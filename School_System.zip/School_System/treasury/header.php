﻿<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Treasury</title>

<?php require "../config.php"; require "collection_generator.php"; ?>

<link href="css/header.css" rel="stylesheet" type="text/css" />
<script language="javascript" src="../js/jquery-1.7.2.min.js"></script>
<script src="../js/lightbox.js"></script>
<link href="../css/lightbox.css" rel="stylesheet" />

<link rel="stylesheet" href="../jquery.superbox.css" type="text/css" media="all" />
	<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.3.2/jquery.min.js"></script>

	<script type="text/javascript" src="../jquery.superbox-min.js"></script>
	<script type="text/javascript">

		$(function(){

			$.superbox.settings = {

				closeTxt: "Close",

				loadTxt: "Loading...",

				nextTxt: "Next",

				prevTxt: "Previous"

			};

			$.superbox();

		});

	</script>
</head>

<body>

<div id="cover_all">
<div id="header_box">
 
 <div id="logo">
  <a href="index.php"><img border="0" src="../img/logo.jpg" width="300" /></a>
 </div><!-- logo -->
 
 <div id="search_camp">
  <form name="search" method="post" action="" enctype="multipart/form-data">
   <input type="text" name="key" /><input class="input" type="submit" name="search" value="" />
  </form>
  
 
 
 <?php if(isset($_POST['search'])){
  
  $key = $_POST['key'];
  if($key == ''){
	  echo "<script language='javascript'>window.alert('Report the Collection Number or Enrollment Number, Please!');</script>";
  }else{
	  $sql_1 = "SELECT * FROM fees WHERE code = '$key'";
	  $result_1 = mysqli_query($connection, $sql_1);
	  if(mysqli_num_rows($result_1) >=1){
   			echo "<script language='javascript'>window.location='show_fees.php?fees=$key&status=show_statement';</script>";		
	  }else{
	  $sql_2 = "SELECT * FROM students WHERE code = '$key' OR name = '$key' OR pps = '$key'";
	  $result_2 = mysqli_query($connection, $sql_2);
	  if(mysqli_num_rows($result_2) >= 1){
		  while($res_2 = mysqli_fetch_assoc($result_2)){	
		  	$student_code = $res_2['code'];
	   echo "<script language='javascript'>window.location='show_student.php?enrollment=$student_code';</script>";	
		  }
	  }else{
	   echo "<script language='javascript'>window.alert('No results for your research, check information provided!');</script>";  
		  
  
  }}}}?>
 
 
 
 </div><!-- search_camp -->
 
 <div id="show_login">
  <h1><strong>Welcome new Student <?php echo @$name; ?></strong> <strong><a href="../config.php?pg=logout">LOG OUT</a></strong></h1>
 </div><!-- show_login -->
</div><!-- box_header -->

</div><!-- cover_all -->

</body>
</html>