﻿<?php $actual_panel = "treasury"; ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Treasury</title>
<link rel="stylesheet" type="text/css" href="css/index_1.css"/>
</head>

<body>
<?php require "header.php"; ?>

<div id="black_box">
</div><!-- black_box -->

<div id="box">
<?php
$d = date("d");
$m = date("m");
$a = date("Y");
?>
 <div id="reports">
   <ul>
    <h1><strong>Financial Statement Today</strong></h1>
    <li><strong>Fees payed by Cash:</strong>  Euro
     <?php
     $sql_2 = mysqli_query($connection, "SELECT SUM(value) as sum FROM fees WHERE payment_day = '$d/$m/$a' AND payment_methods = 'Cash'");
	 	while($res_2 = mysqli_fetch_assoc($sql_2)){
			echo number_format($res_2['sum'],2);
		}
	 ?>
    </li>
    <li><strong>Fees Payed by Credit Card:</strong> Euro
     <?php
     $sql_2 = mysqli_query($connection, "SELECT SUM(value) as sum FROM fees WHERE payment_day = '$d/$m/$a' AND payment_methods = 'Credit Card'");
	 	while($res_2 = mysqli_fetch_assoc($sql_2)){
			echo number_format($res_2['sum'],2);
		}
	 ?>    
    </li>
    <li><strong>Fees Payed by Credit Card:</strong> Euro
     <?php
     $sql_2 = mysqli_query($connection, "SELECT SUM(value) as sum FROM fees WHERE payment_day = '$d/$m/$a' AND payment_methods = 'Credit Card'");
	 	while($res_2 = mysqli_fetch_assoc($sql_2)){
			echo number_format($res_2['sum'],2);
		}
	 ?>      
    </li>
    <li><strong>Fees Payed by Cheque:</strong> Euro
     <?php
     $sql_2 = mysqli_query($connection, "SELECT SUM(value) as sum FROM fees WHERE payment_day = '$d/$m/$a' AND payment_methods = 'Cheque'");
	 	while($res_2 = mysqli_fetch_assoc($sql_2)){
			echo number_format($res_2['sum'],2);
		}
	 ?>      
    </li>
   </ul>

 </div><!-- reports -->
 
 <div id="notifications">
  <h1>Notifications</h1>
  <div id="notifications_warning">
  <?php
  
  $sql_1 = mysqli_query($connection, "SELECT * FROM treasury_wall ORDER BY id DESC LIMIT 30");
  $count_sql_1 = mysqli_num_rows($sql_1);
  
  if($count_sql_1 == ''){
	  echo "<h1>There is no warning on your wall so far!</h1>";
  }else{
	  while($res_1 = mysqli_fetch_assoc($sql_1)){
  ?>
   <ul>
    <li><?php echo $res_1['title']; ?></li>
   </ul>
  <?php }} ?>  
  </div><!-- notifications_warning -->
 </div><!-- notifications -->
 
 
</div><!-- box -->

</body>
</html>