<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
</head>

<body>
<?php

$d = date("d");
$m = date("m");
$a = date("Y");
$d_m_y = date("d/m/Y");
$date = date("d/m/Y H:i:s");

$sql_1 = mysqli_query($connection, "SELECT * FROM students WHERE name != '' AND	status = 'Active'");
if(mysqli_num_rows($sql_1) == ''){
}else{
	while($res_1 = mysqli_fetch_assoc($sql_1)){
		$due_date = $res_1['due_date'];
		$student_code = $res_1['code'];
		$fees = $res_1['fee'];
		$name = $res_1['name'];
		
		$d_venc = $res_1['due_date'];
		
		if($due_date >= 5){
		}else{
		$sql_2 = mysqli_query($connection, "SELECT * FROM fees WHERE due_date = '$d_m_y' AND enrollment = '$student_code'");		
		if(mysqli_num_rows($sql_2) >=1){
		}else{
			$sql_3 = mysqli_query($connection, "SELECT * FROM fees ORDER BY id DESC LIMIT 1");
				while($res_3 = mysqli_fetch_assoc($sql_3)){
					
					$collection_code = $res_3['code']+1;
					
					$v_collection = "$due_date/$m/$a";
		 		
			$sql_4 = mysqli_query($connection, "INSERT INTO fees (code, enrollment, d_collection, due_date, value, status, day, month, year) VALUES ('$collection_code', '$student_code', '$d_m_y', '$v_collection', '$fees', 'Payment on hold', '$d', '$m', '$a')");	
			$sql_5 = mysqli_query($connection, "INSERT INTO tresuary_wall (date, status, title) VALUES ('$date', 'Active', 'A charge in name of  $name regards to month $m/$a is set and is waiting for payment')");	
		
					
	 }
	}
   }
  }
 }
?>
</body>
</html>