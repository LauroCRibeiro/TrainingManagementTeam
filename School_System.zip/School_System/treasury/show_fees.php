<?php
session_start();
$_SESSION['actual_panel'] = "treasury";
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />

<title>Treasury - <?php 
$name = $_SESSION['name'];
echo $name; ?> </title>
<link href="css/index.css" rel="stylesheet" type="text/css" />
</head>

<body>
<?php if(@$_GET['status'] == 'show_statement'){ ?>
<?php require "header.php"; ?>
<div id="black_box">
</div><!-- black_box -->

<div id="box">
<h1>Billing Brief <?php echo $fees = $_GET['fees']; ?></h1>
<?php

$sql_1 = "SELECT * FROM fees WHERE code = '$fees'";
$result_1 = mysqli_query($connection, $sql_1);
while($res_1 = mysqli_fetch_assoc($result_1)){
	$enrollment =  $res_1['enrollment'];

$sql_2 = "SELECT * FROM students WHERE code = '$enrollment'";	
$result_2 = mysqli_query($connection, $sql_2);
	while($res_2 = mysqli_fetch_assoc($result_2)){
?>
 <table width="950" border="0">
  <tr>
    <td colspan="4"><hr /></td>
  </tr>
  <tr>
    <td><strong>Enrollment Number:</strong></td>
    <td><strong>Student Name:</strong></td>
    <td><strong>Due Date:</strong></td>
  </tr>
  <tr>
    <td><?php echo $enrollment; ?></td>
    <td><?php echo $res_2['name']; ?></td>
    <td><?php echo $res_1['due_date']; ?></td>
  </tr>
  <tr>
    <td><strong>Value:</strong></td>
    <td><strong>Status:</strong></td>
    <td><strong>Payment Date:</strong></td>
  </tr>
  <tr>
    <td> <?php echo number_format($res_1['value'],2); ?> Euro</td>
    <td><?php echo $res_1['status']; ?></td>
    <td><?php echo $res_1['payment_date']; ?></td>
  </tr>
  <tr>
    <td><strong>PPS:</strong></td>
    <td><strong>Course:</strong></td>
  </tr>
  <tr>
    <td><?php echo $res_2['pps']; ?></td>
    <td><?php echo $res_2['year_grade']; ?></td>
  </tr>
  <tr>
    <td><strong>Payment Methods:</strong></td>
    <td><?php echo $res_1['payment_methods']; ?></td>
  </tr>
  <tr>
    <td colspan="4"><hr /></td>
  </tr>
  <?php if($res_1['status'] != 'Payment Confirmed'){ ?>
  <tr>
    <td colspan="4">| <a rel="superbox[iframe][270x180]" href="show_fees.php?fees=<?php echo $fees; ?>&status=low_fees&value=<?php echo $res_1['value']; ?>&enrollment=<?php echo $enrollment; ?>">Show Payment</a> | <a rel="superbox[iframe][270x180]" href="show_fees.php?fees=<?php echo $fees; ?>&status=readjust_fees&value=<?php echo $res_1['value']; ?>">Readjust Billing Value</a> | </td>
  </tr>  
  <?php } ?>
</table>
<?php }} ?>
<ul>
 <li>Bear in mind after reporting down cash, you are responsible for the cash flow.</li>
 <li>Do not forget before fee adjustament, you must be authorized to do so.</li>
 <li>Caution, If you send a Billing Collection to some student, you are entirely responsible for it</li>
 <li>If you have some questions, just pop in the main office</li>
</ul>
</div><!-- box -->
<?php } ?>



<?php if($_GET['status'] == 'low_fees'){ ?>
<?php require "../config.php"; ?>
<div id="low_box">

<?php if(isset($_POST['confirm'])){

$date = date("d/m/Y H:i:s");
$day = date("d/m/Y");
$d = date("d");
$m = date("m");
$a = date("Y");
$payment_methods = $_POST['payment_methods'];
$fees = $_GET['fees'];
$enrollment = $_GET['enrollment'];
$value = $_GET['value'];

$sql_1 = "UPDATE fees SET status = 'Payment Confirmed', payment_date = '$date', payment_day = '$day', payment_methods = '$payment_methods', d_p = '$d', m_p = '$m', a_p = '$a' WHERE code = '$fees'";
mysqli_query($connection, $sql_1);


$sql_2 = "INSERT INTO cash_flow (status, type, d, m, a, full_date, date, code, details, value, payment_methods) VALUES ('Active', 'CREDIT', '$d', '$m', '$a', '$date', '$day', 'fees=$code', 'Student`s fees: $enrollment Start: $m/$a', '$value', '$payment_methods')";
mysqli_query($connection, $sql_2);

	echo "<br><br>Operation Concluded Successfully!<br> Press F5 .";	
die;

}?>

<h1>Payment Methods</h1>

<form name="confirm" method="post" action="" enctype="multipart/form-data">
<select name="payment_methods">
 <option value="">Select</option>
 <option value="Credit Card">Credit Card</option>
 <option value="Debit Card">Debit Card</option>
 <option value="Cash">Cash</option>
 <option value="Cheque">Cheque</option>
</select>
<input class="select" type="submit" name="confirm" value="Confirm" />
</form>
</div><!-- low_box -->
<?php } ?>




<?php if($_GET['status'] == 'readjust_fees'){ ?>

<?php require "../config.php"; ?>
<div id="low_box">
<?php if(isset($_POST['confirm'])){

$value = $_POST['value'];
$fees = $_GET['fees'];
$date = date("d/m/Y H:i:s");

$sql_1 = "UPDATE fees SET value = '$value' WHERE code = '$fees'";
mysqli_query($connection, $sql_1);

$sql_2 = "INSERT INTO coordenation_wall (date, status, course, title) VALUES ('$date', 'Active', 'Uninformed', 'Students`s fee has been adjusted!')";
mysqli_query($connection, $sql_2);

	echo "<br><br>Operation Concluded Successfully!<br> Press F5.";	
die;

}?>
<h1>Readjust Billing Value</h1>
<form name="confirm" method="post" action="" enctype="multipart/form-data">
<input type="text" name="value" value="<?php echo $_GET['value']; ?>" />
<input class="select" type="submit" name="confirm" value="Confirm" />
</form>
</div><!-- low_box -->
<?php } ?>
</body>
</html>