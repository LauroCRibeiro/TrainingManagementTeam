<?php
session_start();
$_SESSION['actual_panel'] = "treasury";
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />

<title>To Learn - Treasury - <?php $name = $_SESSION['name']; echo $name; ?> </title>
<link href="css/index.css" rel="stylesheet" type="text/css" />
</head>

<body>
<?php require "header.php"; ?>
<div id="black_box">
</div><!-- black_box -->

<div id="box">
<h1>Student Enrollment Number - <?php echo $enrollment = $_GET['enrollment']; ?></h1>
<?php
$sql_1 = "SELECT * FROM students WHERE code = '$enrollment'";
$result_1 = mysqli_query($connection, $sql_1);
	while($res_1 = mysqli_fetch_assoc($result_1)){
?>
 <table width="900" border="0">
  <tr>
    <td colspan="4"><hr /></td>
  </tr>
  <tr>
    <td width="314"><strong>Name:</strong></td>
    <td width="308"><strong>Birthday:</strong></td>
    <td width="221"><strong>Due Date:</strong></td>
  </tr>
  <tr>
    <td><?php echo $res_1['name']; ?></td>
    <td><?php echo $res_1['birthday']; ?></td>
    <td><?php echo $res_1['due_date']; ?></td>
  </tr>
  <tr>
    <td><strong>Value:</strong></td>
    <td><strong>Status:</strong></td>
    <td><strong>PPS:</strong></td>
  </tr>
  <tr>
    <td><?php echo $res_1['fee']; ?></td>
    <td><?php echo $res_1['status']; ?></td>
    <td><?php echo $res_1['pps']; ?></td>
  </tr>
  <tr>
    <td><strong>Shift:</strong></td>
    <td><strong>Billing Phone:</strong></td>
    <td><strong>Course:</strong></td>
  </tr>
  <tr>
    <td><?php echo $res_1['shift']; ?></td>
    <td><?php echo $res_1['collection_number']; ?></td>
    <td><?php echo $res_1['year_grade']; ?></td>
  </tr>
  <tr>
    <td colspan="3"><hr> 
 
  <h1><strong>Fees History</strong></h1></td>
  </tr>
  <tr>
    <td colspan="3">
    <table width="920" border="0">
      <tr>
        <td width="130" height="21"><strong>Collection Number:</strong></td>
        <td width="100"><strong>Due Date:</strong></td>
        <td width="80"><strong>Value:</strong></td>
        <td width="150"><strong>Status:</strong></td>
        <td width="170"><strong>Payment Date:</strong></td>
        <td width="154"><strong>Payment Methods:</strong></td>
      </tr>
      <?php
      $sql_2 = "SELECT * FROM fees WHERE enrollment = '$enrollment' ORDER BY id DESC";
	  $result_2 = mysqli_query($connection, $sql_2);
	  	while($res_2 = mysqli_fetch_assoc($result_2)){	  
	  ?>
      <tr>
        <td><?php echo $res_2['code']; ?></td>
        <td><?php echo $res_2['due_date']; ?></td>
        <td><?php echo $res_2['value']; ?></td>
        <td><?php echo $res_2['status']; ?></td>
        <td><?php echo $res_2['payment_date']; ?></td>
        <td><?php echo $res_2['payment_methods']; ?></td>
        </tr>
      <tr>
        <td colspan="6"><hr></td>
        </tr>
     <?php } ?>
    </table>
    </td>
  </tr>  
</table>
<?php } ?>
</div><!-- box -->
</body>
</html>