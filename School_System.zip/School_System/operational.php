<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
</head>

<body>
<?php // Closing Semester Assignments


$date = date("d/m/Y");
$sql_1 = mysqli_query($connection, "SELECT * FROM semester_assignments WHERE delivery_date < '$date'");
if(mysqli_num_rows($sql_1) == ''){
}else{
	while($res_1 = mysqli_fetch_assoc($sql_1)){	
		
		mysqli_query($connection, "UPDATE semester_assignments SET status = 'Closed' WHERE id = ".$res_1['id']."");
 }
}
// Closing Semester Assignments
?>


<?php // Closing Extra Assigments
$date = date("d/m/Y");
$sql_2 = mysqli_query($connection, "SELECT * FROM extra_assignments WHERE delivery_date < '$date'");
if(mysqli_num_rows($sql_2) == ''){
}else{
	while($res_2 = mysqli_fetch_assoc($sql_2)){	
		
		mysqli_query($connection, "UPDATE extra_assignments SET status = 'Closed' WHERE id = ".$res_2['id']."");
 }
}
// Semester Assignments Ending.
?>
</body>
</html>