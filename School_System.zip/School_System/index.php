﻿<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Scholar System</title>

<link rel="stylesheet" type="text/css" href="css/style.css"/>

<link rel="shortcut icon" href="img/ico_escola.ico" />

<?php require "connection.php"; require "operational.php"; require "staff_payment.php"; ?>

</head>

<body>

<div id="logo">
<img src="img/logo.jpg" />
</div>
<br><br><br><br><br><br>


<div id="login_box">

<?php
if(isset($_POST['button'])){
	$code = $_POST['code'];
	$password = $_POST['password'];
	
	if($code == ''){
		echo "<h2> Type your card number or access code! </h2>";
		}
		
		else if($password == ''){
			echo "<h2> Type your password, Please!</h2>";		
	} else{
		$sql = "SELECT * FROM login WHERE code = '$code' AND password = '$password'";
		
		$result = mysqli_query($connection, $sql);
		if(mysqli_num_rows($result) > 0){
			
			while($res_1 = mysqli_fetch_assoc($result)){
				$status = $res_1['status'];
				$code = $res_1['code'];
				$password = $res_1['password'];
				$name = $res_1['name'];
				$panel = $res_1['panel'];
				
				if($status == 'Inactive'){
					echo "<h2> You are inactive, ask for help at the main office</h2>";	
				}else{
				
					session_start();
					$_SESSION['code'] = $code;
					$_SESSION['name'] = $name;
					$_SESSION['password'] = $password;
					$_SESSION['panel'] = $panel;
					
					if($panel == 'admin'){
						echo "<script language='javascript'> window.location='admin';</script>";	
						
					} else if($panel == 'student'){
						echo "<script language='javascript'> window.location='student';</script>";	
					}else if($panel == 'teacher'){
						echo "<script language='javascript'> window.location='teacher';</script>";	
					}else if($panel == 'concierge'){
						echo "<script language='javascript'> window.location='concierge';</script>";	
					}else if($panel == 'treasury'){
						echo "<script language='javascript'> window.location='treasury';</script>";	
					}
						
				}
				
			}
			
		} else{
			echo "<h2> Incorrect Data! </h2>";	
		}
		
	}
}
?>

<form name="form" method="post" action="" enctype="multipart/form-data">

<table>
  <tr>
   <td><h1>Card Number or Access Code:</h1></td>
  </tr>
  <tr>
   <td><input type="text" name="code" /></td>
  </tr>
   <tr>
   <td><h1>Password:</h1></td>
  </tr>
  <tr>
   <td><input type="password" name="password" /></td>
  </tr>
  <tr>
   <td><input class="input" type="submit" name="button" value="Log In" /></td>
  </tr>
 </table>

</form>
</div>


</body>
</html>