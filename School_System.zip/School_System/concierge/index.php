﻿<?php $actual_panel = "concierge"; ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Concierge</title>
<link rel="stylesheet" type="text/css" href="css/index.css"/>
<?php require "../config.php"; ?>
</head>

<body>

<div id="box">
 
 <div id="doorman">
  <h1><strong><i><?php echo $name ?> </i> - Your code is:</strong> <?php echo $code ?> <a href="../config.php?action=quit"><br><br>
  
  <a href="../config.php?action=quit"><strong>LOGOUT</strong></a></h1>
 </div><!-- doorman -->
 
 <div id="logo">
  <img src="../img/logo.jpg" width="250px" />
 </div><!-- logo -->
 
 <div id="search_camp">
   <form name="" method="post" action="" enctype="multipart/form-data">
   <input type="text" name="pps" value="" /><input class="input" type="submit" name="send" value="" />
  </form>
  
 
 <?php
if(isset($_POST['send'])){
	
	$_GET['pg'] = '';
	$pps = $_POST['pps'];
	
	
	if($pps == ''){
		echo "<script language='javascript'> window.alert('Type your enrollment number or PPS, Please!');</script>";
		}
		
		else{
		$sql = "SELECT * FROM students WHERE code = '$pps' OR name = '$pps' OR pps = '$pps' OR identification = '$pps' ";
		
		$result = mysqli_query($connection, $sql);
		if(mysqli_num_rows($result) <= 0){
			echo "<br><br><br><br><h2> Student not found, Check the details typed in! </h2>";
			
		}else{
			while($res_1 = mysqli_fetch_assoc($result)){
				$name = $res_1['name'];
				$code = $res_1['code'];
				$ident = $res_1['identification'];
				
	
	?> 
  
  

<br><br><br><br><h3><strong>
Student:</strong> <?php echo $name ?> <strong>
Enrollment Number:</strong> <?php echo $code; ?> <strong>
ID:</strong> <?php echo $ident; ?> 

<a href="index.php?pg=confirm&code_a=<?php echo $code; ?>"><img src="../img/confirma.png" title="Confirm" border="0" width="22px" /></a> 

<a href="index.php"><img src="../img/deleta.png" title="Cancel" width="22px" /></a> </h3>

<input type="hidden" name="codes" value="" />    
 
<?php 	}	}	}   } ?>


<?php  
if(@$_GET['pg'] == 'confirm'){
	$data = date("d/m/Y H:i:s");
	$date = date("d/m/Y");
	
	$code_a = $_GET['code_a'];
	
	$sql = "INSERT INTO confirm_students_entrance (date, today_date, doorman, student_code) VALUES ('$data', '$date', '$code', '$code_a')";	
	
	mysqli_query($connection, $sql);
	
	echo "<script language='javascript'> window.alert('Student entrance has been confirmed!');</script>";
	
}
?>


 </div><!-- search_camp -->
 <br><br><br>
</div><!-- box -->
</body>
</html>