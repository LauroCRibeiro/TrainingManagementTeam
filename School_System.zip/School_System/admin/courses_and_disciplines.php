<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />

<title>Management</title>
<link href="css/courses_and_disciplines.css" rel="stylesheet" type="text/css" />
</head>

<body>
<?php require "header.php"; ?>


<!Register Course>

<div id="black_box">
</div><!-- black_box -->

<?php if(@$_GET['pg'] == 'course'){ ?>
<div id="course_box">
<br /><br />
 <a class="a2" href="courses_and_disciplines.php?pg=course&register=yes">Register Course</a>
<?php if(@$_GET['register'] == 'yes'){?> 
 <br /><br />
 <h1>Register Course</h1>
<?php if(isset($_POST['register'])){

$course = $_POST['course'];

$sql = "INSERT INTO courses(course)  VALUES ('$course')";	
	
	$cad = mysqli_query($connection, $sql);

	if ($cad == ''){
		echo "<script language='javascript'> window.alert('Error! Course already registered');</script>";
	}else{
		
	echo "<script language='javascript'> window.alert('Course successfully registered!');</script>";
	echo "<script language='javascript'>window.location='courses_and_disciplines.php?pg=course';</script>";
	}

}?> 
<form name="form1" method="post" action="">
  <table width="900" border="0">
    <tr>
      <td width="134">Course</td>
    </tr>
    <tr>
      <td><input type="text" name="course" id="textfield"></td>
      <td><input class="input" type="submit" name="register" id="button" value="Register"></td>
    </tr>
  </table>
</form> 
 <br />
<?php die;} ?> 



<!View Registered Course>

<?php
$sql_1 = "SELECT * FROM courses";
$result = mysqli_query($connection, $sql_1);
 if(mysqli_num_rows($result) <= 0){
	 echo "<br><br>There is no course registered by now.<br><br>";
 }else{
?>
<br /><br />
 <h1>Course</h1>
    <table width="900" border="0">
      <tr>
        <td><strong>Course:</strong></td>
        <td><strong>Number of subjects:</strong></td>
        <td>&nbsp;</td>
      </tr>
      <?php while($res_1 = mysqli_fetch_assoc($result)){ ?>
      <tr>
        <td><h3><?php echo $course = $res_1['course']; ?></h3></td>
        <td><h3><?php $sql_2 = "SELECT * FROM disciplines WHERE course = '$course'";
		$result2 = mysqli_query($connection, $sql_2);
		echo mysqli_num_rows($result2); ?></h3>
        </td>
        <td><a class="a" href="courses_and_disciplines.php?pg=course&delete=cur&id=<?php echo @$res_1['id']; ?>"><img title="Delete Course" src="img/deleta.jpg" width="18" height="18" border="0"></a></td>
      </tr>
      <?php } ?>
    </table>	 

<?php } ?> 
<br />


<!COURSE DELETION>

<?php if(@$_GET['delete'] == 'cur'){

$id = $_GET['id'];

$sql_3 = "DELETE FROM courses WHERE id = '$id'";
mysqli_query($connection, $sql_3);

echo "<script language='javascript'>window.location='courses_and_disciplines.php?pg=course';</script>";

}?>
</div><!-- course_box -->
<?php  }?>





<!REGISTER DISCIPLINE>

<?php if(@$_GET['pg'] == 'discipline'){ ?>

<div id="disciplines_box">
<a class="a2" href="courses_and_disciplines.php?pg=discipline&register=yes">
Register Discipline</a>
<?php if(@$_GET['register'] == 'yes'){ ?>
<h1>Register New Discipline</h1>

<?php if(isset($_POST['register'])){
	
$course = $_POST['course'];	
$discipline = $_POST['discipline'];	
$teacher = $_POST['teacher'];	
$classroom = $_POST['classroom'];	
$shift = $_POST['shift'];	

if($discipline == ''){
	echo "<script language='javascript'>window.alert('Type Discipline Name');</script>";
}else if($classroom == ''){
	echo "<script language='javascript'>window.alert('Type Classroom number');</script>";
}else{
$sql_cad_disc = "INSERT INTO disciplines (course, discipline, teacher, classroom, shift) VALUES ('$course', '$discipline', '$teacher', '$classroom', '$shift')";
$cad_disc = mysqli_query($connection, $sql_cad_disc);
if($cad_disc == ''){
	echo "<script language='javascript'>window.alert('ERROR has occurred');</script>";
}else{
	echo "<script language='javascript'>window.alert('Discipline successfully registered');window.location='courses_and_disciplines.php?pg=discipline';</script>";
	echo "<script language='javascript'>window.location='courses_and_disciplines.php?pg=discipline';</script>";
  }
 }
}?>

<form name="form1" method="post" action="">
  <table width="900" border="0">
    <tr>
      <td width="134">Course:</td>
      <td width="213">Discipline:</td>
      <td>Teacher:</td>
      <td width="128">Classroom: <em>Only numbers</em></td>
      <td width="128">Shift:</td>
      <td width="126">&nbsp;</td>
      <td width="0" colspan="2"></td>
    </tr>
    <tr>
      <td>
      <select name="course">
      <?php
      $sql_rec_course = "SELECT * FROM courses";
	  $result_rec_course = mysqli_query($connection, $sql_rec_course);

	  	while($r2 = mysqli_fetch_assoc($result_rec_course)){
	  ?>
      	<option value="<?php echo $r2['course']; ?>"><?php echo $r2['course']; ?></option>
      <?php } ?>
      </select>
      </td>
      <td>
      <input type="text" name="discipline" id="textfield"></td>
      <td width="143">
      <select name="teacher">
      <?php
      $sql_result_teacher = "SELECT * FROM teachers WHERE name != ''";
	  $result_rec_teacher = mysqli_query($connection,  $sql_result_teacher );
	  	while($r3 = mysqli_fetch_assoc($result_rec_teacher)){
	  ?>
       <option value="<?php echo $r3['code']; ?>"><?php echo $r3['name']; ?></option>
      <?php } ?>
      </select>
      </td>
      <td>
      <input type="text" name="classroom" id="textfield"></td>
      <td>
        <select name="shift" size="1" id="shift">
          <option value="Morning">Morning</option>
          <option value="Afternoon">Afternoon</option>
          <option value="Evening">Evening</option>
      </select></td>
      <td width="126"><input class="input" type="submit" name="register" id="button" value="REGISTER"></td>
    </tr>    
  </table>
</form>

<?php die;  } ?>






<!SHOW DISCIPLINES TABLE>


<br /><br />




 <h1>Disciplines</h1>
<?php
$sql_search_disc = "SELECT * FROM disciplines";
$result_search_disc = mysqli_query($connection,  $sql_search_disc );
if(mysqli_num_rows($result_search_disc) == ''){
	echo "<h2>There is no Discipline Register by now.</h2><br><br>";
}else{
?> 
    <table width="900" border="0">
      <tr>
        <td><strong>Course:</strong></td>
        <td><strong>Discipline:</strong></td>
        <td><strong>Teacher:</strong></td>
        <td><strong>Classroom:</strong></td>
        <td><strong>Shift:</strong></td>
      </tr>
      <?php while($res_search = mysqli_fetch_assoc($result_search_disc)){ ?>
      <tr>
        <td><h3><?php echo $res_search['course']; ?></h3></td>
        <td><h3><?php echo $res_search['discipline']; ?></h3></td>
        <td><h3>
		<?php
		$teacher = $res_search['teacher'];
		
		$sql_search_teacher = "SELECT * FROM teachers WHERE code = '$teacher'";
			$result_search_teacher = mysqli_query($connection,  
        $sql_search_teacher);
			while($res_search2 = mysqli_fetch_assoc($result_search_teacher)){
				echo $res_search2['name']; echo " - "; echo $res_search['teacher'];
			}
				
		?>
        </h3></td>
        <td><h3><?php echo $res_search['classroom']; ?></h3></td>
        <td><h3><?php echo $res_search['shift']; ?></h3></td>
        <td><a class="a" href="courses_and_disciplines.php?pg=discipline&delete=yes&id=<?php echo $res_search['id']; ?>"><img title="Delete Discipline" src="img/deleta.jpg" width="18" height="18" border="0"></a></td>
      </tr>
      <?php } ?>
    </table>
<?php } ?>






<!DISCIPLINE DELETION>

<?php if(@$_GET['delete'] == 'yes'){

$id = $_GET['id'];

$sql_delete_disc = "DELETE FROM disciplines WHERE id = '$id'";
mysqli_query($connection,  $sql_delete_disc);

echo "<script language='javascript'>window.location='courses_and_disciplines.php?pg=discipline';</script>";

}?> 
</div><!-- disciplines_box -->
<?php } ?>






<!SHOW COURSES AND DISCIPLINES>


<?php if(@$_GET['pg'] == 'coursesanddisciplines'){ ?>
<div id="box_courses_and_disciplines">
<h1>Courses and Disciplines</h1>

<?php
$sql_ced = "SELECT * FROM courses";
$result_ced = mysqli_query($connection,  $sql_ced);
if(mysqli_num_rows($result_ced) == ''){
	echo "There is no course registered by now";
}else{
?>
<table width="620" border="0">
<?php while($rs_ced = mysqli_fetch_assoc($result_ced)){ ?>
  <tr>
    <td width="614">Course: <?php echo $course = $rs_ced['course']; ?></td>
  </tr>
  <tr>
    <td>
    <textarea disabled="disabled" name="textarea" id="textarea" cols="100" rows="5">
    <?php
     $sql_ced_teacher = "SELECT * FROM disciplines WHERE course = '$course'";
	 $result_ced_teacher = mysqli_query($connection,  $sql_ced_teacher);
	 	while($rs_ced2 = mysqli_fetch_assoc($result_ced_teacher)){
		
			$teacher = $rs_ced2['teacher'];
						
			echo $rs_ced2['discipline']; 
			echo " - ";
	$sql_ced_cod = "SELECT * FROM teachers WHERE code = '$teacher'";
	$result_ced_cod = mysqli_query($connection,  $sql_ced_cod);
		while($rs_ced3 = mysqli_fetch_assoc($result_ced_cod)){
			echo $rs_ced3['name'];
			echo " - ";
			echo $rs_ced3['code'];
			}  ?>
		
		<?php }
		
	?>
    </textarea>
    </td>
  </tr>
<?php } ?>
</table>
<br />	
<?php } ?>

</div><!-- box_course_and_disciplines -->
<?php } ?>



</div>
<?php require "footer.php"; ?>
</body>
</html>