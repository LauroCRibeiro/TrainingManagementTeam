﻿<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Technical Support</title>
<link rel="stylesheet" type="text/css" href="css/technical_support.css"/>
</head>

<body>
<?php require "header.php"; ?>

<div id="black_box">
</div><!-- black_box -->

<div id="box">
 <h1>Technical Support</h1> 

<?php if(isset($_POST['button'])){

$resp = $_POST['resp'];
$id = $_POST['id'];
$date = date("d/m/Y H:i:s");
$attach = $_FILES['attachment']['name'];

if(file_exists("../attachment/$attach")){
		 $a = 1;
		 while(file_exists("../attachment/[$a]$attach")){
			 $a++;
			 }
			 
		$attach = "[".$a."]".$attach;	 
	}
	
$sql_2 = "UPDATE central_message SET status = 'Replied', reponse_date = '$date', response = '$resp', attach_resp = '$attach' WHERE id = '$id' ";
mysqli_query($connection, $sql_2);

(move_uploaded_file($_FILES['attachment']['tmp_name'], "../attachment/".$attach));

echo "<script language='javascript'>window.alert('Message Replied Successfully!');window.location='';</script>";


}?>

<?php
$sql_1 = "SELECT * FROM central_message WHERE receiver = 'COORDENATION' AND status = 'Response on hold' LIMIT 3";
$result = mysqli_query($connection, $sql_1);
if(mysqli_num_rows($result) == ''){
	echo "<h2>There is no contact to be replied to!</h2>";	
}else{
	while($res_1 = mysqli_fetch_assoc($result)){
?>
 
<form name="button" method="post" action="" enctype="multipart/form-data">
<table width="950" border="0">
  <tr>
    <td><strong>Date:</strong></td>
    <td><strong>Student Enrollment Number:</strong></td>
    <td><strong>Attachment:</strong></td>
  </tr>
  <tr>
    <td><?php echo $res_1['date']; ?></td>
    <td><?php echo $res_1['emitter']; ?></td>
    <td><a target="_blank" href="../attachment/<?php echo $res_1['attachment']; ?>"><?php echo $res_1['attachment']; ?></a></td>
  </tr>
  <tr>
    <td><strong>Message:</strong></td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td colspan="3"><?php echo $res_1['message']; ?></td>
  </tr>
  <tr>
    <td colspan="3"><label for="textarea"></label>
    <textarea name="resp" id="textarea" cols="110" rows="5"></textarea></td>
  </tr>
  <tr>
    <td colspan="3"><strong>Choose a file to attach it below</strong></td>
  </tr>
  <tr>
    <td colspan="3"><input name="attachment" type="file" /></td>
  </tr>
  <tr>
    <td><input class="input" type="submit" name="button" id="button" value="SEND"></td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
</table>
<input type="hidden" name="id" value="<?php echo $res_1['id']; ?>" />
</form>

<?php }} ?>
</div><!-- box -->

<?php require "footer.php"; ?>
</body>
</html>