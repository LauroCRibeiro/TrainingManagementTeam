﻿<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Students</title>
<link rel="stylesheet" type="text/css" href="css/students.css"/>
</head>

<body>
<?php require "header.php"; ?>

<!Searching for a Student>

<div id="black_box">
</div><!-- black_box -->
<?php if(@$_GET['pg'] == 'all'){ ?>
<div id="student_box">
 <br /><br />
 <a class="a2" href="students.php?pg=register&block=1">Register new Student</a>
 <h1>Student already registered</h1>

<?php
$sql_1 = "SELECT * FROM students WHERE name != ''";
$query = mysqli_query($connection, $sql_1);
if(mysqli_num_rows($query) == ''){
	echo "<h2>There is no student registered at this moment.</h2>";
}else{
?>

    <table width="900" border="0">
      <tr>
        <td><strong>Status:</strong></td>
        <td><strong>Code:</strong></td>
        <td><strong>Name:</strong></td>
        <td><strong>Year Grade:</strong></td>
        <td><strong>Fee:</strong></td>
        <td></td>
      </tr>
      <?php while($res_1 = mysqli_fetch_assoc($query)){ ?>
      <tr>
        <td><h3><?php echo $res_1['status']; ?></h3></td>
        <td><h3><?php echo $res_1['code']; ?></h3></td>
        <td><h3><?php echo $res_1['name']; ?></h3></td>
        <td><h3><?php echo $res_1['year_grade']; ?></h3></td>
        <td><h3>R$ <?php echo $res_1['fee']; ?></h3></td>
        <td></td>
        <td>
        <a class="a" href="students.php?pg=all&func=delete&id=<?php echo $res_1['id']; ?>&code=<?php echo $res_1['code']; ?>"><img title="Delete Student" src="img/deleta.jpg" width="18" height="18" border="0"></a>
        <?php if($res_1['status'] == 'Inactive'){ ?>
        <a class="a" href="students.php?pg=all&func=activate&id=<?php echo $res_1['id']; ?>&code=<?php echo $res_1['code']; ?>"><img title="Reactivate Student" src="../img/correto.jpg" width="20" height="20" border="0"></a>
        <?php } ?>
        <?php if($res_1['status'] == 'Active'){?>
        <a class="a" href="students.php?pg=all&func=inactivate&id=<?php echo $res_1['id']; ?>&code=<?php echo $res_1['code']; ?>"><img title=" Inactivate Student" src="../img/ico_bloqueado.png" width="18" height="18" border="0"></a>
        <?php } ?>
        <a class="a" rel='superbox[iframe][800x600]' href="show_results.php?q=<?php echo $res_1['code']; ?>&s=student&course=<?php echo $res_1['year_grade']; ?>"><img title="Detailed info about this student" src="../img/visualizar16.gif" width="18" height="18" border="0"></a>
        </td>
      </tr>
      <?php } ?>
    </table>
    <br /> 
<?php } // Closing Student Query?>
</div><!-- student_box -->







<! Deletion, Activation and Deactivation>

<?php if(@$_GET['func'] == 'delete'){

$id = $_GET['id'];
$code = $_GET['code'];

$sql_del = "DELETE FROM students WHERE id = '$id'";
$sql_del2 = "DELETE FROM login WHERE code = '$code'";
mysqli_query($connection, $sql_del);
mysqli_query($connection, $sql_del2);

echo "<script language='javascript'>
window.location='students.php?pg=all';</script>";
}?>


<?php if(@$_GET['func'] == 'activate'){

$id = $_GET['id'];
$code = $_GET['code'];

$sql_edit = "UPDATE students SET status = 'Active' WHERE id = '$id'";
$sql_edit2 = "UPDATE login SET status = 'Active' WHERE code = '$code'";
mysqli_query($connection, $sql_edit);
mysqli_query($connection,$sql_edit2);

echo "<script language='javascript'>window.location='students.php?pg=all';</script>";
}?>


<?php if(@$_GET['func'] == 'inactivate'){

$id = $_GET['id'];
$code = $_GET['code'];

$sql_edit = "UPDATE students SET status = 'Inactive' WHERE id = '$id'";
$sql_edit2 = "UPDATE login SET status = 'Inactive' WHERE code = '$code'";
mysqli_query($connection, $sql_edit);
mysqli_query($connection,$sql_edit2);

echo "<script language='javascript'>window.location='students.php?pg=all';</script>";
}?>


<?php }// Closing pg All ?>





<!Register a Student - Step one>


<?php  if(@$_GET['pg'] == 'register'){ ?> 
<?php  if(@$_GET['block'] == '1'){ ?>
<div id="register_student">
 <h1>First Step - Register Personal Details</h1>

<?php  if(isset($_POST['button'])){

$code = $_POST['code'];
$name = $_POST['name'];
$pps = $_POST['pps'];
$identification = $_POST['identification'];
$birthday = $_POST['birthday'];
$mother = $_POST['mother'];
$father = $_POST['father'];
$county = $_POST['county'];
$city = $_POST['city'];
$neighborhood = $_POST['neighborhood'];
$address = $_POST['address'];
$complement = $_POST['complement'];
$residential_phone = $_POST['residential_phone'];
$postal_code = $_POST['postal_code'];
$mobile = $_POST['mobile'];
$friend_contact = $_POST['friend_contact'];

$sql_2 = "INSERT INTO students (code, status, name, pps, identification, birthday, mother, father, county, city, neighborhood, address, complement, postal_code, residential_phone, mobile, friend_contact) VALUES ('$code', 'Active', '$name', '$pps', '$identification', '$birthday', '$mother', '$father', '$county', '$city', '$neighborhood', '$address', '$complement', '$postal_code', '$residential_phone', '$mobile', '$friend_contact')";

$sql_login = "INSERT INTO login (status, code, password, name, panel) VALUES ('Active', '$code', '$pps', '$name', 'Students')";

$register = mysqli_query($connection, $sql_2);
$register_login = mysqli_query($connection, $sql_login);

echo "<script language='javascript'>window.alert('Successfully Registered Click OK to next');window.location='students.php?pg=register&block=2&code=$code';</script>";

}?> 
 
<form name="form1" method="post" action="">
  <table width="900" border="0">
	<tr>
     <td></td>
     <td colspan="2"><strong> It has created an exclusive code for this student</strong></td>
     <td></td>
    </tr>
    <tr>
     <td></td>
     <?php 
	 $sql_1 = "SELECT * FROM students ORDER BY id DESC LIMIT 1";
	 $con_est = mysqli_query($connection, $sql_1);
	 if(mysqli_num_rows($con_est) == ''){
		 $new_code = "587418";
	?>
      <td><input type="text" name="code" id="textfield" disabled="disabled" value="<?php echo $new_code; ?>"></td>
      <input type="hidden" name="code" value="<?php echo $new_code; ?>" />    
    <?php
		 }else{
	 
	 	while($res_1 = mysqli_fetch_assoc($con_est)){
			$new_code = $res_1['code']+741+$res_1['id'];
	 ?>
      <td><input type="text" name="code" id="textfield" disabled="disabled" value="<?php echo $new_code; ?>"></td>
      <input type="hidden" name="code" value="<?php echo $new_code; ?>" />
     <?php } } ?>
     <td></td>
    </tr>    
    <tr>
      <td>Name:</td>
      <td>Pps:</td>
      <td>Id:</td>
    </tr>
      <td><label for="mobile"></label>
      <input type="text" name="name" id="textfield2"></td>
      <td><label for="friend_contact"></label>
      <input type="text" name="pps" id="textfield3"></td>
      <td><label for="friend_contact"></label>
      <input type="text" name="identification" id="textfield3"></td>
    </tr>
    <tr>
      <td>Birthday:</td>
      <td>Mother`s name:</td>
      <td>Father`s name:</td>
    </tr>
    <tr>
      <td><label for="birthday"></label>
      <input type="text" name="birthday" id="textfield4"></td>
      <td><label for="select"></label>
      <input type="text" name="mother" id="textfield12"></td>
      <td><input type="text" name="father" id="textfield5"></td>
    </tr>
    <tr>
      <td>County:</td>
      <td>City:</td>
      <td>Neighborhood:</td>
    </tr>
    <tr>
      <td><input type="text" name="county" id="textfield6"></td>
      <td><input type="text" name="city" id="textfield7"></td>
      <td><input type="text" name="neighborhood" id="textfield8"></td>
    </tr>
    <tr>
      <td>Address:</td>
      <td>Complement:</td>
      <td>Postal Code:</td>
    </tr>
    <tr>
      <td><input type="text" name="address" id="textfield8"></td>
      <td><input type="text" name="complement" id="textfield8"></td>
      <td><input type="text" name="postal_code" id="textfield8"></td>
    </tr>
    <tr>
      <td>Home Phone:</td>
      <td>Mobile:</td>
      <td>Friend`s Phone Number:</td>
    </tr>
    <tr>
      <td><input type="text" name="residential_phone" id="textfield9"></td>
      <td><input type="text" name="mobile" id="textfield10"></td>
      <td><input type="text" name="friend_contact" id="textfield11"></td>
    </tr>
    <tr>
      <td><input class="input" type="submit" name="button" id="button" value="Next"></td>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
    </tr>
  </table>
</form>
<br /> 
 
</div><!-- Register Student -->

<?php } // Closing the First Step ?>




<!REGISTER STUDENTS - STEP 2>

<?php if(@$_GET['block'] == '2'){ ?>
<div id="register_student">
 <h1>Second Step - Finish your Details</h1>

<?php if(isset($_POST['button'])){

$code = $_GET['code'];
$grade_year = $_POST['grade_year'];
$shift = $_POST['shift'];
$extra_service = $_POST['extra_service'];
$fee = $_POST['fee'];
$due_date = $_POST['due_date'];
$collection_phone = $_POST['collection_phone'];
$obs = $_POST['OBS'];

$sql_3 = "UPDATE students SET grade_year = '$grade_year', shift = '$shift', extra_service = '$extra_service', fee = '$fee', due_date = '$due_date', collection_phone = '$collection_phone', OBS = '$obs' WHERE code = '$code'";

mysqli_query($connection, $sql_3);

$d = date("d");
$m = date("m");
$a = date("Y");
$code_collection = $code*2;

$sql_monthly = "INSERT INTO fees (code, enrollment, d_collection, due_date, value, status, day, month, year) VALUES ('$code_collection', '$code', '$d/$m/$a', '$due_date/$m/$a', '$fee', 'Payment on hold', '$d', '$m', '$a')";

mysqli_query($connection, $sql_monthly);

echo "<script language='javascript'>window.location='students.php?pg=register&block=3';</script>";

}?> 
 
<form name="form1" method="post" action="">
  <table width="900" border="0">
    <tr>
      <td width="350">Which grade are you enrolling?:</td>
      <td width="332">Shift:</td>
      <td width="204">Special Care:</td>
    </tr>
    <tr>
      <td>
      <select name="grade_year" id="grade_year">
      <?php
      $sql_4 = "SELECT * FROM courses";
	  $result = mysqli_query($connection, $sql_4);
	  	while($res_1 = mysqli_fetch_assoc($result)){
	  ?>  
        <option value="<?php echo $res_1['course']; ?>"><?php echo $res_1['course']; ?></option>
      <?php } ?>
      </select>
      </td>
      <td><label for="shift"></label>
        <select name="shift" size="1" id="shift">
          <option value="Morning">Morning</option>
          <option value="Afternoon">Afternoon</option>
          <option value="Evening">Evening</option>
      </select></td>
      <td><label for=""></label>
        <select name="extra_service" size="1" id="extra_service">
          <option value="YES">YES</option>
          <option value="NO">NO</option>
      </select></td>
    </tr>
    <tr>
      <td>Fee:</td>
      <td>Due Date:</td>
      <td>Billing Phone:</td>
    </tr>
    <tr>
      <td><label for="fee"></label>
      <input type="text" name="fee" id="fee"></td>
      <td><label for="due_date"></label>
      <input type="text" name="due_date" id="due_date"></td>
      <td><label for="collection_phone"></label>
      <input type="text" name="collection_phone" id="collection_phone"></td>
    </tr>
    <tr>
      <td>Observations for this student</td>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
    </tr>
    <tr>
      <td colspan="3"><label for="obs"></label>
      <textarea name="obs" id="obs" cols="45" rows="5"></textarea></td>
    </tr>
    <tr>
      <td><input class="input" type="submit" name="button" id="button" value="Finish"></td>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
    </tr>
  </table>
</form>
<br />
 
</div><!-- register_students -->


<?php }// Closing Block 2 ?>


<?php if(@$_GET['block'] == '3'){ ?>
<div id="register_student">
 <h1>Third Step - Confirmation Message</h1>
 <table>
<tr>
<td>
<h4>This student has been registered in our system.
<ul>
 <li>It will be generated a collection bill monthly in the amount informed </li>
 <li>This student already has access to the system using their code and their PPS as a password</li>
</ul>
<a href="students.php?pg=all">Click it to go home page</a>
</h4>
</td>
</tr>
</table>
<br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br />
</div><!-- register_student -->


<?php }// Closing Block 3 ?>


<?php }// Closing PG register ?>




<?php require "footer.php"; ?>
</body>
</html>