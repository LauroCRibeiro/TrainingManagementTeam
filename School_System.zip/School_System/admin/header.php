<? $actual_panel = "admin";?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<?php require "../config.php"; ?>
<link href="css/header.css" rel="stylesheet" type="text/css" />
<script language="javascript" src="../js/jquery-1.7.2.min.js"></script>
<script src="../js/lightbox.js"></script>
<link href="../css/lightbox.css" rel="stylesheet" />


<link rel="stylesheet" href="../jquery.superbox.css" type="text/css" media="all" />
	<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.3.2/jquery.min.js"></script>

	<script type="text/javascript" src="../jquery.superbox-min.js"></script>
	<script type="text/javascript">

		$(function(){

			$.superbox.settings = {

				closeTxt: "Close",

				loadTxt: "Loading...",

				nextTxt: "Next",

				prevTxt: "Previous"

			};

			$.superbox();

		});

	</script>
   
</head>

<body>
<div id="header_box">
 
 <div id="logo">
  <img src="../img/logo.jpg" width="250"/>
 </div><!-- logo -->

 <div id="search_camp">

  <form name="" method="post" action="" enctype="multipart/form-data">
   <input type="text" name="key" /><input class="input" type="submit" name="search" value="" />
  </form>
  
  
  <?php if(isset($_POST['search'])){
   
 $key = $_POST['key'];
 if($key == ''){
   echo "<script language='javascript'>window.alert('Type Something to research');</script>";
 }else{
   echo "<script language='javascript'>window.location='research_result.php?q=$key';</script>";     
 }}?>
  
  
 </div><!-- search_camp -->

 
 <div id="show_login">
  <h1><strong>Welcome <i><?php echo @$name; ?> </i>- Your Code is: <?php echo @$code; ?></strong> <strong><a href="../config.php?pg=logout" >Log out</a></strong></h1>
 </div><!-- show_login -->
</div><!-- header_box -->

<div id="box_menu">
 
 <div id="header_menu">
  <ul>
   <img src="img/separador_menu.png" />
   <li><a href="index.php">HOME</a></li>
   <img src="img/separador_menu.png" />
   <li><a href="">COURSES AND DISCIPLINES</a>
    <ul>
     <li><a href="courses_and_disciplines.php?pg=course">Register Course</a></li>
     <li><a href="courses_and_disciplines.php?pg=discipline">Register Discipline</a></li>
     <li><a href="courses_and_disciplines.php?pg=coursesanddisciplines">Courses & Disciplines</a></li>
    </ul>
   </li>
   <img src="img/separador_menu.png" />
   <li><a href="teachers.php?pg=all">Teacher</a></li>   
   <img src="img/separador_menu.png" />
   <li><a href="students.php?pg=all">Students</a></li>
   <img src="img/separador_menu.png" />
   <li><a href="finance_sector.php">Finance</a></li>
   <img src="img/separador_menu.png" />
   <li><a href="">REPORTS</a>
    <ul>
    <li><a href="reports.php?type=students&s=<?php echo base64_encode("SELECT * FROM students WHERE name != ''"); ?>">Students</a></li>
     <li><a href="reports.php?type=teachers&s=<?php echo base64_encode("SELECT * FROM disciplines"); ?>">Teachers</a></li>
     <li><a href="cash_flow.php?&s=<?php echo base64_encode("WHERE m = ".date("m")." AND a = ".date("Y").""); ?>">Cash Flow</a></li>
    </ul>
   </li>
   <img src="img/separador_menu.png" />
   <li><a href="technical_support.php">Technical Support</a></li>
   <img src="img/separador_menu.png" />
   <li><a href="">EXTRAS</a>
    <ul>
    <li><a href="staff.php?pg=all">Staff</a></li>
    </ul>
   </li>
   <img src="img/separador_menu.png" />   
  </ul>
 </div><!-- header_menu -->

</div><!-- box_menu -->
</body>
</html>