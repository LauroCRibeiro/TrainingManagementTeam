<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link href="css/reports.css" rel="stylesheet" type="text/css" />
<title>Management</title>
</head>

<body>
<?php require "header.php"; ?>
<div id="black_box">
</div><!-- black_box -->

<div id="box">
<?php if(@$_GET['type'] == 'students'){ ?>
<h1>Student Reports</h1> 
<?php if(isset($_POST['button'])){

$type = $_POST['type'];
$year_grade = $_POST['year_grade'];

$s = base64_encode("SELECT * FROM students WHERE status = '$type' AND year_grade = '$year_grade'");

echo "<script language='javascript'>window.location='reports.php?type=students&s=$s';</script>";

}?>
<form name="button" method="post" action="" enctype="multipart/form-data">
<table width="950" border="0">
  <tr>
    <td width="267"><strong>Status</strong></td>
    <td width="248"><strong>Year Grade</strong></td>
    <td width="180">&nbsp;</td>
  </tr>
  <tr>
    <td><select name="type" size="1" id="select">
      <option value="Active">Active Students</option>
      <option value="Inactive">Inactive Students</option>
    </select></td>
    <td>
      <select name="year_grade" id="select2">
      <?php
      $sql_2 = mysqli_query($connetion, "SELECT * FROM courses");
	  	while($res_2 = mysqli_fetch_assoc($sql_2)){
	  ?>
       <option value="<?php echo $res_2['course']; ?>"><?php echo $res_2['course']; ?></option>      
       <?php } ?>
      </select>
    </td>
    <td><input class="input" type="submit" name="button" id="button" value="Filter"></td>
  </tr>
</table>
</form>

<?php 
$s = base64_decode($_GET['s']);
$sql_1 = mysqli_query($connection, $s);
if(mysqli_num_rows($sql_1) == ''){
	echo "There is no results for this filter";
}else{
?>
<table width="950" border="0">
  <tr>
    <td width="200"><strong>Name:</strong></td>
    <td width="130"><strong>Enrollment Number:</strong></td>
    <td width="155"><strong>Year Grade:</strong></td>
    <td width="194"><strong>Paid Fees:</strong></td>
    <td width="149"><strong>Owed Fees:</strong></td>
  </tr>
  <?php while($res_1 = mysqli_fetch_assoc($sql_1)){ ?>
  <tr>
    <td><?php echo $res_1['name']; ?></td>
    <td><?php echo $res_1['code']; ?></td>
    <td><?php echo $res_1['year_grade']; ?></td>
    <td><?php echo mysqli_num_rows(mysqli_query($connection, "SELECT * FROM fees WHERE enrollment = ".$res_1['code']." AND status = 'Unconfirmed Payment'")); ?></td>
    <td><?php echo mysqli_num_rows(mysqli_query($connection, "SELECT * FROM fees WHERE enrollment = ".$res_1['code']." AND status = 'Payment on hold'")); ?></td>
  </tr>
  <tr>
    <td colspan="5"><hr></td>
  </tr>
  <?php } ?>
  <tr>
   <td align="center" colspan="5"><a target="_blank" href="print_student_payment.php?s=<?php echo $_GET['s']; ?>">Print Student Details</a></td>
  </tr>
</table>
<?php } ?>



<?php }// closing pg students ?>



<?php if(@$_GET['type'] == 'teachers'){ ?>
<h1>Teacher Reports</h1> 

<?php if(isset($_POST['button'])){

$type = $_POST['type'];
$discipline = $_POST['discipline'];

$sql_3 = mysqli_query($connection, "SELECT * FROM teachers WHERE status = '$type'");
if(mysqli_num_rows($sql_3) == ''){
echo "<script language='javascript'>window.location='reports.php?type=teachers&s=not_found';</script>";
}else{
	while($res_3 = mysqli_fetch_assoc($sql_3)){

$s = base64_encode("SELECT * FROM disciplines WHERE course = '$discipline'");

echo "<script language='javascript'>window.location='reports.php?type=teachers&s=$s';</script>";

}}}?>
<form name="button" method="post" action="" enctype="multipart/form-data">
<table width="950" border="0">
  <tr>
    <td width="330"><strong>Status:</strong></td>
    <td width="151"><strong>Course:</strong></td>
    <td width="244">&nbsp;</td>
  </tr>
  <tr>
    <td><select name="type" size="1" id="select">
      <option value="Active">Active Teachers</option>
      <option value="Inactive">Inactive Teacher</option>
    </select></td>
    <td><select name="discipline" id="discipline">
      <?php
      $sql_2 = mysqli_query($connection, "SELECT * FROM disciplines");
	  	while($res_2 = mysqli_fetch_assoc($sql_2)){
	  ?>
      <option value="<?php echo $res_2['course']; ?>"><?php echo $res_2['course']; ?></option>
      <?php } ?>
    </select></td>
    <td><input class="input" type="submit" name="button" id="button" value="Filter"></td>
  </tr>
</table>
</form>

<?php

$s = base64_decode($_GET['s']);

$sql_1 = mysqli_query($connection, $s);
if(mysqli_num_rows($sql_1) == '') { 
	
	echo "There is no result for this filter!";
}else{
?>
<table width="950" border="0">
  <tr>
    <td width="200"><strong>Discipline/Course:</strong></td>
    <td width="70"><strong>Code:</strong></td>
    <td width="150"><strong>Name</strong></td>
    <td width="180"><strong>Graduation:</strong></td>
    <td width="105"><strong>Wage:</strong></td>
  </tr>
<?php while($res_1 = mysqli_fetch_assoc($sql_1)){ ?>  
  <tr>
    <td><?php
			echo $res_1['discipline'];
			echo " - ";
			echo $res_1['course'];
			
	?></td>
    <td><?php echo $res_1['teacher']; ?></td>
    <td><?php
    $sql_1_extra = mysqli_query($connection, "SELECT * FROM teachers WHERE code = ".$res_1['teacher']."");
		while($res_extra = mysqli_fetch_assoc($sql_1_extra)){
	
	?>
    <?php echo $res_extra['name']; ?></td>
    <td><?php echo $res_extra['leaving_certificate']; ?>/<?php echo $res_extra['graduation']; ?></td>
    <td> <?php echo($res_extra['wage']); ?></td>
  </tr>
  <?php } ?>
  <tr>
    <td colspan="6"><hr></td>
  </tr>
<?php } ?>  
  <tr>
   <td align="center" colspan="6"><a target="_blank" href="print_teacher_payment.php?s=<?php echo $_GET['s']; ?>">Print Full List</a></td>
  </tr>
</table>
<?php } ?>


<?php }// Closing teacher PG ?>






</div><!-- box -->





<?php require "footer.php"; ?>
</body>
</html>