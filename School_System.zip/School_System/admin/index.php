﻿<?php $actual_panel = "admin"; ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link rel="stylesheet" type="text/css" href="css/index.css"/>
<title>Management Panel</title>

</head>

<body>
<?php require "header.php"; ?>

<div id="black_box">
</div><!-- black_box -->

<div id="box">
 <div id="reports">
 <?php
 
 $d = date("d");
 $m = date("m");
 $y = date("Y");
 
 ?>
   <ul>
    <h1><strong>Courses and Disciplines</strong></h1>
    <li><strong>Number of Registered Courses:</strong> <?php echo mysqli_num_rows(mysqli_query($connection, "SELECT * FROM courses")); ?>  </li>
    <li><strong>Number of Registered Disciplines:</strong> <?php echo mysqli_num_rows(mysqli_query($connection, "SELECT * FROM disciplines")); ?>  </li>
   </ul>
   
   <ul>
    <h1><strong>Teachers</strong></h1>
    <li><strong>Active Teachers:</strong> <?php echo mysqli_num_rows(mysqli_query($connection, "SELECT * FROM teachers WHERE status = 'Active'")); ?></li>
    <li><strong>Inactive Teachers:</strong> <?php echo mysqli_num_rows(mysqli_query($connection, "SELECT * FROM teachers WHERE status = 'Inactive'")); ?></li>
   </ul> 
   
   <ul>
    <h1><strong>Students</strong></h1>
    <li><strong>Active Students:</strong> <?php echo mysqli_num_rows(mysqli_query($connection, "SELECT * FROM students WHERE status = 'Active'")); ?></li>
    <li><strong>Inactive Students:</strong> <?php echo mysqli_num_rows(mysqli_query($connection, "SELECT * FROM students WHERE status = 'Inactive'")); ?></li>
   </ul> 
   
   <ul>
    <h1><strong>Finance Sector</strong></h1>
    <li><strong>Charges generated this month:</strong> <?php echo mysqli_num_rows(mysqli_query($connection, "SELECT * FROM fees WHERE month = '$m' AND year = '$y'")); ?></li>
    <li><strong>Payed Bills:</strong>  <?php echo mysqli_num_rows(mysqli_query($connection, "SELECT * FROM fees WHERE month = '$m' AND year = '$y' AND status = 'Payment confirmed'")); ?></li>
    <li><strong>Not Paid Bills:</strong> <?php echo mysqli_num_rows(mysqli_query($connection, "SELECT * FROM fees WHERE month = '$m' AND year = '$y' AND status = 'Payment on hold'")); ?></li>
   </ul>  
   
   <ul>
    <h1><strong>Technical Support</strong></h1>
    <li><strong>Contacts still waiting for a response:</strong> <?php echo mysqli_num_rows(mysqli_query($connection, "SELECT * FROM central_message WHERE status = 'Response on hold'")); ?></li>
    <li><strong>Replied Contacts:</strong><?php echo mysqli_num_rows(mysqli_query($connection, "SELECT * FROM central_message WHERE status = 'Replied'")); ?></li>
    <li><strong>Total Contacts:</strong> <?php echo mysqli_num_rows(mysqli_query($connection, "SELECT * FROM central_message")); ?></li>
   </ul>        
 </div><!-- reports -->
 
 
 <div id="notifications">
  <h1>Notifications</h1>
  <div id="notifications_warning">
   <ul>
   <?php
   $sql_1 = mysqli_query($connection, "SELECT * FROM coordination_wall ORDER BY id DESC");
   if($sql_1 == ''){
	   echo "No news at the moment, stay tuned!";
   }else{
	   while($res_1 = mysqli_fetch_assoc($sql_1)){
   ?>
    <li><h1><?php echo $res_1['title']; ?></h1></li>
    <?php }} ?>
   </ul>
  </div><!-- notifications_warning -->
 </div><!-- notifications -->
 
 
</div><!-- box -->


<?php require "footer.php"; ?>
</body>
</html>