﻿<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Print</title>
<link rel="stylesheet" type="text/css" href="css/reports.css"/>
</head>


<body>
<script language="javascript">
window.print() 
</script>
<div id="box">
<?php
require "../config.php"; 

$s = base64_decode($_GET['s']);

$sql_1 = mysqli_query($connection, $s);
if(mysqli_num_rows($sql_1) == ''){
	echo "There is nothing to print!";
}else{
?>
<table width="950" border="0">
  <tr>
    <td width="200"><strong>Discipline/Course:</strong></td>
    <td width="70"><strong>Code:</strong></td>
    <td width="150"><strong>Name</strong></td>
    <td width="180"><strong>Graduation:</strong></td>
    <td width="105"><strong>Wage:</strong></td>
  </tr>
<?php while($res_1 = mysqli_fetch_assoc($sql_1)){ ?>  
  <tr>
    <td><?php
			echo $res_1['discipline'];
			echo " - ";
			echo $res_1['course'];
			
	?></td>
    <td><?php echo $res_1['teacher']; ?></td>
    <td><?php
    $sql_1_extra = mysqli_query($connection, "SELECT * FROM teachers WHERE code = ".$res_1['teacher']."");
		while($res_extra = mysqli_fetch_assoc($sql_1_extra)){
	
	?>
    <?php echo $res_extra['name']; ?></td>
    <td><?php echo $res_extra['leaving_certificate']; ?>/<?php echo $res_extra['graduation']; ?></td>
    <td> <?php echo ($res_extra['wage']);  ?></td>
  </tr>
  <?php } ?>
  <tr>
    <td colspan="6"><hr></td>
  </tr>
<?php } ?>  
</table>
<?php } ?>

</div><!-- box -->
</body>
</html>