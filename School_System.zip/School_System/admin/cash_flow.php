<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link href="css/finance_sector.css" rel="stylesheet" type="text/css" />
<title>Management</title>
</head>

<body>
<?php require "header.php"; ?>
<div id="black_box">
</div><!-- black_box -->


<div id="box_student">
<h1>Cash Flow</h1>
<a class="a" href="cash_flow.php?s=<?php echo base64_encode("WHERE m = ".date("m")." AND a = ".date("Y").""); ?>&action=launch">REGISTER INFORMATION</a>


<?php if(@$_GET['action'] == 'launch'){ ?>

<?php if(isset($_POST['button'])){

$date = $_POST['date'];
$type = $_POST['type'];
$details = $_POST['details'];
$value = $_POST['value'];
$form = $_POST['form'];

$d = date("d");
$m = date("m");
$y = date("Y");
$full_date = date("d/m/Y H:i:s");

$sql_6 = mysqli_query($connection, "INSERT INTO cash_flow (status, type, d, m, a, full_date, date, code, details, value, payment_methods) VALUES ('Active', '$type', '$d', '$m', '$y', '$full_date', '$date', 'Uninformed', '$details', '$value', '$form')");

$s = $_GET['s'];

echo "<script language='javascript'>
window.alert('information successfully launched');
window.location='cash_flow.php?s=$s';</script>';
</script>";

}?>

<form name="button" method="post" action="" enctype="multipart/form-data">
<table width="950" border="0">
  <tr>
    <td width="168">Event Date</td>
    <td width="168">Type</td>
    <td width="181">Details</td>
    <td width="90">Value</td>
    <td width="90">Payment Methods</td>
  </tr>
  <tr>
    <td><label for="textfield"></label>
    <input class="input" type="text" name="date" id="textfield" value="<?php echo date("d/m/Y"); ?>"></td>
    <td><label for="select"></label>
      <select name="type" size="1" id="select">
        <option value="CREDIT">CREDIT</option>
        <option value="DEBIT">DEBIT</option>
    </select></td>
    <td><label for="textfield3"></label>
    <input class="input" name="details" type="text" id="textfield3"></td>
    <td><label for="textfield4"></label>
    <input class="input" type="text" name="value" id="textfield4"></td>
    <td><label for="select2"></label>
      <select name="form" size="1" id="select2">
        <option value="Cash">Cash</option>
        <option value="Cheque">Cheque</option>
        <option value="Bank Transfer">Bank Transfer</option>
        <option value="Lodgement">Lodgement</option>
        <option value="Credit card">Credit Card</option>
        <option value="Debit Card">Debit Card</option>
    </select></td>
  </tr>
  <tr>
    <td><input type="submit" name="button" id="button" value="Launch"></td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
</table>
<form>

<hr />

<?php } ?>



<?php if(isset($_POST['filter'])){

$day = $_POST['day'];
$month = $_POST['month'];
$year = $_POST['year'];
$type = $_POST['type'];

if($type == 'All'){
$s = base64_encode("WHERE d = '$day' AND m = '$month' AND a = '$year'");
echo "<script language='javascript'>window.location='cash_flow.php?s=$s';</script>";
}else{
$s = base64_encode("WHERE d = '$day' AND m = '$month' AND a = '$year' AND type = '$type'");
echo "<script language='javascript'>window.location='cash_flow.php?s=$s';</script>";
 }
}?>

<form name="" method="post" action="" enctype="multipart/form-data">
<table width="950" border="0">
  <tr>
    <td colspan="4"><h2><strong>Select Filter</strong></h2></td>
  </tr>
  <tr>
    <td width="144"><strong>Report Day</strong></td>
    <td width="144"><strong>Report Month</strong></td>
    <td width="144"><strong>Report Year</strong></td>
    <td width="84"><strong>Report Type</strong></td>
  </tr>
  <tr>
    <td><input class="input2" type="text" name="day"></td>
    <td><input class="input2" type="text" name="month"></td>
    <td><input class="input2" type="text" name="year"?></td>
    <td><select name="type" size="1" id="select4">
      <option value="All">All</option>
      <option value="CREDIT">Credit</option>
      <option value="DEBIT">Debit</option>
    </select></td>
    <td width="412"><input type="submit" class="" name="filter" value="FILTER" /></td>
  </tr>
</table>
</form>
<?php

$s = base64_decode($_GET['s']);

 $sql_1 = mysqli_query($connection, "SELECT * FROM cash_flow $s");
if(mysqli_fetch_assoc($sql_1) == ''){
	echo "No filter has been found during your search.";
}else{

?>

 <table width="950" border="0">
  <tr>
    <td width="130"><strong>Date:</strong></td>
    <td width="85"><strong>Type:</strong></td>
    <td width="100"><strong>Code:</strong></td>
    <td width="400"><strong>Details:</strong></td>
    <td width="81"><strong>Value:</strong></td>
    <td width="124"><strong>Receipt:</strong></td>
  </tr>
  <tr>
    <td colspan="7"><hr></td>
  </tr>
  <?php while($res_1 = mysqli_fetch_assoc($sql_1)){ ?>
  <tr>
    <td><?php echo $res_1['full_date']; ?></td>
    <td><?php echo $res_1['type']; ?></td>
    <td width="111"><?php echo $res_1['code']; ?></td>
    <td><?php echo $res_1['details']; ?></td>
    <td> <?php echo ($res_1['value']); ?></td>
    <td><?php echo $res_1['payment_methods']; ?></td>
    <td width="17">&nbsp;</td>
    <td width="31">&nbsp;</td>
  </tr>
  <tr>
    <td colspan="7"><hr></td>
  </tr>
  <?php } ?>
  <tr>
    <td colspan="7">&nbsp;</td>
  </tr>
  <tr>
    <td colspan="7"><strong>CASH FLOW RESUME:</strong>
      <hr /></td>
  </tr>
  <tr>
    <td colspan="2"><strong>CREDITS:</strong></td>
    <td width="111"><strong>DEBITS:</strong></td>
    <td colspan="4"><strong>STATEMENT:</strong></td>
  </tr>
  <tr>
    <td colspan="2"> Euro
    <?php
    
	$sql_2 = mysqli_query($connection, "SELECT SUM(value) as addition FROM cash_flow $s AND type = 'CREDIT'");
		while($res_2 = mysqli_fetch_assoc($sql_2)){
				echo number_format($res_2["addition"],2);
			}
	
	?>
    
    </td>
    <td> 
        <?php
    
	$sql_3 = mysqli_query($connection, "SELECT SUM(value) as addition FROM cash_flow $s AND type = 'DEBIT'");
		while($res_3 = mysqli_fetch_assoc($sql_3)){
				echo number_format($res_3["addition"],2);
			}
	
	?>
    </td>
    <td colspan="4"> 
    <?php
    
		$sql_4 = mysqli_query($connection, "SELECT SUM(value) as addition FROM cash_flow $s AND type = 'CREDIT'");
		while($res_4 = mysqli_fetch_assoc($sql_4)){
			
		$sql_5 = mysqli_query($connection, "SELECT SUM(value) as addition FROM cash_flow $s AND type = 'DEBIT'");
		while($res_5 = mysqli_fetch_assoc($sql_5)){	
		
		echo number_format($res_4["addition"]-$res_5["addition"],2);
		
		}}
	
	?>
    
    </td>
  </tr>
</table>
<?php } ?>

</div><!-- box_student-->
<?php require "footer.php"; ?>
</body>
</html>