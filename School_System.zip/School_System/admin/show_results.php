﻿<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Search Details</title>
<link rel="stylesheet" type="text/css" href="css/show_results.css"/>
 <?php require "../connection.php"; ?>
</head>

<body>

<div id="box">
<?php if(@$_GET['s'] == 'teacher'){ ?>
<?php
$q = $_GET['q'];
$sql_1 = mysqli_query($connection, "SELECT * FROM teachers WHERE code = '$q'");
	while($res_1 = mysqli_fetch_assoc($sql_1)){
?>
<table width="750" border="0">
  <tr>
    <td colspan="3"><h1>Information about this teacher</h1></td>
  </tr>
  <tr>
    <td><strong>Name:</strong></td>
    <td><strong>Wage:</strong></td>
    <td><strong>PPS:</strong></td>
  </tr>
  <tr>
    <td><?php echo $res_1['name']; ?></td>
    <td><?php echo number_format($res_1['wage'],2); ?></td>
    <td><?php echo $res_1['pps']; ?></td>
  </tr>
  <tr>
    <td><strong>Leaving Certificate</strong>:</td>
    <td><strong>Graduação:</strong></td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td><?php echo $res_1['leaving_certificate']; ?></td>
    <td><?php echo $res_1['graduation']; ?></td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td><strong>Honours Bachelor:</strong></td>
    <td><strong>Masters Degree:</strong></td>
    <td><strong>Doctoral Degree:</strong></td>
  </tr>
  <tr>
    <td><?php echo $res_1['honours_degree']; ?></td>
    <td><?php echo $res_1['masters_degree']; ?></td>
    <td><?php echo $res_1['doctoral_degree']; ?></td>
  </tr>
</table>
<?php } ?>
<?php
$sql_2 = mysqli_query($connection, "SELECT * FROM disciplines WHERE teacher = '$q'");
?>
<table width="750" border="0">
  <tr>
    <td colspan="2"><h1>Academic Information</h1></td>
  </tr>
  <tr>
    <td width="404"><strong>Status: </strong> <?php echo $_GET['status']; ?></td>
    <td width="330">&nbsp;</td>
  </tr>
  <tr>
    <td><strong>Lectured Disciplines:</strong></td>
    <td><strong>Course</strong></td>
  </tr>
  <?php while($res_2 = mysqli_fetch_assoc($sql_2)){ ?>
  <tr>
    <td><?php echo $res_2['discipline']; ?></td>
    <td><?php echo $res_2['course']; ?></td>
  </tr>
 <?php } ?> 
</table>

<?php

$sql_3 = mysqli_query($connection, "SELECT * FROM cash_flow WHERE code = '$q'");
if(mysqli_num_rows($sql_3) == ''){
	echo "<h3>No payment has found</h3>";
}else{
?>

<table width="750" border="0">
  <tr>
    <td colspan="3"><h1>Payment Statement</h1></td>
  </tr>
  <tr>
    <td><strong>Payment date:</strong></td>
    <td><strong>Details:</strong></td>
    <td><strong>Payment Method:</strong></td>
  </tr>
  <?php while($res_3 = mysqli_fetch_assoc($sql_3)){ ?>
  <tr>
    <td><?php echo $res_3['date']; ?></td>
    <td><?php echo $res_3['details']; ?></td>
    <td><?php echo $res_3['payment_methods']; ?></td>
  </tr>
  <?php } ?>
</table>
<?php } ?>
<p>&nbsp;</p>
<p>&nbsp;</p>
<?php } ?>


<?php if($_GET['s'] == 'student'){ ?>
<?php
$q = $_GET['q'];
$sql_1 = mysqli_query($connection, "SELECT * FROM students WHERE code = '$q'");
	while($res_1 = mysqli_fetch_assoc($sql_1)){
?>
<table width="750" border="0">
  <tr>
    <td colspan="3"><h1>General Information</h1></td>
  </tr>
  <tr>
    <td><strong>Name:</strong></td>
    <td><strong>PPS:</strong></td>
    <td><strong>ID:</strong></td>
  </tr>
  <tr>
    <td><?php echo $res_1['name']; ?></td>
    <td><?php echo $res_1['pps']; ?></td>
    <td><?php echo $res_1['identification']; ?></td>
  </tr>
  <tr>
    <td><strong>Birthday:</strong></td>
    <td><strong>Mother:</strong></td>
    <td><strong>Father:</strong></td>
  </tr>
  <tr>
    <td><?php echo $res_1['birthday']; ?></td>
    <td><?php echo $res_1['mother']; ?></td>
    <td><?php echo $res_1['father']; ?></td>
  </tr>
  <tr>
    <td><strong>County:</strong></td>
    <td><strong>City:</strong></td>
    <td><strong>Neighborhood:</strong></td>
  </tr>
  <tr>
    <td><?php echo $res_1['county']; ?></td>
    <td><?php echo $res_1['city']; ?></td>
    <td><?php echo $res_1['neighborhood']; ?></td>
  </tr>
  <tr>
    <td><strong>Address:</strong></td>
    <td><strong>Complement:</strong></td>
    <td><strong>Postal Code:</strong></td>
  </tr>
  <tr>
    <td><?php echo $res_1['address']; ?></td>
    <td><?php echo $res_1['complement']; ?></td>
    <td><?php echo $res_1['pps']; ?></td>
  </tr>
  <tr>
    <td><strong>Residential Phone:</strong></td>
    <td><strong>Mobile:</strong></td>
    <td><strong>Friend`s contact:</strong></td>
  </tr>
  <tr>
    <td><?php echo $res_1['residential_phone']; ?></td>
    <td><?php echo $res_1['mobile']; ?></td>
    <td><?php echo $res_1['friend_contact']; ?></td>
  </tr>
  <tr>
    <td><strong>Grade Year:</strong></td>
    <td><strong>Shift:</strong></td>
    <td><strong>Special Service:</strong></td>
  </tr>
  <tr>
    <td><?php echo $res_1['year_grade']; ?></td>
    <td><?php echo $res_1['shift']; ?></td>
    <td><?php echo $res_1['special_service']; ?></td>
  </tr>
  <tr>
    <td><strong>Fee:</strong></td>
    <td><strong>Due Date:</strong></td>
    <td><strong>Collection Bill Number:</strong></td>
  </tr>
  <tr>
    <td><?php echo $res_1['fee']; ?></td>
    <td><?php echo $res_1['due_date']; ?></td>
    <td><?php echo $res_1['collection_number']; ?></td>
  </tr>
  <tr>
    <td><strong>OBS:</strong></td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td colspan="3"><?php echo $res_1['obs']; ?></td>
  </tr>
</table>
<?php } ?>


<table width="750" border="0">
  <tr>
    <td colspan="5"><h1>Academic Info</h1></td>
  </tr>
  <tr>
    <td width="248"><strong>Attendance:</strong> <?php echo mysqli_num_rows(mysqli_query($connection, "SELECT * FROM attendance_in_class WHERE student_code = '$q' AND attend = 'YES' ")); ?></td>
    <td colspan="2"><strong>Missed:</strong>  <?php echo mysqli_num_rows(mysqli_query($connection, "SELECT * FROM attendance_in_class WHERE student_code = '$q' AND attend = 'NO' ")); ?></td>
    <td colspan="2"><strong>Justified Absence:</strong>  <?php echo mysqli_num_rows(mysqli_query($connection, "SELECT * FROM attendance_in_class WHERE student_code = '$q' AND attend = 'JUSTIFIED' ")); ?></td>
  </tr>
  <tr>
    <td>
    <?php
    $sql_2 = mysqli_query($connection, "SELECT * FROM attendance_in_class WHERE student_code = '$q' AND attend = 'YES'");
		while($res_2 = mysqli_fetch_assoc($sql_2)){
				echo $res_2['date_day'];
				echo " - ";
				echo $res_2['discipline'];		
				echo "<br>";		
					
			}
	?>
    </td>
    <td colspan="2">
    <?php
    $sql_3 = mysqli_query($connection, "SELECT * FROM attendance_in_class WHERE student_code = '$q' AND attend = 'NO'");
		while($res_3 = mysqli_fetch_assoc($sql_3)){
				echo $res_3['date_day'];
				echo " - ";
				echo $res_3['discipline'];	
				echo "<br>";		
			}
	?>    
    </td>
    <td colspan="2">
    <?php
    $sql_3 = mysqli_query($connection, "SELECT * FROM attendance_in_class WHERE student_code = '$q' AND attend = 'JUSTIFIED'");
		while($res_3 = mysqli_fetch_assoc($sql_3)){
				echo $res_3['date_day'];
				echo " - ";
				echo $res_3['discipline'];	
				echo "<br>";		
			}
	?>      
    </td>
  </tr>
  <tr>
    <td colspan="5"><hr></td>
  </tr>
  <tr>
    <td colspan="5"><h2><strong>Semester Grades</strong></h2></td>
  </tr>
  <tr>
    <td><strong>Discipline:</strong></td>
    <td width="119"><strong>First Semester</strong></td>
    <td width="119"><strong>Second Semester</strong></td>
    <td width="119"><strong>Third Semester</strong></td>
    <td width="119"><strong>Forth Semester</strong></td>
    
  </tr>
 <?php
 $course = $_GET['course'];
 $sql_3 = mysqli_query($connection, "SELECT * FROM disciplines WHERE course = '$course'");
 	while($res_3 = mysqli_fetch_assoc($sql_3)){
		$discipline = $res_3['discipline'];
 ?> 
  <tr>
    <td><?php echo $res_3['discipline']; ?></td>
    <td>
    <?php
     $sql_4 = mysqli_query($connection, "SELECT * FROM assignments_grade WHERE semester = '1' AND discipline = '$discipline' AND code = '$q'");			
	 
	 	while($res_4 = mysqli_fetch_assoc($sql_4)){
				echo $res_4['grade'];
			}
	 
	?>
    </td>
    <td>
    <?php
     $sql_4 = mysqli_query($connection, "SELECT * FROM assignments_grade WHERE semester = '2' AND discipline = '$discipline' AND code = '$q'");			
	 
	 	while($res_4 = mysqli_fetch_assoc($sql_4)){
				echo $res_4['grade'];
			}
	 
	?>    
    </td>
    <td>
    <?php
     $sql_4 = mysqli_query($connection, "SELECT * FROM assignments_grade WHERE semester = '3' AND discipline = '$discipline' AND code = '$q'");			
	 
	 	while($res_4 = mysqli_fetch_assoc($sql_4)){
				echo $res_4['grade'];
			}
	 
	?>    
    </td>
    <td>
    <?php
     $sql_4 = mysqli_query($connection, "SELECT * FROM assignments_grade WHERE semester = '4' AND discipline = '$discipline' AND code = '$q'");			
	 
	 	while($res_4 = mysqli_fetch_assoc($sql_4)){
				echo $res_4['grade'];
			}

  
	?>    
    </td>
  </tr>
  <tr>
    <td colspan="5"><hr></td>
  </tr>`
  <?php } ?>
  <tr>
    <td colspan="5"><h2><strong>Extra Assignments Grades</strong></h2></td>
  </tr>
 <?php
 $course = $_GET['course'];
 $sql_3 = mysqli_query($connection, "SELECT * FROM disciplines WHERE course = '$course'");

 ?>  
  <tr>
    <td><strong>Discipline:</strong></td>
    <td colspan="4"><strong>Marks</strong></td>
  </tr>
 <?php  	while($res_3 = mysqli_fetch_assoc($sql_3)){
		$discipline = $res_3['discipline'];
 ?> 
  <tr>
    <td><?php echo $res_3['discipline']; ?></td>
    <td colspan="4">
    <?php
     $sql_4 = mysqli_query($connection, "SELECT * FROM extra_marks WHERE discipline = '$discipline' AND code = '$q'");			
	 
	 	while($res_4 = mysqli_fetch_assoc($sql_4)){
				echo $res_4['grade'];
			}
	 
	?>       
    </td>
  </tr>
  <tr>
    <td colspan="5"><hr></td>
  </tr>
<?php } ?>  
  <tr>
    <td colspan="5"><h2><strong>Exam Grades</strong></h2></td>
  </tr>
  <tr>
    <td><strong>Discipline:</strong></td>
    <td><strong>First Semester</strong></td>
    <td><strong>Second Semester</strong></td>
    <td><strong>Third Semester</strong></td>
    <td><strong>Fourth Semester</strong></td>
  </tr>
 <?php
 $course = $_GET['course'];
 $sql_3 = mysqli_query($connection, "SELECT * FROM disciplines WHERE course = '$course'");
 	while($res_3 = mysqli_fetch_assoc($sql_3)){
		$discipline = $res_3['discipline'];
 ?> 
  <tr>
    <td><?php echo $res_3['discipline']; ?></td>
    <td>
    <?php
     $sql_4 = mysqli_query($connection, "SELECT * FROM exam_grades WHERE semester = '1' AND discipline = '$discipline' AND code = '$q'");			
	 
	 	while($res_4 = mysqli_fetch_assoc($sql_4)){
				echo $res_4['grade'];
			}
	 
	?>
    </td>
    <td>
    <?php
     $sql_4 = mysqli_query($connection, "SELECT * FROM exam_grades WHERE semester = '2' AND discipline = '$discipline' AND code = '$q'");			
	 
	 	while($res_4 = mysqli_fetch_assoc($sql_4)){
				echo $res_4['grade'];
			}
	 
	?>    
    </td>
    <td>
    <?php
     $sql_4 = mysqli_query($connection, "SELECT * FROM exam_grades WHERE semester = '3' AND discipline = '$discipline' AND code = '$q'");			
	 
	 	while($res_4 = mysqli_fetch_assoc($sql_4)){
				echo $res_4['grade'];
			}
	 
	?>    
    </td>
    <td>
    <?php
     $sql_4 = mysqli_query($connection, "SELECT * FROM exam_grades WHERE semester = '4' AND discipline = '$discipline' AND code = '$q'");			
	 
	 	while($res_4 = mysqli_fetch_assoc($sql_4)){
				echo $res_4['grade'];
			}
	 
	?>    
    </td>
  </tr>
  <tr>
    <td colspan="5"><hr></td>
  </tr>`
  <?php } ?>
  <tr>
    <td colspan="5"><h2><strong>Observation Notes</strong></h2></td>
  </tr>
  <tr>
    <td><strong>Discipline:</strong></td>
    <td><strong>First Semester</strong></td>
    <td><strong>Second Semester</strong></td>
    <td><strong>Third Semester</strong></td>
    <td><strong>Fourth Semester</strong></td>
  </tr>
 <?php
 $course = $_GET['course'];
 $sql_3 = mysqli_query($connection, "SELECT * FROM disciplines WHERE course = '$course'");
 	while($res_3 = mysqli_fetch_assoc($sql_3)){
		$discipline = $res_3['discipline'];
 ?> 
  <tr>
    <td><?php echo $res_3['discipline']; ?></td>
    <td>
    <?php
     $sql_4 = mysqli_query($connection, "SELECT * FROM observations_notes WHERE semester = '1' AND discipline = '$discipline' AND id = '$q'");			
	 
	 	while($res_4 = mysqli_fetch_assoc($sql_4)){
				echo $res_4['details'];
			}
	 
	?>
    </td>
    <td>
    <?php
     $sql_4 = mysqli_query($connection, "SELECT * FROM observations_notes WHERE semester = '2' AND discipline = '$discipline' AND id = '$q'");			
	 
	 	while($res_4 = mysqli_fetch_assoc($sql_4)){
				echo $res_4['details'];
			}
	 
	?>    
    </td>
    <td>
    <?php
     $sql_4 = mysqli_query($connection, "SELECT * FROM observations_notes WHERE semester = '3' AND discipline = '$discipline' AND id = '$q'");			
	 
	 	while($res_4 = mysqli_fetch_assoc($sql_4)){
				echo $res_4['details'];
			}
	 
	?>    
    </td>
    <td>
    <?php
     $sql_4 = mysqli_query($connection, "SELECT * FROM observations_notes WHERE semester = '4' AND discipline = '$discipline' AND id = '$q'");			
	 
	 	while($res_4 = mysqli_fetch_assoc($sql_4)){
				echo $res_4['details'];
			}
	 
	?>    
    </td>
  </tr>
  <tr>
    <td colspan="5"><hr></td>
  </tr>`
  <?php } ?>
  <tr>
    <td colspan="5"><h2><strong>Semester Grades</strong></h2></td>
  </tr>
  <tr>
    <td><strong>Discipline:</strong></td>
    <td><strong>First Semesters</strong></td>
    <td><strong>Second Semester</strong></td>
    <td><strong>Third Semester</strong></td>
    <td><strong>Fourth Semester</strong></td>
  </tr>
 <?php
 $course = $_GET['course'];
 $sql_3 = mysqli_query($connection, "SELECT * FROM disciplines WHERE course = '$course'");
 	while($res_3 = mysqli_fetch_assoc($sql_3)){
		$discipline = $res_3['discipline'];
 ?> 
  <tr>
    <td><?php echo $res_3['discipline']; ?></td>
    <td>
    <?php
     $sql_4 = mysqli_query($connection, "SELECT * FROM semester_grades WHERE semester = '1' AND discipline = '$discipline' AND code = '$q'");			
	 
	 	while($res_4 = mysqli_fetch_assoc($sql_4)){
				echo $res_4['grade'];
			}
	 
	?>
    </td>
    <td>
    <?php
     $sql_4 = mysqli_query($connection, "SELECT * FROM semester_grades WHERE semester = '2' AND discipline = '$discipline' AND code = '$q'");			
	 
	 	while($res_4 = mysqli_fetch_assoc($sql_4)){
				echo $res_4['grade'];
			}
	 
	?>    
    </td>
    <td>
    <?php
     $sql_4 = mysqli_query($connection, "SELECT * FROM semester_grades WHERE semester = '3' AND discipline = '$discipline' AND code = '$q'");			
	 
	 	while($res_4 = mysqli_fetch_assoc($sql_4)){
				echo $res_4['grade'];
			}
	 
	?>    
    </td>
    <td>
    <?php
     $sql_4 = mysqli_query($connection, "SELECT * FROM semester_grades WHERE semester = '4' AND discipline = '$discipline' AND code = '$q'");			
	 
	 	while($res_4 = mysqli_fetch_assoc($sql_4)){
				echo $res_4['grade'];
			}
	 
	?>    
    </td>
  </tr>
  <tr>
    <td colspan="5"><hr></td>
  </tr>`
  <?php } ?>
  <tr>
    <td colspan="5">&nbsp;</td>
  </tr>
</table>

<table width="750" border="0">
  <tr>
    <td colspan="5"><h1>Financial Info</h1></td>
  </tr>
  <tr>
    <td width="141"><strong>Bill Code:</strong></td>
    <td width="133"><strong>Status:</strong></td>
    <td width="120"><strong>Value:</strong></td>
    <td width="185"><strong>Due Date:</strong></td>
    <td width="137"><strong>Payment Method:</strong></td>
  </tr>
<?php
$sql_5 = mysqli_query($connection, "SELECT * FROM fees WHERE enrollment = '$q'");
	while($res_5 = mysqli_fetch_assoc($sql_5)){
?>  
  <tr>
    <td><?php echo $res_5['code']; ?></td>
    <td><?php echo $res_5['status']; ?></td>
    <td> <?php echo $res_5['value']; ?></td>
    <td><?php echo $res_5['payment_day']; ?></td>
    <td><?php echo $res_5['payment_methods']; ?></td>
  </tr>
  <tr>
   <td colspan="5"><hr /></td>
  </tr>
<?php } ?>  
</table>
<p>&nbsp;</p>
<p>&nbsp;</p>

<?php } ?>


<?php if($_GET['s'] == 'collect'){ ?>

<?php
$q = $_GET['code'];
$sql_1 = mysqli_query($connection, "SELECT * FROM fees WHERE code = '$q'");
	while($res_1 = mysqli_fetch_assoc($sql_1)){
	$enrollment =  $res_1['enrollment'];
$sql_2 = mysqli_query($connection, "SELECT * FROM students WHERE code = '$enrollment'");	
	while($res_2 = mysqli_fetch_assoc($sql_2)){	

?>
 <table width="950" border="0">
  <tr>
    <td colspan="4"><hr /></td>
  </tr>
  <tr>
    <td><strong>Enrollment Number:</strong></td>
    <td><strong>Student Name:</strong></td>
    <td><strong>Due Date:</strong></td>
  </tr>
  <tr>
    <td><?php echo $enrollment; ?></td>
    <td><?php echo $res_2['name']; ?></td>
    <td><?php echo $res_1['due_date']; ?></td>
  </tr>
  <tr>
    <td><strong>Value:</strong></td>
    <td><strong>Status:</strong></td>
    <td><strong>Payment due:</strong></td>
  </tr>
  <tr>
    <td>R$ <?php echo number_format($res_1['value'],2); ?></td>
    <td><?php echo $res_1['status']; ?></td>
    <td><?php echo $res_1['due_date']; ?></td>
  </tr>
  <tr>
    <td><strong>PPS:</strong></td>
    <td><strong>Course:</strong></td>
  </tr>
  <tr>
    <td><?php echo $res_2['pps']; ?></td>
    <td><?php echo $res_2['year_grade']; ?></td>
  </tr>
  <tr>
    <td><strong>Payment Method:</strong></td>
    <td><?php echo $res_1['payment_methods']; ?></td>
  </tr>
  <tr>
    <td colspan="4"><hr /></td>
  </tr>
</table>
<?php }} ?>


<?php } ?>
</div><!--box  -->

</body>
</html>