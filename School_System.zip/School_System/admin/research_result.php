<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Research Result</title>
<link href="css/search_result.css" rel="stylesheet" type="text/css" />
</head>

<body>
<?php require "header.php"; ?>
<div id="black_box">
</div><!-- black_box -->

<div id="box">

<h1>Research Result to  <?php echo $q = $_GET['q']; ?></h1>
<ul>
<?php
$sql_1 = mysqli_query($connection, "SELECT * FROM teachers WHERE code = '$q' OR name = '$q'");
if(mysqli_num_rows($sql_1) == ''){
	echo "<h2>There is no teacher found.</h2>";
}else{
	while($res_1 = mysqli_fetch_assoc($sql_1)){
		$status = $res_1['status'];
			echo "<li><a rel='superbox[iframe][800x800]' href='show_results.php?q=$q&s=teacher&status=$status'><strong>General Information about Teacher</strong><a></li>";
		}
}
?>

<?php
$sql_1 = mysqli_query($connection, "SELECT * FROM students WHERE code = '$q' OR name = '$q'");
if(mysqli_num_rows($sql_1) == ''){
	echo "<h2>No Student Has been found.</h2>";
}else{
	while($res_1 = mysqli_fetch_assoc($sql_1)){
		$course = $res_1['year_grade'];
			echo "<li><a rel='superbox[iframe][800x600]' href='show_results.php?q=$q&s=student&course=$course'><strong>General Information about Student</strong><a></li>";
		}
}
?>

<?php
$sql_1 = mysqli_query($connection, "SELECT * FROM fees WHERE code = '$q'");
if(mysqli_num_rows($sql_1) == ''){
	echo "<h2>No Charges have been found.</h2>";
}else{
	while($res_1 = mysqli_fetch_assoc($sql_1)){
			echo "<li><a rel='superbox[iframe][970x270]' href='show_results.php?q=$q&s=charge'><strong>General Information about Charges</strong><a></li>";
		}
}
?>

</ul>
</div><!-- box -->

<?php require "footer.php"; ?>
</body>
</html>