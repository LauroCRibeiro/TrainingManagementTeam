﻿<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Finance Sector</title>
<link rel="stylesheet" type="text/css" href="css/finance_sector.css"/>
</head>

<body>
<?php require "header.php"; ?>

<div id="black_box">
</div><!-- black_box -->


<div id="box_student">
<h1>Finance Sector</h1>
<?php

$d = date("d");
$m = date("m");
$a = date("Y");

?>
<table width="950" border="0">
  <tr>
    <td colspan="4"><h2><strong>Today`s Report</strong></h2></td>
  </tr>
  <tr>
    <td width="247"><strong>Payments for Today:</strong></td>
    <td width="262"><strong>Fees payed today:</strong></td>
    <td width="269"><strong>Payments on hold:</strong></td>
    <td width="154"><strong>Statement:</strong></td>
  </tr>
  <tr>
    <td><?php echo $sql_1 = mysqli_num_rows(mysqli_query($connection, "SELECT * FROM fees WHERE due_date = '$d/$m/$a'")); ?></td>
    <td><?php echo $sql_2 = mysqli_num_rows(mysqli_query($connection,"SELECT * FROM fees WHERE payment_day = '$d/$m/$a' AND status = 'Payment Confirmed'")); ?></td>
    <td><?php echo $sql_3 = mysqli_num_rows(mysqli_query($connection,"SELECT * FROM fees WHERE payment_day = '$d/$m/$a' AND status = 'Payment on hold'")); ?></td>
    <td>
    <?php
    $sql_4 = mysqli_query($connection, "SELECT SUM(value) as sum FROM fees WHERE payment_day = '$d/$m/$a' AND status = 'Payment Confirmed'");
		while($res_4 = mysqli_fetch_assoc($sql_4)){
				echo number_format($res_4["sum"],2);
			}
	?>
    </td>
  </tr>
  <tr>
    <td><strong>Amount payed in cash:</strong></td>
    <td><strong>Amount payed in debit card:</strong></td>
    <td><strong>Amount payed in credit card:</strong></td>
    <td><strong>Amount payed in cheque:</strong></td>
  </tr>
  <tr>
    <td>
	<?php $sql_5 = mysqli_query($connection, "SELECT SUM(value) as sum FROM fees WHERE payment_day = '$d/$m/$a' AND status = 'Confirmed Payment' AND payment_methods = 'Cash'");
		
		echo mysqli_num_rows($sql_5);
		echo " - ";
		
			while($res_5 = mysqli_fetch_assoc($sql_5)){
					echo number_format($res_5["sum"],2);
				}
	?>  
    </td>
    <td>
	<?php $sql_6 = mysqli_query($connection, "SELECT SUM(value) as sum FROM fees WHERE payment_day = '$d/$m/$a' AND status = 'Payment Confirmed' AND payment_methods = 'Debit Card'");
		
		echo mysqli_num_rows($sql_6);
		echo " - ";
		
			while($res_6 = mysqli_fetch_assoc($sql_6)){
					echo number_format($res_6["sum"],2);
				}
	?>      
    </td>
    <td>
	<?php $sql_7 = mysqli_query($connection, "SELECT SUM(value) as sum FROM fees WHERE payment_day = '$d/$m/$a' AND status = 'Payment Confirmed' AND payment_methods = 'Credit Card'");
		
		echo mysqli_num_rows($sql_7);
		echo " - ";
		
			while($res_7 = mysqli_fetch_assoc($sql_7)){
					echo number_format($res_7["sum"],2);
				}
	?>      
    </td>
    <td>
	<?php $sql_8 = mysqli_query($connection, "SELECT SUM(value) as sum FROM fees WHERE payment_day = '$d/$m/$a' AND status = 'Confirmed Payment' AND payment_methods = 'Cheque'");
		
		echo mysqli_num_rows($sql_8);
		echo " - ";
		
			while($res_8 = mysqli_fetch_assoc($sql_8)){
					echo number_format($res_8["sum"],2);
				}
	?>      
    </td>
  </tr>
  <tr>
    <td colspan="4"><hr></td>
  </tr>
  <tr>
    <td colspan="4"><h2><strong>Monthly Report</strong></h2></td>
  </tr>
  <tr>
    <td width="247"><strong>Monthly Fees:</strong></td>
    <td width="262"><strong>Fees paid this month:</strong></td>
    <td width="269"><strong>Payments on hold:</strong></td>
    <td width="154"><strong>Statement:</strong></td>
  </tr>
  <tr>
    <td><?php echo $sql_1 = mysqli_num_rows(mysqli_query($connection, "SELECT * FROM fees WHERE month = '$m' AND year = '$a'")); ?></td>
    <td><?php echo $sql_2 = mysqli_num_rows(mysqli_query($connection, "SELECT * FROM fees WHERE m_p = '$m' AND a_p = '$a' AND status = 'Payment Confirmed'")); ?></td>
    <td><?php echo $sql_3 = mysqli_num_rows(mysqli_query($connection, "SELECT * FROM fees WHERE m_p = '$m' AND a_p = '$a' AND status = 'Payment on hold'")); ?></td>
    <td>
    <?php
    $sql_4 = mysqli_query($connection, "SELECT SUM(value) as sum FROM fees WHERE m_p = '$m' AND a_p = '$a' AND status = 'Payment Confirmed'");
		while($res_4 = mysqli_fetch_assoc($sql_4)){
				echo number_format($res_4["sum"],2);
			}
	?>
    </td>
  </tr>
  <tr>
    <td><strong>Amount payed in Cash:</strong></td>
    <td><strong>Amount payed in Debit Card:</strong></td>
    <td><strong>Amount payed in Credit Card:</strong></td>
    <td><strong>Amount payed in Cheque:</strong></td>
  </tr>
  <tr>
    <td>
	<?php $sql_5 = mysqli_query($connection, "SELECT SUM(value) as sum FROM fees WHERE m_p = '$m' AND a_p = '$a' AND status = 'Payment Confirmed' AND payment_methods = 'Cash'");
		
		echo mysqli_num_rows($sql_5);
		echo " - ";
		
			while($res_5 = mysqli_fetch_assoc($sql_5)){
					echo number_format($res_5["sum"],2);
				}
	?>  
    </td>
    <td>
	<?php $sql_6 = mysqli_query($connection, "SELECT SUM(value) as sum FROM fees WHERE m_p = '$m' AND a_p = '$a' AND status = 'Payment Confirmed' AND payment_methods = 'Debit Card'");
		
		echo mysqli_num_rows($sql_6);
		echo " - ";
		
			while($res_6 = mysqli_fetch_assoc($sql_6)){
					echo number_format($res_6["sum"],2);
				}
	?>      
    </td>
    <td>
	<?php $sql_7 = mysqli_query($connection, "SELECT SUM(value) as sum FROM fees WHERE m_p = '$m' AND a_p = '$a' AND status = 'Payment Confirmed' AND payment_methods = 'Credit Card'");
		
		echo mysqli_num_rows($sql_7);
		echo " - ";
		
			while($res_7 = mysqli_fetch_assoc($sql_7)){
					echo number_format($res_7["sum"],2);
				}
	?>      
    </td>
    <td>
	<?php $sql_8 = mysqli_query($connection, "SELECT SUM(value) as sum FROM fees WHERE m_p = '$m' AND a_p = '$a' AND status = 'Payment Confirmed' AND payment_methods = 'Cheque'");
		
		echo mysqli_num_rows($sql_8);
		echo " - ";
		
			while($res_8 = mysqli_fetch_assoc($sql_8)){
					echo number_format($res_8["sum"],2);
				}
	?>      
    </td>
  </tr>
  <tr>
    <td colspan="4"><hr></td>
  </tr>
  <tr>
    <td colspan="4"><h2><strong>Yearly Reports</strong></h2></td>
  </tr>
  <tr>
    <td><strong>Yearly Payments:</strong></td>
    <td><strong>Fees paid in the year:</strong></td>
    <td><strong>Payments on hold:</strong></td>
    <td><strong>Statement:</strong></td>
  </tr>
  <tr>
    <td><?php echo $sql_1 = mysqli_num_rows(mysqli_query($connection,"SELECT * FROM fees WHERE year = '$a'")); ?></td>
    <td><?php echo $sql_2 = mysqli_num_rows(mysqli_query($connection, "SELECT * FROM fees WHERE a_p = '$a' AND status = 'Payment Confirmed'")); ?></td>
    <td><?php echo $sql_3 = mysqli_num_rows(mysqli_query($connection, "SELECT * FROM fees WHERE a_p = '$a' AND status = 'Payments on hold'")); ?></td>
    <td>
    <?php
    $sql_4 = mysqli_query($connection, "SELECT SUM(value) as sum FROM fees WHERE a_p = '$a' AND status = 'Payment Confirmed'");
		while($res_4 = mysqli_fetch_assoc($sql_4)){
				echo number_format($res_4["sum"],2);
			}
	?>
    </td>
  </tr>
  <tr>
    <td><strong>Amount payed by Cash:</strong></td>
    <td><strong>Amount payed by Debit Card:</strong></td>
    <td><strong>Amount payed by Credit Card:</strong></td>
    <td><strong>Amount payed by Cheques:</strong></td>
  </tr>
  <tr>
    <td>
	<?php $sql_5 = mysqli_query($connection, "SELECT SUM(value) as sum FROM fees WHERE a_p = '$a' AND status = 'Payment Confirmed' AND payment_methods = 'Cash'");
		
		echo mysqli_num_rows($sql_5);
		echo " - ";
		
			while($res_5 = mysqli_fetch_assoc($sql_5)){
					echo number_format($res_5["sum"],2);
				}
	?>  
    </td>
    <td>
	<?php $sql_6 = mysqli_query($connection, "SELECT SUM(value) as sum FROM fees WHERE a_p = '$a' AND status = 'Payment Confirmed' AND payment_methods = 'Debit Card'");
		
		echo mysqli_num_rows($sql_6);
		echo " - ";
		
			while($res_6 = mysqli_fetch_assoc($sql_6)){
					echo number_format($res_6["sum"],2);
				}
	?>      
    </td>
    <td>
	<?php $sql_7 = mysqli_query($connection, "SELECT SUM(value) as sum FROM fees WHERE a_p = '$a' AND status = 'Confirmed Payment' AND payment_methods = 'Credit Card'");
		
		echo mysqli_num_rows($sql_7);
		echo " - ";
		
			while($res_7 = mysqli_fetch_assoc($sql_7)){
					echo number_format($res_7["sum"],2);
				}
	?>      
    </td>
    <td>
	<?php $sql_8 = mysqli_query($connection, "SELECT SUM(value) as sum FROM fees WHERE a_p = '$a' AND status = 'Payment Confirmed' AND payment_methods = 'Cheque'");
		
		echo mysqli_num_rows($sql_8);
		echo " - ";
		
			while($res_8 = mysqli_fetch_assoc($sql_8)){
					echo number_format($res_8["sum"],2);
				}
	?>      
    </td>
  </tr>
</table>
 
</div><!-- box_student -->

<?php require "footer.php"; ?>
</body>
</html>