﻿<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Histórico</title>
<link rel="stylesheet" type="text/css" href="css/history_of_the_teacher.css"/>
 <?php require "../connection.php"; ?>
</head>

<body>

<div id="box">
<?php
$id = $_GET['id'];

$sql_1 = "SELECT * FROM teachers WHERE id = '$id'";
$query = mysqli_query($connection, $sql_1);
	while($res_1 = mysqli_fetch_assoc($query)){
?>
   <table width="900" border="0">
    <tr>
      <td><h2>Status:</h2></td>
      <td><h2>Wage:</h2></td>
    </tr>
    <tr>
      <td><h3><?php echo $res_1['status']; ?></h3></td>
      <td><h3><?php echo $res_1['wage']; ?></h3></td>
    </tr>
    <tr>
      <td><h2>Code:</h2></td>
      <td><h2>Name:</h2></td>
      <td><h2>PPS:</h2></td>
    </tr>
    <tr>
      <td><h3><?php echo $code = $res_1['code']; ?></h3></td>
      <td><h3><?php echo $res_1['name']; ?></h3></td>
      <td><h3><?php echo $res_1['pps']; ?></h3></td>
    </tr>
    <tr>
      <td><h2>Birthday:</h2></td>
      <td><h2>Academic Training:</h2></td>
      <td><h2>Graduation<h2></td>
    </tr>
    <tr>
      <td><h3><?php echo $res_1['birthday']; ?></h3></td>
      <td><h3><?php echo $res_1['leaving_certificate']; ?></h3></td>
      <td><h3><?php echo $res_1['graduation']; ?></h3></td>
    </tr>
    <tr>
      <td><h2>Honours Degree:</h2></td>
      <td><h2>Masters Degree:<h2></td>
      <td><h2>Doctoral Degree:</h2></td>
    </tr>
    <tr>
      <td><h3><?php echo $res_1['honours_degree']; ?></h3></td>
      <td><h3><?php echo $res_1['masters_degree']; ?></h3></td>
      <td><h3><?php echo $res_1['doctoral_degree']; ?></h3></td>
    </tr>
    <tr>
      <td><h2><strong>This teacher is able to teach:</strong> <?php $sql_2 = "SELECT * FROM disciplines WHERE teacher = '$code'";
	   $result_disc = mysqli_query($connection, $sql_2);
	   echo mysqli_num_rows($result_disc); ?></h2></td>
    </tr>
    <?php while($res_2 = mysqli_fetch_assoc($result_disc)){ ?>
    <tr>
      <td><h2>Grade:</h2></td>
      <td><h2>Discipline:</h2></td>
    </tr>
    <tr>
      <td><h3><?php echo $res_2['course']; ?></h3></td>
      <td><h3><?php echo $res_2['discipline']; ?></h3></td>
    </tr>
    <?php } ?>
  </table>
<?php } ?>  
</div><!-- box -->

</body>
</html>