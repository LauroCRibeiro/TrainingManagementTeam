<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />

<link href="css/staff.css" rel="stylesheet" type="text/css" />
<title>Management</title>
</head>

<body>
<?php require "header.php"; ?>
<div id="black_box">
</div><!-- black_box -->

<?php if(@$_GET['pg'] == 'all'){ ?>
<div id="staff_box">
<br /><br />
<a class="a2" href="staff.php?pg=register">REGISTER STAFF</a>
<br /><br />
<hr />
<h1>Staff</h1>
<?php

$sql_1 = mysqli_query($connection, "SELECT * FROM staff WHERE name != ''");
if(mysqli_num_rows($sql_1) == ''){
	echo "There is no staff registered by now";
}else{
?>
   <table width="900" border="0">
      <tr>
        <td><strong>Code:</strong></td>
        <td><strong>Name:</strong></td>
        <td><strong>Profession:</strong></td>
        <td><strong>Wage:</strong></td>
        <td><strong>Status:</strong></td>
        <td></td>
      </tr>
      <?php while($res_1 = mysqli_fetch_assoc($sql_1)){ ?>
      <tr>
        <td><?php echo $res_1['code']; ?></td>
        <td><?php echo $res_1['name']; ?></td>
        <td><?php echo $res_1['profession']; ?></td>
        <td> <?php echo number_format($res_1['wage'],2); ?> Euro</td>
        <td><?php echo $res_1['status']; ?></td>
        <td></td>
        <td>
        <a class="a" href="staff.php?pg=all&func=delete&id=<?php echo $res_1['id']; ?>"><img title="Delete Staff" src="img/deleta.jpg" width="18" height="18" border="0"></a>
        <?php if($res_1['status'] == 'Inactive'){?>
        <a class="a" href="staff.php?pg=all&func=activate&id=<?php echo $res_1['id']; ?>&code=<?php echo $res_1['code']; ?>"><img title="Reactivate Staff Access" src="../img/correto.jpg" width="20" height="20" border="0"></a>
        <?php } ?>
        <?php if($res_1['status'] == 'Active'){?>       
        <a class="a" href="staff.php?pg=all&func=inactivate&id=<?php echo $res_1['id']; ?>&code=<?php echo $res_1['code']; ?>"><img title="Inactivate Staff" src="../img/ico_bloqueado.png" width="18" height="18" border="0">		</a>
        <?php } ?>
        <a class="a" href="staff.php?pg=all&func=edit&id=<?php echo $res_1['id']; ?>"><img title="Edit Personal Information" src="../img/ico-editar.png" width="18" height="18" border="0"></a>
</td>
      </tr>
      <?php } ?>
    </table>
<br />
<?php } ?>
</div><!-- staff_box -->

<?php if(@$_GET['func'] == 'delete'){

$id = $_GET['id'];
mysqli_query($connection, "DELETE FROM staff WHERE id = '$id'");
echo "<script language='javascript'>window.location='staff.php?pg=all';</script>";
}?>

<?php if(@$_GET['func'] == 'activate'){

$id = $_GET['id'];
$code_s = $_GET['code'];
mysqli_query($connection, "UPDATE staff SET status = 'Active' WHERE id = '$id'");
mysqli_query($connection, "UPDATE  login SET status = 'Active' WHERE code = '$code_s'");
echo "<script language='javascript'>window.location='staff.php?pg=all';</script>";
}?>
<?php if(@$_GET['func'] == 'inactivate'){

$id = $_GET['id'];
$code_s = $_GET['code'];
mysqli_query($connection, "UPDATE staff SET status = 'Inactive' WHERE id = '$id'");
mysqli_query($connection, "UPDATE  login SET status = 'Inactive' WHERE code = '$code_s'");
echo "<script language='javascript'>window.location='staff.php?pg=all';</script>";
}?>

<?php } ?>
</div><!-- register_staff -->



<?php if($_GET['pg'] == 'register'){ ?>
<div id="register_staff">
<h1>Register Staff</h1>

<?php if(isset($_POST['button'])){

$code = $_POST['code'];
$name = $_POST['name'];
$pps = $_POST['pps'];
$birthday = $_POST['birthday'];
$leaving_cert = $_POST['leaving_certificate'];
$graduation = $_POST['graduation'];
$honours_degree = $_POST['honours_degree'];
$masters = $_POST['masters_degree'];
$doctoral = $_POST['doctoral_degree'];
$wage = $_POST['wage'];
$profession = $_POST['profession'];
$panel  = $_POST['panel'];

$sql_2 = mysqli_query($connection, "INSERT INTO staff (code, status, profession, name, pps, birthday, leaving_certificate, graduation, honours_degree, masters_degree, doctoral_degree, wage) VALUES ('$code', 'Active', '$profession', '$name', '$pps', '$birthday', '$leaving_cert', '$graduation', '$honours_degree', '$masters', '$doctoral', '$wage')");

if($panel != 'No access'){
mysqli_query($connection, "INSERT INTO login (status, code, password, name, panel) VALUES ('Active', '$code', '$pps', '$name', '$panel')");	
}

	echo "<script language='javascript'>window.alert('Staff Sucessfully Registered');window.location='staff.php?pg=all';</script>";

}?>


<form name="form1" method="post" action="">
  <table width="900" border="0">
    <tr>
      <td>Code:</td>
      <td>Name:</td>
      <td>PPS:</td>
    </tr>
    <tr>
      <td>
      <?php
      $sql_1 = mysqli_query($connection, "SELECT * FROM staff ORDER BY id DESC LIMIT 1");
	  if(mysqli_num_rows($sql_1) == ''){
		  $new_code = "2597418795";
	  ?>
      <input type="hidden" name="code" value="<?php echo $new_code; ?>" />
      <input type="text" name="code" id="textfield" disabled="disabled" value="<?php echo $new_code; ?>"></td>
	 <?php
      }else{
	  	while($res_1 = mysqli_fetch_assoc($sql_1)){
			$new_code = $res_1['code']+713;
	  ?>
      <input type="hidden" name="code" value="<?php echo $new_code; ?>" />
      <input type="text" name="code" id="textfield" disabled="disabled" value="<?php echo $new_code; ?>"></td>
      <?php }} ?>
      <td><label for="textfield2"></label>
      <input type="text" name="name" id="textfield2"></td>
      <td><label for="textfield3"></label>
      <input type="text" name="pps" id="textfield3"></td>
    </tr>
    <tr>
      <td>Birthday:</td>
      <td>Academic Training</td>
      <td>Graduation:</td>
    </tr>
    <tr>
      <td><label for="textfield4"></label>
      <input type="text" name="birthday" id="textfield4"></td>
      <td><label for="select"></label>
        <select name="leaving_certificate" size="1" id="select">
          <option value="Failed">Failed</option>
          <option value="Approved">Approved</option>
          <option value="Graduation Incomplete">Graduation Incomplete</option>
          <option value="Graduate">Graduate</option>
      </select></td>
      <td><input type="text" name="graduation" id="textfield5"></td>
    </tr>
    <tr>
      <td>Honours Bachelor:</td>
      <td>Masters Degree:</td>
      <td>Doctoral Degree:</td>
    </tr>
    <tr>
      <td><input type="text" name="honours_degree" id="textfield6"></td>
      <td><input type="text" name="masters_degree" id="textfield7"></td>
      <td><input type="text" name="doctoral_degree" id="textfield8"></td>
    </tr>
    <tr>
      <td>Wage:</td>
      <td>Profession:</td>
      <td>Access Type:</td>
    </tr>
    <tr>
      <td><input type="text" name="wage" id="textfield8"></td>
      <td><input type="text" name="profession" id="textfield8"></td>
      <td><select name="panel" size="1">
        <option value="No access">No access</option>
        <option value="teacher">Teacher</option>
        <option value="treasury">Treasurer</option>
        <option value="admin">Admin</option>
        <option value="concierge">Doorman</option>
      </select></td>
    </tr>
    <tr>
      <td><input class="input" type="submit" name="button" id="button" value="Register"></td>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
    </tr>





  </table>
</form>
</div><!-- register-staff -->
<?php } ?>


<?php if(@$_GET['func'] == 'edit'){ ?>
<div id="staff_box">
<h1>Edit Personal Information</h1>

<?php if(isset($_POST['button'])){
$id = $_GET['id'];
$name = $_POST['name'];
$pps = $_POST['pps'];
$birthday = $_POST['birthday'];
$leaving_cert = $_POST['leaving_certificate'];
$graduation = $_POST['graduation'];
$honours_degree = $_POST['honours_degree'];
$masters_degree = $_POST['masters_degree'];
$doctoral_degree = $_POST['doctoral_degree'];
$wage = $_POST['wage'];
$profession = $_POST['profession'];


$sql_2 = mysqli_query($connection, "UPDATE staff SET name = '$name', pps = '$pps', birthday = '$birthday', leaving_certificate = '$leaving_cert', graduation = '$graduation', honours_degree = '$honours_degree', masters_degree = '$masters_degree', doctoral_degree = '$doctoral_degree', wage = '$wage' WHERE id = '$id'");
if($sql_2 == ''){
	echo "<script language='javascript'>window.alert('Error! Try it again, Please!');window.location='';</script>";
}else{
	echo "<script language='javascript'>window.alert('Update Completed!');window.location='staff.php?pg=all';</script>";

}}?>



<?php 
$sql_1 = mysqli_query($connection, "SELECT * FROM staff WHERE id = ".$_GET['id']."");
while($res_1 = mysqli_fetch_assoc($sql_1)){
?>
<form name="form1" method="post" action="">
  <table width="900" border="0">
    <tr>
      <td>Name:</td>
      <td>PPS:</td>
      <td>Birthday:</td>
    </tr>
    <tr>
      <td><input type="text" name="name" id="textfield2" value="<?php echo $res_1['name']; ?>"></td>
      <td><label for="textfield2">
        <input type="text" name="pps" id="textfield3" value="<?php echo $res_1['pps']; ?>">
      </label></td>
      <td><label for="textfield3">
        <input type="text" name="birthday" id="textfield4" value="<?php echo $res_1['birthday']; ?>">
      </label></td>
    </tr>
    <tr>
      <td>Academic Training</td>
      <td>Graduation:</td>
      <td>Honours Bachelor:</td>
    </tr>
    <tr>
      <td><label for="textfield4">
        <select name="leaving_certificate" size="1" id="select">
          <option value="<?php echo $res_1['leaving_certificate']; ?>"><?php echo $res_1['leaving_certificate']; ?></option>
          <option value=""></option>
          <option value="Failed">Failed</option>
          <option value="Approved">Approved</option>
          <option value="Graduation Incomplete">Graduation Incomplete</option>
          <option value="Graduate">Graduate</option>
        </select>
      </label></td>
      <td><label for="select">
        <input type="text" name="graduation" id="textfield5" value="<?php echo $res_1['graduation']; ?>">
      </label></td>
      <td><input type="text" name="honours_degree" id="textfield6" value="<?php echo $res_1['honours_degree']; ?>"></td>
    </tr>
    <tr>
      <td>Masters Degree:</td>
      <td>Doctoral Degree:</td>
      <td>Wage:</td>
    </tr>
    <tr>
      <td><input type="text" name="masters_degree" id="textfield7" value="<?php echo $res_1['masters_degree']; ?>"></td>
      <td><input type="text" name="doctoral_degree" id="textfield" value="<?php echo $res_1['doctoral_degree']; ?>"></td>
      <td><input type="text" name="wage" id="textfield9" value="<?php echo $res_1['wage']; ?>"></td>
    </tr>
    <tr>
      <td>Profession:</td>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
    </tr>
    <tr>
      <td><input type="text" name="profession" id="textfield8"></td>
      <td><input class="input" type="submit" name="button" id="button" value="Update"></td>
      <td>&nbsp;</td>
    </tr>
  </table>
</form>
<?php } ?>
</div><!-- register_staff -->
<?php } ?>
<?php require "footer.php"; ?>
</body>
</html>