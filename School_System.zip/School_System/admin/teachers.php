﻿<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Teachers</title>
<link rel="stylesheet" type="text/css" href="css/teachers.css"/>
</head>

<body>
<?php require "header.php"; ?>


<!SHOW REGISTERED TEACHERS TABLE>

<div id="black_box">
</div><!-- black_box -->


<?php if(@$_GET['pg'] == 'all'){ ?>
<div id="teachers_box">
<br /><br />
<a class="a2" href="teachers.php?pg=register">Register Teacher</a>
<h1>Teacher</h1>
<?php
$sql = "SELECT * FROM teachers WHERE name != ''";
$con = mysqli_query($connection, $sql);
if(mysqli_num_rows($con) == ''){
	echo "There is no teacher registered at the moment!";
}else{
?>
    <table width="900" border="0">
      <tr>
        <td><strong>Code:</strong></td>
        <td><strong>Name:</strong></td>
        <td><strong>Discipline Number:</strong></td>
        <td><strong>Wage:</strong></td>
        <td><strong>Status:</strong></td>
        <td></td>
      </tr>
      <?php while($res_1 = mysqli_fetch_assoc($con)){ ?>
      <tr>
        <td><h3><?php echo $code = $res_1['code']; ?></h3></td>
        <td><h3><?php echo $res_1['name']; ?></h3></td>
        <td><h3><?php 
		$sql2 = "SELECT * FROM disciplines WHERE teacher = '$code'";
		echo mysqli_num_rows(mysqli_query($connection, $sql2)); ?></h3></td>
        <td><h3>R$ <?php echo $res_1['wage']; ?></h3></td>
        <td><h3><?php echo $res_1['status']; ?></h3></td>
        <td></td>
        <td>
        <a class="a" href="teachers.php?pg=all&func=delete&id=<?php echo $res_1['id']; ?>"><img title="Delete Teacher" src="img/deleta.jpg" width="18" height="18" border="0"></a>
        <?php if($res_1['status'] == 'Inactive'){?>
        <a class="a" href="teachers.php?pg=all&func=activate&id=<?php echo $res_1['id']; ?>&code=<?php echo $res_1['code']; ?>"><img title="Reactivate Teacher" src="../img/correto.jpg" width="20" height="20" border="0"></a>
        <?php } ?>
        <?php if($res_1['status'] == 'Active'){?>
        <a class="a" href="teachers.php?pg=all&func=inactivate&id=<?php echo $res_1['id']; ?>&code=<?php echo $res_1['code']; ?>"><img title="Inactivate Teacher" src="../img/ico_bloqueado.png" width="18" height="18" border="0"></a>
        <?php } ?>
        <a class="a" href="teachers.php?pg=all&func=edit&id=<?php echo $res_1['id']; ?>"><img title="Edit Personal Details" src="../img/ico-editar.png" width="18" height="18" border="0"></a>
        <a class="a" rel="superbox[iframe][930x500]" href="teacher_historical.php?id=<?php echo $res_1['id']; ?>"><img title="Teacher Historical" src="../img/visualizar16.gif" width="18" height="18" border="0"></a></td>
      </tr>
      <?php } ?>
    </table>
<?php  }?>
<br />


<!TEACHER DELETION>

<?php if(@$_GET['func'] == 'delete'){

$id = $_GET['id'];

$sql_del = "DELETE FROM teachers WHERE id = '$id'";
mysqli_query($connection, $sql_del);
echo "<script language='javascript'>window.location='teachers.php?pg=all';</script>";

}?>



<!ACTIVATE TEACHER>

<?php if(@$_GET['func'] == 'activate'){

$id = $_GET['id'];
$code = $_GET['code'];

$sql_edit1 = "UPDATE teachers SET status = 'Active' WHERE id = '$id'";
$sql_edit2 = "UPDATE login SET status = 'Active' WHERE code = '$code'";
mysqli_query($connection, $sql_edit1);
mysqli_query($connection, $sql_edit2);


echo "<script language='javascript'>window.location='teachers.php?pg=all';</script>";

}?>



<!INACTIVATE TEACHER>

<?php if(@$_GET['func'] == 'inactivate'){

$id = $_GET['id'];
$code = $_GET['code'];

$sql_edit3 = "UPDATE teachers SET status = 'Inactive' WHERE id = '$id'";
$sql_edit4 = "UPDATE login SET status = 'Inactive' WHERE code = '$code'";
mysqli_query($connection, $sql_edit3);
mysqli_query($connection, $sql_edit4);

echo "<script language='javascript'>window.location='teachers.php?pg=all';</script>";

}?>





<!EDIT TEACHER>

<?php if(@$_GET['func'] == 'edit'){ ?>
<hr />
<h1>Edit Teacher</h1>


<?php
$id = $_GET['id'];

$sql_1 = "SELECT * FROM teachers WHERE id = '$id'";
$edit = mysqli_query($connection, $sql_1);
	while($res_1 = mysqli_fetch_assoc($edit)){
?>

<?php if(isset($_POST['button'])){
$id = $_GET['id'];
$name = $_POST['name'];
$pps = $_POST['pps'];
$birthday = $_POST['birthday'];
$leaving_certificate = $_POST['leaving_certificate'];
$graduation = $_POST['graduation'];
$honours_degree = $_POST['honours_degree'];
$masters_degree = $_POST['masters_degree'];
$doctoral_degree = $_POST['doctoral_degree'];
$wage = $_POST['wage'];


$sql_2 = "UPDATE teachers SET name = '$name', pps = '$pps', birthday = '$birthday', leaving_certificate = '$leaving_certificate', graduation = '$graduation', honours_degree = '$honours_degree', masters_degree = '$masters_degree', doctoral_degree = '$doctoral_degree', wage = '$wage' WHERE id = '$id'";
$res_edit = mysqli_query($connection, $sql_2);
if($res_edit == ''){
	echo "<script language='javascript'>window.alert('Error!!! Try it again, Please!');window.location='';</script>";
}else{
	echo "<script language='javascript'>window.alert('Updated successfully');window.location='teachers.php?pg=all';</script>";

}}?>

<form name="form1" method="post" action="" enctype="multipart/form-data">
  <table width="900" border="0">
    <tr>
      <td>Name:</td>
      <td>PPS</td>
      <td>Salary:</td>
    </tr>
    <tr>
      <td><label for="textfield2"></label>
      <input type="text" name="name" id="textfield2" value="<?php echo $res_1['name']; ?>"></td>
      <td><label for="textfield3"></label>
      <input type="text" name="pps" id="textfield3" value="<?php echo $res_1['pps']; ?>"></td>
      <td><input type="text" name="wage" id="textfield8" value="<?php echo $res_1['wage']; ?>"></td>
    </tr>
    <tr>
      <td>Birthday:</td>
      <td>Academic Info:</td>
      <td>Graduation:</td>
    </tr>
    <tr>
      <td><label for="textfield4"></label>
      <input type="text" name="birthday" id="textfield4" value="<?php echo $res_1['birthday']; ?>"></td>
      <td><label for="select"></label>
        <select name="leaving_certificate" size="1" id="select">
          <option value="<?php echo $res_1['leaving_certificate']; ?>"><?php echo $res_1['leaving_certificate']; ?></option>
          <option value=""></option>
          <option value="Failed">Failed Leaving Certificate</option>
          <option value="Approved">Approved Leaving Certificate</option>
          <option value="Incomplete Graduation">Incomplete Graduation</option>
          <option value="Graduate">Graduate</option>
      </select></td>
      <td><input type="text" name="graduation" id="textfield5" value="<?php echo $res_1['graduation']; ?>"></td>
    </tr>
    <tr>
      <td>Honours Degree:</td>
      <td>Masters Degree:</td>
      <td>Doctoral Degree:</td>
    </tr>
    <tr>
      <td><input type="text" name="honours_degree" id="textfield6" value="<?php echo $res_1['honours_degree']; ?>"></td>
      <td><input type="text" name="masters_degree" id="textfield7" value="<?php echo $res_1['masters_degree']; ?>"></td>
      <td><input type="text" name="doctoral_degree" id="textfield8" value="doctoral_degree"></td>
    </tr>
    <tr>
      <td><input class="input" type="submit" name="button" id="button" value="UPDATE"></td>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
    </tr>
  </table>
<?php } ?>
</form>
<?php } ?>
<br />
</div><!-- teachers_box -->


<?php } // Closing PG for all ?>




<!REGISTER TEACHERS>

<?php if(@$_GET['pg'] == 'register'){ ?>
<div id="register_teachers">
<h1>Register New Teacher</h1>
<?php if(isset($_POST['button'])){
	
$code = $_POST['code'];
$name = $_POST['name'];
$pps = $_POST['pps'];
$birthday = $_POST['birthday'];
$leaving_certificate = $_POST['leaving_certificate'];
$graduation = $_POST['graduation'];
$honours_degree = $_POST['honours_degree'];
$masters_degree = $_POST['masters_degree'];
$doctoral_degree = $_POST['doctoral_degree'];
$wage = $_POST['wage'];

$sql_2 = "INSERT INTO teachers (code, status, name, pps, birthday, leaving_certificate, graduation, honours_degree, masters_degree, doctoral_degree, wage) VALUES ('$code', 'Active', '$name', '$pps', '$birthday', '$leaving_certificate', '$graduation', '$honours_degree', '$masters_degree', '$doctoral_degree', '$wage')";
$register = mysqli_query($connection, $sql_2);
if($register == ''){
	echo "<script language='javascript'>window.alert('Error occurred, try it again!');</script>";
}else{
	
$sql_3 = "INSERT INTO login (status, code, password, name, panel) VALUES ('Active', '$code', '$pps', '$name', 'teacher')";
$register_login = mysqli_query($connection, $sql_3);

	echo "<script language='javascript'>window.alert('Teacher successfully registered!');window.location='teachers.php?pg=all';</script>";
 }
}?>



<form name="form1" method="post" action="">
  <table width="900" border="0">
    <tr>
      <td>Code:</td>
      <td>Name:</td>
      <td>PPS:</td>
    </tr>
    <tr>
      <td>
      <?php
      $sql_4 = "SELECT * FROM teachers ORDER BY id DESC LIMIT 1";
	  $search_prof = mysqli_query($connection, $sql_4);
	  if(mysqli_num_rows($search_prof) == ''){
		  $new_code = "87415978";
	  ?>
        <input type="text" name="code" id="textfield" disabled="disabled" value="<?php echo $new_code;  ?>">
        <input type="hidden" name="code" value="<?php echo $new_code;  ?>" />
        </td>      
      <?php
	  }else{
	  	while($res_1 = mysqli_fetch_assoc($search_prof)){
			
			$new_code = $res_1['code']+$res_1['id']+741;
	  ?>
        <input type="text" name="code" id="textfield" disabled="disabled" value="<?php echo $new_code;  ?>">
        <input type="hidden" name="code" value="<?php echo $new_code;  ?>" />
        </td>
      <?php }} ?>
      <td>
      <input type="text" name="name" id="textfield2"></td>
      <td>
      <input type="text" name="pps" id="textfield3"></td>
    </tr>
    <tr>
      <td>Birthday:</td>
      <td>Academic Info:</td>
      <td>Graduation:</td>
    </tr>
    <tr>
      <td><label for="textfield4"></label>
      <input type="text" name="birthday" id="textfield4"></td>
      <td><label for="select"></label>
        <select name="leaving_certificate" size="1" id="select">
          <option value="Failed">Failed Leaving Certificate</option>
          <option value="Approved">Approved Leaving Certificate</option>
          <option value="Incomplete Graduation">Graduation Incomplete</option>
          <option value="Graduate">Graduate</option>
      </select></td>
      <td><input type="text" name="graduation" id="textfield5"></td>
    </tr>
    <tr>
      <td>Honours Degree:</td>
      <td>Masters Degree:</td>
      <td>Doctoral Degree:</td>
    </tr>
    <tr>
      <td><input type="text" name="honours_degree" id="textfield6"></td>
      <td><input type="text" name="masters_degree" id="textfield7"></td>
      <td><input type="text" name="doctoral_degree" id="textfield8"></td>
    </tr>
    <tr>
      <td>Wage:</td>
    </tr>
    <tr>
      <td><input type="text" name="wage" id="textfield8"></td>
    </tr>
    <tr>
      <td><input class="input" type="submit" name="button" id="button" value="Register"></td>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
    </tr>
  </table>
</form>
<br />
</div><!-- register_teacher -->
<?php } // Closing PG registration ?>


<?php require "footer.php"; ?>
</body>
</html>