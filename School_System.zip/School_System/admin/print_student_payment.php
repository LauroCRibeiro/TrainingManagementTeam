﻿<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Print</title>
<link rel="stylesheet" type="text/css" href="css/reports.css"/>
</head>

<body>

<div id="box">
<script language="javascript">
window.print() 
</script>

<?php 

require "../config.php"; 

$s = base64_decode($_GET['s']);
$sql_1 = mysqli_query($connection, $s);
?>
<table width="950" border="0">
  <tr>
    <td width="200"><strong>Name:</strong></td>
    <td width="130"><strong>Enrolment Number:</strong></td>
    <td width="155"><strong>Year Grade:</strong></td>
    <td width="194"><strong>Payed Fees:</strong></td>
    <td width="149"><strong>Owed Fees:</strong></td>
  </tr>
  <?php while($res_1 = mysqli_fetch_assoc($sql_1)){ ?>
  <tr>
    <td><?php echo $res_1['name']; ?></td>
    <td><?php echo $res_1['code']; ?></td>
    <td><?php echo $res_1['year_grade']; ?></td>
    <td><?php echo mysqli_num_rows(mysqli_query($connection, "SELECT * FROM fees WHERE enrollment = ".$res_1['code']." AND status = 'Payment Confirmed'")); ?></td>
    <td><?php echo mysqli_num_rows(mysqli_query($connection, "SELECT * FROM fees WHERE enrollment = ".$res_1['code']." AND status = 'Payment on hold'")); ?></td>
  </tr>
  <tr>
    <td colspan="5"><hr></td>
  </tr>
  <?php } ?>
  <tr>
  </tr>
</table>
</div><!-- box -->

</body>
</html>