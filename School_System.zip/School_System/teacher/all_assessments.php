﻿<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link rel="stylesheet" type="text/css" href="css/all_assessments.css"/>
<title>Exams</title>
</head>

<body>
<?php require "header.php"; ?>

<div id="black_box">
</div><!-- black_box -->

<div id="box">
<?php if($_GET['pg'] == 'semester_exams'){ ?>
<br /><a class="a2" rel="superbox[iframe][850x350]" href="register_exam.php?type=semester&code=<?php echo $code; ?>">Register Exam</a>
<p></p>
 <h1>Semester Exam History from your Classes</h1>
 
<?php
$sql_1 = "SELECT * FROM semester_exams WHERE teacher = '$code' ORDER BY id DESC";
$result = mysqli_query($connection, $sql_1);
if(mysqli_num_rows($result) == ''){
	 echo "<h2>There is no exam at the moment!</h2>";	 
}else{
	while($res_1 = mysqli_fetch_assoc($result)){
?> 
<table width="955" border="0">
  <tr>
    <td width="90">Exam Number</td>
    <td width="60">Status</td>
    <td width="131">Release</td>
    <td width="187">Exam Date</td>
    <td width="323">Discipline</td>
  </tr>
  <tr>
    <td><h3><?php echo $res_1['id']; ?></h3></td>
    <td><h3><?php echo $res_1['status']; ?></h3></td>
    <td><h3><?php echo $res_1['date']; ?></h3></td>
    <td><h3><?php echo $res_1['application_date']; ?></h3></td>
    <td><h3><?php echo $res_1['discipline']; ?></h3></td>
  </tr>
  <tr>
    <td><a rel="superbox[iframe][850x350]" href="edit_exam.php?id=<?php echo $res_1['id']; ?>&code=<?php echo $code; ?>">Edit</a></td>
    <td colspan="3"><a href="grade_exams.php?pg=semester_exams&id=<?php echo $res_1['id']; ?>">Grade Exam</a></td>
    <td></td>
    <td><a href="all_assessments.php?pg=delete&id=<?php echo $res_1['id']; ?>&code=<?php echo $code; ?>"><img src="../img/deleta.png" width="22" border="0" /></a></td>
  </tr>  
  </table> 
 
<?php }}}

if($_GET['pg'] == 'delete'){
	
$id = $_GET['id'];
$code = $_GET['code'];

$sql_2 = "DELETE FROM semester_exams WHERE id = '$id'";
mysqli_query($connection, $sql_2);

echo "<script language='javascript'>window.location='all_assessments.php?pg=semester_exams';</script>";

}?> 
</div><!-- box-->



<?php require "footer.php"; ?>
</body>
</html>