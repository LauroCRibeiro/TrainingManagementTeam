<? $actual_panel = "teacher";?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<?php require "../config.php"; $code; ?>
<link href="css/header.css" rel="stylesheet" type="text/css" />
<title>To Learn - Teacher Management</title>
<script language="javascript" src="../js/jquery-1.7.2.min.js"></script>
<script src="../js/lightbox.js"></script>
<link href="../css/lightbox.css" rel="stylesheet" />


<link rel="stylesheet" href="../jquery.superbox.css" type="text/css" media="all" />
  <script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.3.2/jquery.min.js"></script>

  <script type="text/javascript" src="../jquery.superbox-min.js"></script>
  <script type="text/javascript">

    $(function(){

      $.superbox.settings = {

        closeTxt: "Close",

        loadTxt: "Loading...",

        nextTxt: "Next",

        prevTxt: "Previous"

      };

      $.superbox();

    });

	</script>
    
</head>

<body>
<div id="header_box">
 
 <div id="logo">
  <img src="../img/logo.jpg" width="250" />
 </div><!-- logo -->
 
 <div id="show_login">
  <h1><strong>Hi Teacher! Your code is:</strong> <?php echo @$code; ?> <strong><a href="../config.php?pg=logout">LOG OUT</a></strong></h1>
 </div><!-- show_login -->
</div><!-- header_box -->

<div id="box_menu">
 
 <div id="menu_header">
  <ul>
   <li><a href="index.php">HOME</a></li>
   <li><a href="classes_and_students.php">Students and Classes</a></li>   
   <li><a href="">All Assessments</a>
    <ul>
     <li><a href="semester_assignments.php">Semester Assignments</a></li>
     <li><a href="all_assessments.php?pg=semester_exams">Semester Exams</a></li>
     <li><a href="extra_assignments.php">Extra Assignments</a></li>
     <li><a href="observation_notes.php">Observation Notes</a></li>
     <li><a href="technical_support.php">Technical Support</a></li>
  </ul>
 </div><!-- menu_header -->

</div><!-- box_menu -->
</body>
</html>