﻿<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Register Assignments</title>
<link rel="stylesheet" type="text/css" href="css/register_semester_assignment.css"/>
<?php require "../config.php"; ?>
</head>

<body>

<div id="box">
<?php if(isset($_POST['button'])){
	
$date = date("d/m/Y");

$semester = $_POST['semester'];
$discipline = $_POST['discipline'];
$delivery_date = $_POST['delivery_date'];
$theme = $_POST['theme'];
$details = $_POST['details'];

$sql_3 = "SELECT * FROM disciplines WHERE discipline = '$discipline'";
$result_3 = mysqli_query($connection, $sql_3);
	while($res_3 = mysqli_fetch_assoc($result_3)){
		
		$course = $res_3['course'];
		
$sql_4 = "SELECT * FROM semester_assignments WHERE course = '$course' AND discipline = '$discipline' AND semester = '$semester'";
$result_4 = mysqli_query($connection, $sql_4);
if(mysqli_num_rows($result_4) >= '1'){
	echo "<br><br><br>This Discipline Assignment is already available";
  die;

}else{
$sql_5 = "INSERT INTO semester_assignments (date, status, teacher, course, discipline, theme, details, delivery_date, semester) VALUES ('$date', 'Active', '$code', '$course', '$discipline', '$theme', '$details', '$delivery_date', '$semester')";
mysqli_query($connection, $sql_5);
$sql_6 = "INSERT INTO student_wall (date, status, course, title) VALUES ('$date', 'Active', '$course', 'Semester Assignment $discipline due to $delivery_date - to see more about go to Semester Assignments')";
mysqli_query($connection, $sql_6);

echo "<script language='javascript'>window.alert('Assignment Successfully Registered! Click Ok to register a new one!');window.location='register_semester_assignment.php';</script>";

die;
}}}?>



 <form name="send" method="post" action="" enctype="multipart/form-data">		
<table border="0">
  <tr>
    <td width="198">Assignment Number</td>
    <td width="216">Released</td>
  </tr>
  <tr>
    <td><input disabled type="text" value=""
	<?php
	
	$date = date("d/m/Y");
	
    $sql_1 = "SELECT * FROM semester_assignments ORDER BY id DESC LIMIT 1";
	$result = mysqli_query($connection, $sql_1);
	if(mysqli_num_rows($result) == ''){
		echo "1";
	}else{
		while($res_1 = mysqli_fetch_assoc($result)){
			echo $id = $res_1['id']+1;
			
							
	}}?>"></td>
    <td><input disabled type="text" value="<?php echo $date; ?>"></td>
  </tr>
  <tr>
    <td width="198">Select Semester</td>
    <td width="272">Discipline</td>
  </tr>
  <tr>
    <td>
      <select name="semester" id="discipline">
      <option value="1">First Semester</option>
      <option value="2">Second Semester</option>
      <option value="3">Third Semester</option>
      <option value="4">Fourth Semester</option>
      <option value="5">Fifth Semester</option>
      <option value="6">Sixth Semester</option>
      </select></td>
    <td><label for="discipline"></label>
      <select name="discipline" id="discipline">
      
      <?php
      $sql_2 = "SELECT * FROM disciplines WHERE teacher = '$code'";
	  $result_2 = mysqli_query($connection, $sql_2);
	  if(mysqli_num_rows($result_2) == ''){
		 ?>
      <option value=""><?php echo "There is no discipline"; ?></option>
      <?php
	  }else{
		  
		   ?>
      <option value="">Select Discipline</option>
      <?php
		  
	  	while($res_2 = mysqli_fetch_assoc($result_2)){
	  ?>
      <option value="<?php echo $res_2['discipline']; ?>"><?php echo $res_2['discipline']; ?></option>
      <?php }} ?>
      </select></td>
  </tr>  
  <tr>
    <td width="216">Due Date</td>
    <td width="272">Theme</td>
  </tr>
  <tr>
    <td><input type="text" name="delivery_date" value=""></td>
    <td><input type="text" name="theme" value=""></td>
  </tr>
  <tr>
    <td>Further Details about Assignment:</td>
  </tr>
  <tr>
    <td colspan="3"><textarea name="details" cols="" rows=""></textarea></td>
  </tr>
  <tr>
    <td><input class="input" type="submit" name="button" id="button" value="Register"></td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  </table>
  </form>
</div><!-- box -->

</body>
</html>