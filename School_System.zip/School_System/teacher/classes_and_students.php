<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link href="css/classes_and_students.css" rel="stylesheet" type="text/css" />
</head>

<body>
<?php require "header.php"; ?>
<div id="black_box">
</div><!-- black_box -->

<div id="box">
<h1>Discipline and Students history below!</h1>
<?php
 $sql_1 = "SELECT * FROM disciplines WHERE teacher = '$code'";
 $result = mysqli_query($connection, $sql_1);
if(mysqli_num_rows($result) == ''){
	echo "You Do not lecture none of these!";
}else{
	while($res_1 = mysqli_fetch_assoc($result)){
		$course = $res_1['course'];
?>	
 <table width="955" border="0">
  <tr>
    <td width="400"><strong>Discipline:</strong> <?php echo $res_1['discipline']; ?></td>
    <td width="300"><strong>Total  Discipline Student:</strong><?php 
	$sql_2 = "SELECT * FROM students WHERE year_grade = '$course'";
	echo mysqli_num_rows(mysqli_query($connection, $sql_2)); ?></td>
    <td width="123"><a href="attendance.php?course=<?php echo base64_encode($res_1['course']); ?>&dis=<?php echo base64_encode($res_1['discipline']); ?>">Start Attendance</a></td>
  </tr>
 </table>	
<?php }} ?>
</div><!-- box -->

<?php require "footer.php"; ?>
</body>
</html>