﻿<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Observation Notes</title>
<link rel="stylesheet" type="text/css" href="css/extra_assignments.css"/>
</head>

<body>
<?php require "header.php"; ?>

<div id="black_box">
</div><!-- black_box -->

<div id="box">
<br /><a class="a2" rel="superbox[iframe][850x350]" href="register_observation_note.php?code=<?php echo $code; ?>">Register Note</a>
<p></p>
 <h1>Your semester observation notes history is below!</h1>

<?php
$sql_1 = "SELECT * FROM observations_notes WHERE teacher = '$code' ORDER BY id DESC";
$result = mysqli_query($connection, $sql_1);
if(mysqli_num_rows($result) == ''){
	 echo "<h2>There is no observation note at the moment!</h2>";	 
}else{
	while($res_1 = mysqli_fetch_assoc($result)){
?>

<table width="955" border="0">
  <tr>
    <td width="60">Status</td>
    <td width="250">Course</td>
    <td width="250">Discipline</td>
    <td width="250">Semester</td>
    <td width="131">Release</td>
  </tr>
  <tr>
    <td><h3><?php echo $res_1['status']; ?></h3></td>
    <td><h3><?php echo $res_1['course']; ?></h3></td>
    <td><h3><?php echo $res_1['discipline']; ?></h3></td>
    <td><h3><?php echo $res_1['semester']; ?> Semester</h3></td>
    <td><h3><?php echo $res_1['date']; ?></h3></td>
  </tr>
  <tr>
    <td colspan="3"><a href="include_observations_notes.php?id=<?php echo $res_1['id']; ?>&course=<?php echo $res_1['course']; ?>">Include Notes</a></td>
    <td></td>
    <td><a href="observation_notes.php?pg_e=delete&id=<?php echo $res_1['id']; ?>"><img src="../img/deleta.png" width= "22" border="0" /></a></td>
  </tr>  
  </table> 
<?php }} ?> 
</div><!-- box -->

<?php if(@$_GET['pg_e'] == 'delete'){

$id = $_GET['id'];

$sql_2 = "DELETE FROM observation_notes WHERE id = '$id'";
mysqli_query($connection, $sql_2);

echo "<script language='javascript'>window.location='observation_notes.php';</script>";

}?>


<?php require "footer.php"; ?>
</body>
</html>