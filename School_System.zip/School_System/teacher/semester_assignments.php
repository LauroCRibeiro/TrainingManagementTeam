﻿<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Semester Assignments</title>
<link rel="stylesheet" type="text/css" href="css/semester_assignments.css"/>
</head>

<body>
<?php require "header.php"; ?>

<div id="black_box">
</div><!-- black_box -->

<div id="box">
<br /><a class="a2" rel="superbox[iframe][680x400]" href="register_semester_assignment.php?code=<?php echo $code; ?>">Post Assignment</a>
<p></p>
 <h1>Semester Assignments History Below!</h1>

<?php
$sql_1 = "SELECT * FROM semester_assignments WHERE teacher = '$code' ORDER BY id DESC";
$result = mysqli_query($connection, $sql_1);
if(mysqli_num_rows($result) == ''){
 echo "<h2>There is no Assignment at the moment!</h2>";	 
}else{
	while($res_1 = mysqli_fetch_assoc($result)){	
?>
 
<table width="955" border="0">
  <tr>
    <td width="90">Assignment Number</td>
    <td width="60">Status</td>
    <td width="131">Release</td>
    <td width="187">Discipline</td>
    <td width="323">Theme</td>
    <td width="129">Due Date</td>
  </tr>
  <tr>
    <td><h3><?php echo $res_1['id']; ?></h3></td>
    <td><h3><?php echo $res_1['status']; ?></h3></td>
    <td><h3><?php echo $res_1['date']; ?></h3></td>
    <td><h3><?php echo $res_1['discipline']; ?></h3></td>
    <td><h3><?php echo $res_1['theme']; ?></h3></td>
    <td><h3><?php echo $res_1['delivery_date']; ?></h3></td>
  </tr>
  <tr>
    <td><a rel="superbox[iframe][680x400]" href="edit_semester_assignment.php?id=<?php echo $res_1['id']; ?>&code=<?php echo $code; ?>">Edit</a></td>
    <td colspan="3"><a href="students_who_showed_this_assignment.php?id=<?php echo $res_1['id']; ?>&pg=semester_assignments">Students Who Delivered This Assignment</a></td>
    <td></td>
    <td><a href="semester_assignments.php?pg=delete&code=<?php echo $code; ?>&id=<?php echo $res_1['id']; ?>"><img  border="0" src="../img/deleta.png" width="22" /></a></td>
  </tr>  
  </table>

<?php }} ?>
</div><!-- box -->


<?php if(@$_GET['pg'] == 'delete'){

$id = $_GET['id'];
$code = $_GET['code'];

$sql_2 = "DELETE FROM semester_assignments WHERE id = '$id' AND teacher = '$code'";

mysqli_query($connection, $sql_2);

echo "<script language='javascript'>window.location='semester_assignments.php';</script>";

}?>


<?php require "footer.php"; ?>
</body>
</html>