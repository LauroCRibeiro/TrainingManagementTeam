﻿<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link rel="stylesheet" type="text/css" href="css/students_who_showed_this_assignment.css"/>
<title>Students / Assignments</title>
</head>

<body>
<?php require "header.php"; ?>

<div id="black_box">
</div><!-- black_box -->

<div id="box">
 <h1> Student List of who sent their Assignments</h1>
<?php  if($_GET['pg'] == 'semester_assignments'){ ?>
<?php if(isset($_POST['button'])){

$student_code = $_POST['student_code'];
$grade = $_POST['grade'];
$assignment_id = $_POST['assignment_id'];
$discipline = $_POST['discipline'];
$semester = $_POST['semester'];

$sql_3 = "UPDATE send_semester_assignments SET status = 'Accepted', grade = '$grade' WHERE id = '$assignment_id'";
mysqli_query($connection, $sql_3);

$sql_4 = "INSERT INTO extra_marks (code, semester, discipline, grade) VALUES ('$student_code', '$semester',  '$discipline', '$grade')";
mysqli_query($connection, $sql_4);

  echo "<script language='javascript'>window.window.location='';</script>";


}?>


<?php

$id = $_GET['id'];

$sql_1 = "SELECT * FROM send_semester_assignments WHERE assignment_id = '$id'";
$result = mysqli_query($connection, $sql_1);
if(mysqli_num_rows($result) == ''){
	 echo "<h2>There is no Assignments to be corrected at the moment!</h2>";	 
}else{
	while($res_1 = mysqli_fetch_assoc($result)){
		
$sql_1_extra = "SELECT * FROM extra_marks WHERE id = '$id'";
$result_2 = mysqli_query($connection, $sql_1_extra);
	while($res_1_extra = mysqli_fetch_assoc($result_2)){
?>

<form name="" method="post" action="" enctype="multipart/form-data">

<table width="955" border="0">
  <tr>
    <td width="107">Code:</td>
    <td width="302">Student`s Name:</td>
    <td width="100">Assignment:</td>
    <td width="144">Due Date:</td>
    <td width="156">Grade:</td>
    <td width="170">&nbsp;</td>
  </tr>
  <tr>

  <input type="hidden" name="student_code" value="<?php  echo $res_1['student']; ?>" />
  <input type="hidden" name="discipline" value="<?php  echo $res_1['discipline']; ?>" />
  <input type="hidden" name="assignment_id" value="<?php  echo $res_1['id']; ?>" />
  <input type="hidden" name="semester" value="<?php  echo $res_1_extra['semester']; ?>" />
    <td><h3><?php  echo $student_code = $res_1['student']; ?></h3></td>
    <td><h3>
     <?php 
     $sql_2 = "SELECT * FROM students WHERE code = '$student_code'";	 		$result_2 = mysqli_query($connection, $sql_2);
	 	while($res_2 = mysqli_fetch_assoc($result_2)){
			echo $res_2['name'];
		}
	 ?>
    </h3></td>
    <td><a href="../student_assignments/<?php  echo $res_1['assignment']; ?>" target="_blank">Ver</a></td>
    
    <td><h3><?php  echo $res_1['date']; ?></h3></td>
    
    <?php 
	if($res_1['status'] != 'On hold'){ 
	$grade = $res_1['grade'];
	echo "<td><h3>Graded - Grade: $grade</h3></td>";
	}else{
	
	?>
    <td><input name="grade" type="text" id="textfield" size="2"></td>
    <td><input type="submit" name="button" id="button" value="Finish"></td>
    <?php  } ?>
    
    <td> <a href="students_who_showed_this_assignment.php?pg=delete&id=<?php  echo $res_1['id']; ?>&id_t=<?php  echo $res_1['assignment_id']; ?>"><img src="../img/deleta.png" width="22" border="0" title="Delete Assignment" /></a></td>
    
   <?php  if($res_1['status'] != 'On hold'){ ?>
      
   <td><a href="alter_assignment_grade.php?pg=semester_assignments&id=<?php  echo $res_1['id']; ?>&student=<?php  echo $res_1['student']; ?>&discipline=<? echo $res_1['discipline']; ?>&grade=<?php  echo $res_1['grade']; ?>&semester=<?php  echo $res_1_extra['semester']; ?>" rel="superbox[iframe][400x100]"><img border="0" src="../img/ico-editar.png" title="Alter Assignment Grade" /></a></td>
   <?php  } ?>
  </tr>
</table>
</form>
<?php  }}} ?>

<?php  } ?>

<?php if(@$_GET['pg'] == 'delete'){

$id_t = $_GET['id_t'];
$id = $_GET['id'];
$sql_2 = "DELETE FROM send_semester_assignments WHERE id = '$id'";
mysqli_query($connection, $sql_2);

echo "<script language='javascript'>window.location='students_who_showed_this_assignment.php?id=$id_t&pg=semester_assignments';</script>";

}?>
</div><!-- box -->

<?php require "footer.php"; ?>
</body>
</html>