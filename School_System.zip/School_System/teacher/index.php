﻿<?php $actual_panel = "teacher"; ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Teacher Panel</title>
<link rel="stylesheet" type="text/css" href="css/index.css"/>
</head>

<body>

<?php require "header.php"; ?>

<div id="black_box">
</div><!-- black_box -->

<div id="box">
 <div id="reports">
   <ul>
    <h1><strong>Students and Classes</strong></h1>
    <li><strong>Disciplines you lecture: </strong> <?php echo mysqli_num_rows(mysqli_query($connection, "SELECT * FROM disciplines WHERE teacher = '$code'")); ?></li>
    <li><strong>You Lecture for
    
    <?php
    
  $sql_1 = mysqli_query($connection, "SELECT * FROM disciplines WHERE teacher = '$code'");
    while($res_1 = mysqli_fetch_assoc($sql_1)){
      
      $course = $res_1['course'];
  echo mysqli_num_rows(mysqli_query($connection, "SELECT * FROM students WHERE year_grade = '$course'"));
      
    }
  
  ?>
    
    students. </strong></li>
   </ul>
   
   <ul>
    <h1><strong>Registration Info</strong> </h1>
    <li><strong>Your Access Code is:</strong> <?php echo $code; ?></li>
    <li><strong>Password:</strong>***** <a rel="superbox[iframe][285x100]" href="alter_password.php?code=<?php echo $code; ?>">Change</a></li>
   </ul> 
   
   <ul>
    <h1><strong>Technical Support</strong></h1>
    <li><strong>Not Replied Messages:</strong> <?php echo mysqli_num_rows(mysqli_query($connection, "SELECT * FROM central_message WHERE receiver = '$code' AND status = 'Response on hold'")); ?></li>
    <li><strong>Replied Messages:</strong>  <?php echo mysqli_num_rows(mysqli_query($connection, "SELECT * FROM central_message WHERE receiver = '$code' AND status = 'Replied'")); ?></li>
    <li><strong>All Messages:</strong>  <?php echo mysqli_num_rows(mysqli_query($connection, "SELECT * FROM central_message WHERE receiver = '$code'")); ?></li>
   </ul> 
 </div><!-- reports -->
 
 <div id="notifications">
  <h1>Notifications</h1>
  <div id="warning_notifications">
     <ul>
   <?php
   $sql_1 = mysqli_query($connection, "SELECT * FROM central_message WHERE receiver = '$code'");
   if(mysqli_num_rows($sql_1) == ''){
     echo "You have no messages at the moment";
   }else{
    while($res_1 = mysqli_fetch_assoc($sql_1)){
   ?>
    <li><h1>New Message - <?php echo $res_1['message']; ?></h1></li>
    <?php }} ?>
   </ul>
  </div><!-- warning-notifications -->
 </div><!-- notifications -->
 
 
</div><!-- box -->

<?php require "footer.php"; ?>
</body>
</html>