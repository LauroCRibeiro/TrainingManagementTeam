﻿<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Observation Notes</title>
<link rel="stylesheet" type="text/css" href="css/grade_exams.css"/>
</head>

<body>
<?php require "header.php"; ?>

<div id="black_box">
</div><!-- black_box -->

<div id="box">
 <h1>Student List for this Discipline!</h1>

<?php if(isset($_POST['button'])){

echo $student_code = $_POST['student_code'];
$grade = $_POST['grade'];
$discipline = $_POST['discipline'];
$date = date("d/m/Y H:i:s");
$semester = $_POST['semester'];

$sql_3 = "SELECT * FROM exam_grades WHERE code = '$student_code' AND discipline = '$discipline' AND semester = '$semester'";
$result_3 = mysqli_query($connection, $sql_3);
if(mysqli_num_rows($result_3) == ''){
	echo "<script language='javascript'>window.alert('Student Semester Grades have not been graded yet, we need it to calculate the median');</script>";
}else{
	while($res_3 = mysqli_fetch_assoc($result_3)){
		
$sql_4 = "SELECT * FROM extra_grades WHERE code = '$student_code' AND discipline = '$discipline' AND semester = '$semester'";
$result_4 = mysqli_query($connection, $sql_4);
if(mysqli_num_rows($result_4) == ''){
	echo "<script language='javascript'>window.alert('Assignment Grades not been released for this student, we need it to calculate the median');</script>";
}else{
	while($res_4 = mysqli_fetch_assoc($result_4)){
		
$sql_5 = "SELECT * FROM extra_grades WHERE code = '$student_code' AND discipline = '$discipline'";
$result_5 = mysqli_query($connection, $sql_5);
if(mysqli_num_rows($result_5) == ''){


		$median = ($res_3['grade']+$res_4['grade']+$grade)/3;
		
		if($median >10){
			$median = 10;
		}else{
			$median = $median;
		}

 $sql_6 = "INSERT INTO observations_notes (code, semester, discipline, grade) VALUES ('$student_code', '$semester', '$discipline', '$grade')"; mysqli_query($connection, $sql_6);
 
 $sql_7 = "INSERT INTO semester_assignments (code, semester, discipline, grade) VALUES ('$student_code', '$semester', '$disciplines', '$median')";
 mysqli_query($connection, $sql_7);
 
 $sql_8 = "DELETE FROM extra_grades WHERE code = '$student_code' AND discipline = '$discipline'";
 mysqli_query($connection, $sql_8);

echo "<script language='javascript'>window.location='';</script>";


}else{
	while($res_5 = mysqli_fetch_assoc($result_5)){
		
		$extra_marks = $res_5['grade'];

		
		$median = ($res_3['grade']+$res_4['grade']+$extra_marks+$grade)/3;
		
		if($median >10){
			$median = 10;
		}else{
			$median = $median;
		}

 $sql_6 = "INSERT INTO observations_notes (code, semester, discipline, grade) VALUES ('$student_code', '$semester', '$discipline', '$grade')"; 
  mysqli_query($connection, $sql_6);
 
 $sql_7 = "INSERT INTO semester_assignments (code, semester, discipline, grade) VALUES ('$student_code', '$semester', '$discipline', '$median')";
  mysqli_query($connection, $sql_7);
 
 $sql_8 = "DELETE FROM extra_marks WHERE code = '$student_code' AND discipline = '$discipline'";
  mysqli_query($connection, $sql_8);

echo "<script language='javascript'>window.location='';</script>";
						
}}}}}}}?> 
 
 
 
 
 <?php
$id = $_GET['id'];
$sql_1 = "SELECT * FROM obersations_notes WHERE id = ".$_GET['id']."";
 	$result_1 = mysqli_query($connection, $sql_1);
	while($res_1 = mysqli_fetch_assoc($result_1)){
	$course = $res_1['course'];

 $sql_2 = "SELECT * FROM students WHERE status = 'Active' AND year_grade = '$course'";
 	$result_2 = mysqli_query($connection, $sql_2);
	while($res_2 = mysqli_fetch_assoc($result_2)){
 ?>

<form name="" method="post" action="" enctype="multipart/form-data">
<input type="hidden" name="student_code" value="<?php echo $res_2['code']; ?>" />
<input type="hidden" name="semester" value="<?php echo $res_1['semester']; ?>" />
<input type="hidden" name="discipline" value="<?php echo $res_1['discipline']; ?>" />
<table width="955" border="0">
  <tr>
    <td width="107"><strong>Code:</strong></td>
    <td width="302"><strong>Student Name:</strong></td>
    <td width="302"><strong>Discipline:</strong></td>
    <td width="156"><strong>Grade:</strong></td>
    <td width="170">&nbsp;</td>
  </tr>
  <tr>
    <td><h3><?php echo $res_2['code']; ?></h3></td>
    <td><h3><?php echo $res_2['name']; ?></h3></td>
    <td><h3><?php echo $res_1['discipline']; ?></h3></td>
    
    <?php
	
	$student_code = $res_2['code'];
	$discipline = $res_1['discipline'];
	$semester = $res_1['semester'];
	$sql_9 = "SELECT * FROM observations_notes WHERE code = '$student_code' AND discipline = '$discipline' AND semester = '$semester'";
	$result_9 = mysqli_query($connection, $sql_9);
	if(mysqli_num_rows($result_9) == ''){
	?>
    <td><input name="grade" type="text" id="textfield" size="6"></td>
    <td><input type="submit" name="button" id="button" value="Finish"></td>
    <?php
	}else{  
	
	while($res_9 = mysqli_fetch_assoc($result_9)){
	
	echo "<td><h3>Unavailable - Grade ".$res_9['grade']."</h3></td>";
	}} ?>
    
  </tr>
</table>
</form>
<?php }} ?>
</div><!-- box -->



<?php require "footer.php"; ?>
</body>
</html>