﻿<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Extra Assignments</title>
<link rel="stylesheet" type="text/css" href="css/extra_assignments.css"/>
</head>

<body>

<?php require "header.php"; ?>

<div id="black_box">
</div><!-- black_box -->

<div id="box">
<br /><a class="a2" rel="superbox[iframe][850x350]" href="register_assignment.php?code=<?php echo $code; ?>">Post Assignment</a>
<p></p>
 <h1>Your History is below!</h1>

<?php
$sql_1 = "SELECT * FROM extra_assignments WHERE teacher = '$code' ORDER BY id DESC LIMIT 10";
$result = mysqli_query($connection, $sql_1);
if(mysqli_num_rows($result) == ''){
	 echo "<h2>There is no Assignment in the system at the moment!</h2>";	 
}else{
	while($res_1 = mysqli_fetch_assoc($result)){
?>
 
<table width="955" border="0">
  <tr>
    <td width="90">Assignment Number</td>
    <td width="60">Status</td>
    <td width="131">Release</td>
    <td width="187">Discipline</td>
    <td width="323">Theme</td>
    <td width="129">Due Date</td>
    <td width="">Marks</td>
  </tr>
  <tr>
    <td><h3><?php echo $res_1['id']; ?></h3></td>
    <td><h3><?php echo $res_1['status']; ?></h3></td>
    <td><h3><?php echo $res_1['date']; ?></h3></td>
    <td><h3><?php echo $res_1['discipline']; ?></h3></td>
    <td><h3><?php echo $res_1['theme']; ?></h3></td>
    <td><h3><?php echo $res_1['delivery_date']; ?></h3></td>
    <td><h3><?php echo $res_1['marks']; ?></h3></td>
  </tr>
  <tr>
    <td><a rel="superbox[iframe][850x350]" href="edit_extra_assignment.php?id=<?php echo $res_1['id']; ?>&code=<?php echo $code; ?>">Edit</a></td>
    <td colspan="3"><a href="students_who_showed_this_assignment_extra.php?id=<?php echo $res_1['id']; ?>">Students who delivered this Assignments</a></td>
    <td></td>
    <td><a href="extra_assignments.php?pg=delete&id=<?php echo $res_1['id']; ?>&code=<?php echo $code; ?>"><img src="../img/deleta.png" width="22" border="0" /></a></td>
  </tr>  
  </table> 
<?php }} ?> 

<?php if(@$_GET['pg'] == 'delete'){

$id = $_GET['id'];
$sql_2 = "DELETE FROM extra_assignments WHERE id = '$id'";
mysqli_query($connection, $sql_2);

echo "<script language='javascript'>window.location='extra_assignments.php';</script>";

}?>

</div><!-- box -->

<?php require "footer.php"; ?>

</body>
</html>