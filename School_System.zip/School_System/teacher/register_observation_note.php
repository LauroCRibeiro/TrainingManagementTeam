﻿<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Register Observation Note</title>
<link rel="stylesheet" type="text/css" href="css/register_exam.css"/>
<?php require "../connection.php"; $code = $_GET['code'];?>
</head>

<body>

<div id="box">

<?php if(isset($_POST['button'])){

$discipline = $_POST['discipline'];
$semester = $_POST['semester'];
$details = $_POST['details'];
$date = date("d/m/Y H:i:s");	

$sql_2 = "SELECT * FROM disciplines WHERE discipline = '$discipline'";
$result_2 = mysqli_query($connection, $sql_2);
	while($res_2 = mysqli_fetch_assoc($result_2)){
		
		$course = $res_2['course'];
		
	$sql_3 = "INSERT INTO observation_notes (date, status, teacher, course, discipline, details, semester) VALUES ('$date', 'Active', '$code', '$course', '$discipline', '$details', '$semester')";		
$result_3 = mysqli_query($connection, $sql_3);

$sql_4 = "INSERT INTO student_wall (date, status, course, title) VALUES ('$date', 'Active', '$course', 'Semester Grades have been publishing')";
$result_3 = mysqli_query($connection, $sql_4);

echo "Observation Note was successfully released in the System <br> Press F5 on your Keyboard";

die;

		}


}?>

<form name="send" method="post" action="" enctype="multipart/form-data">		
<table border="0">
  <tr>
    <td width="272">Discipline</td>
    <td>Semester:</td>
  </tr>
  <tr>
    <td>
      <select name="discipline" id="discipline">
      <?php
	  $sql_1 = "SELECT * FROM disciplines WHERE teacher = '$code'";
	  $result_1 = mysqli_query($connection, $sql_1);
	  while($res_1 = mysqli_fetch_assoc($result_1)){
	  
	  ?>
      <option value="<?php echo $res_1['discipline']; ?>"><?php echo $res_1['discipline']; ?></option>
      <?php } ?>
      </select></td>
    <td><select name="semester" size="1">
      <option value="1">1&ordm; Semester</option>
      <option value="2">2&ordm; Semester</option>
      <option value="3">3&ordm; Semester</option>
      <option value="4">4&ordm; Semester</option>
    </select></td>
  </tr>
  <tr>
    <td>Additional Information:</td>
  </tr>
  <tr>
    <td colspan="3"><textarea name="details" cols="" rows=""></textarea></td>
  </tr>
  <tr>
    <td><input class="input" type="submit" name="button" id="button" value="Register"></td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  </table>
  </form>
  
</div><!-- box --> 

</body>
</html>