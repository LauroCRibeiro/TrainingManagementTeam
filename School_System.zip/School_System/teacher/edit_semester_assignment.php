﻿<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Edit Semester Assignment</title>
<?php require "../connection.php"; $id = $_GET['id']; $code = $_GET['code']; ?>

<link rel="stylesheet" type="text/css" href="css/edit_assignment.css"/>
</head>

<body>

<div id="box">
<?php if(isset($_POST['button'])){

$dis = $_POST['dis'];
$en = $_POST['delivery_date'];
$theme = $_POST['theme'];
$details = $_POST['details'];
$course = $_POST['course'];


$sql_5 = "UPDATE semester_assignments SET discipline = '$dis', theme = '$theme', details = '$details', delivery_date = '$en' WHERE id = '$id' ";
mysqli_query($connection, $sql_5);
$date = date("d/m/Y H:i:s");

$sql_6 = "INSERT INTO student_wall (date, status, course, title) VALUES ('$date', 'Active', '$course', 'It has been altered $dis due to $en - to see more go to Results')";
mysqli_query($connection, $sql_6);

echo "<br><br><br>This Assignment was successfully updated!<br>Press F5 on your keyboard";

die;

}?>




<?php

$sql_1 = "SELECT * FROM semester_assignments WHERE id = '$id'";
$result = mysqli_query($connection, $sql_1);
while($res_1 = mysqli_fetch_assoc($result)){
?>

 <form name="send" method="post" action="" enctype="multipart/form-data">		
<table width="700" border="0">
  <tr>
    <td width="198">Assignment Number</td>
    <td width="216">Released</td>
  </tr><input type="hidden" name="course" value="<?php echo $res_1['course']; ?>" />
  <tr>
    <td><input disabled type="text" value="<?php echo $res_1['id']; ?>"></td>
    <td><input disabled type="text" value="<?php echo $res_1['date']; ?>"></td>

  </tr>
  <tr>
    <td>Discipline</td>
  </tr>
  <tr>
    <td><label for="dis"></label>
      <select name="dis" id="dis">
      <option value="<?php echo $res_1['discipline']; ?>"><?php echo $res_1['discipline']; ?></option>
      <option value=""></option>
      <?php
	  $dis = $res_1['discipline'];
      $sql_2 = "SELECT * FROM disciplines WHERE teacher = '$code' AND discipline != '$dis'";
	  $result_2 = mysqli_query($connection, $sql_2);
	  	while($res_2 = mysqli_fetch_assoc($result_2)){
	  ?>
      <option value="<?php echo $res_2['discipline']; ?>"><?php echo $res_2['discipline']; ?></option>
      <?php } ?>      
      </select></td>
  </tr>
  <tr>
    <td width="216">Due Date</td>
    <td width="272">Theme</td>
  </tr>
  <tr>
    <td><input type="text" name="delivery_date" value="<?php echo $res_1['delivery_date']; ?>"></td>
    <td><input type="text" name="theme" value="<?php echo $res_1['theme']; ?>"></td>
  </tr>  
  <tr>
    <td>Further Details about Assignment:</td>
  </tr>
  <tr>
    <td colspan="3"><textarea name="details" cols="" rows=""><?php echo $res_1['details']; ?></textarea></td>
  </tr>  
  <tr>
    <td><input class="input" type="submit" name="button" id="button" value="Edit"></td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  </table>
  </form>
<?php } ?>
</div><!-- box -->

</body>
</html>