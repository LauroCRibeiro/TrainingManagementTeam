﻿<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Register Assignment</title>
<?php require "../config.php"; ?>
<link rel="stylesheet" type="text/css" href="css/register_assignment.css"/>
</head>

<body>

<div id="box">

<?php if(isset($_POST['button'])){

$dis = $_POST['dis'];
$marks = $_POST['marks'];
$delivery_date = $_POST['delivery_date'];
$theme = $_POST['theme'];
$details = $_POST['details'];
$date = date("d/m/Y H:i:s");

$sql_3 = "SELECT * FROM disciplines WHERE discipline = '$dis'";
	$result_3 = mysqli_query($connection, $sql_3);
	while($res_3 = mysqli_fetch_assoc($result_3)){
		$course = $res_3['course'];
$sql_4 = "INSERT INTO extra_assignments (date, status, teacher, course, discipline, theme, details, delivery_date, marks) VALUES ('$date', 'Active', '$code', '$course', '$dis', '$theme', '$details', '$delivery_date', '$marks')";
mysqli_query($connection, $sql_4);

$sql_5 = "INSERT INTO student_wall (date, status, course, title) VALUES ('$date', 'Active', '$course', 'Extra Assignments of discipline  $dis due to $delivery_date - For further details go to ASSESSMENTS')";
mysqli_query($connection, $sql_5);

echo "This Assignment has been launched in our System<br>Press F5 on your keyboard.";

die;
	}
}?>

<form name="send" method="post" action="" enctype="multipart/form-data">		
<table border="0">
  <tr>
    <td width="198">Assignment Number</td>
    <td width="216">Launch</td>
    <td width="272">Discipline</td>
    <td width="100"></td>
  </tr>
  <tr>
    <td>
    <input disabled type="text" value=""
    <?php
    $sql_1 = "SELECT * FROM extra_assignments ORDER BY id DESC LIMIT 1";
	$result = mysqli_query($connection, $sql_1);
	if(mysqli_num_rows($result) == ''){
		echo "1";
	}else{
		while($res_1 = mysqli_fetch_assoc($result)){
			
			echo $res_1['id']+1;
			
	}}
	?>
    ">
    </td>
    <td><input disabled type="text" value="<?php echo date("d/m/Y H:i:s"); ?>"></td>
    <td>
      <select name="dis" id="dis">
      <?php
      $sql_2 = "SELECT * FROM disciplines WHERE teacher = '$code'";
	  $result_2 = mysqli_query($connection, $sql_2);
	  	while($res_2 = mysqli_fetch_assoc($result_2)){
	  ?>
      <option value="<?php echo $res_2['discipline']; ?>"><?php echo $res_2['discipline']; ?></option>
      <?php } ?>
      </select>
   </td>
  </tr>
  <tr>
    <td>Marks:</td>
    <td width="216">Due Date</td>
    <td width="272">Theme</td>
  </tr>
  <tr>
    <td><input type="text" name="marks" value=""></td>
    <td><input type="text" name="delivery_date" value=""></td>
    <td><input type="text" name="theme" value=""></td>
  </tr>
  <tr>
    <td>Further Details about Assignment:</td>
  </tr>
  <tr>
    <td colspan="3"><textarea name="details" cols="" rows=""></textarea></td>
  </tr>
  <tr>
    <td><input class="input" type="submit" name="button" id="button" value="Register"></td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  </table>
  </form>
</div><!-- box -->

</body>
</html>