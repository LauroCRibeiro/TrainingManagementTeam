﻿<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Edit Note</title>
<?php require "../config.php"; ?>
</head>

<body>

<?php if($_GET['pg'] == 'semester_assignment'){ ?>
<?php if(isset($_POST['send'])){

$grade = $_POST['grade'];
$student = $_GET['student'];
$id = $_GET['id'];
$dis = $_GET['discipline'];
$semester = $_GET['semester'];

$sql_5 = "UPDATE send_semester_assignments SET grade = '$grade' WHERE id = '$id' AND student = '$student'";
$sql_6 = "UPDATE assignment_grades SET grade = '$grade' WHERE code = '$student' AND discipline = '$dis' AND semester = '$semester'";
mysqli_query($connection, $sql_5);
mysqli_query($connection, $sql_6);


echo "Student`s grade has been already been altered";

die;

}?>
<em>Type new grade below</em>
<form name="" method="post" action="" enctype="multipart/form-data">
 <input type="text" size="4" maxlength="7" name="grade" value="<?php echo $_GET['grade']; ?>" /><input type="submit" name="send" value="Change" />
</form>
<?php }?>



<?php if($_GET['pg'] == 'semester_exams'){ ?>

<?php if(isset($_POST['send'])){

$grade = $_POST['grade'];
$semester = $_GET['semester'];
$teacher = $_GET['teacher'];
$discipline = $_GET['discipline'];
$student_code = $_GET['student'];

$sql = "UPDATE exam_grades SET grade = '$grade' WHERE code = '$student_code' AND semester = '$semester' AND discipline = '$discipline'";

mysqli_query($connection, $sql);

echo "Student`s grade has already been altered";
die;
	
}?>

<em>Type new grade below</em>
<form name="" method="post" action="" enctype="multipart/form-data">
 <input type="text" size="4" maxlength="7" name="grade" value="<?php echo $_GET['grade']; ?>" /><input type="submit" name="send" value="Change" />
</form>

<?php } ?>





<?php if($_GET['pg'] == 'extra_assignment'){ ?>
 
<?php if(isset($_POST['send'])){

$grade = $_POST['grade'];
$send_id = $_GET['id'];
$student = $_GET['student'];
$discipline = $_GET['discipline'];
$assignment_id = $_GET['assignment_id'];

$a_grade = $_GET['grade'];

$sql_2 = "UPDATE send_extra_assignments SET grade = '$grade' WHERE id = '$send_id' AND assignment_id	 = '$assignment_id' AND discipline = '$discipline' AND student = '$student'";

mysqli_query($connection, $sql_2);

$sql_3 = "SELECT * FROM extra_marks WHERE code = '$student' AND discipline = '$discipline'";
$result = mysqli_query($connection, $sql_3);

	while($res_1 = mysqli_fetch_assoc($result)){
			$d_grade = $res_1['grade']-$a_grade;
			
			$new_grade = $d_grade+$grade;
			
			$sql_4 = "UPDATE extra_marks SET grade = '$new_grade' WHERE code = '$student' AND discipline = '$discipline'";
			mysqli_query($connection, $sql_4);
			echo "Student`s grade was successfully altered!!!";
			die;
	
		}

}?> 
 
<em>Type new grade below</em>
<form name="" method="post" action="" enctype="multipart/form-data">
 <input type="text" size="4" maxlength="7" name="grade" value="<?php echo $_GET['grade']; ?>" /><input type="submit" name="send" value="Change" />
</form> 
<?php } ?>

</body>
</html>