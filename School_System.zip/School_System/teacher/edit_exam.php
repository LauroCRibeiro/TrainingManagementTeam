﻿<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Edit Exams</title>
<?php require "../connection.php"; $date = date("d/m/Y H:i:s"); $code = $_GET['code']; $id = $_GET['id']; ?>
<link rel="stylesheet" type="text/css" href="css/register_exam.css"/>
</head>

<body>

<div id="box">
<?php if(isset($_POST['button'])){

$dis = $_POST['dis'];
$semester = $_POST['semester'];
$apli = $_POST['application_date'];
$details = $_POST['details'];


$sql_3 = "UPDATE semester_exams SET discipline = '$dis', details = '$details', semester = '$semester', application_date = '$apli' WHERE id = '$id' ";
mysqli_query($connection, $sql_3);
		
echo "This exam has been successfully updated!<br>Press F5 on your keyboard.";

die;		

}?>

<?php

$sql_5 = "SELECT * FROM semester_exams WHERE id = '$id'";
$result_5 = mysqli_query($connection, $sql_5);
	while($res_5 = mysqli_fetch_assoc($result_5)){
?>
 <form name="send" method="post" action="" enctype="multipart/form-data">	
	
<table border="0">
  <tr>
    <td width="272">Discipline</td>
    <td>Semester:</td>
    <td width="216">Exam Date</td>
  </tr>
  <tr>
    <td>
      <select name="dis" id="dis">
      <option value="<?php echo $dis = $res_5['discipline']; ?>"><?php echo $dis = $res_5['discipline']; ?></option>
      <option value=""></option>
      <?php
      $sql_1 = "SELECT * FROM disciplines WHERE teacher = '$code' AND discipline != '$dis'";
	  $result_1 = mysqli_query($connection, $sql_1);
	  	while($res_1 = mysqli_fetch_assoc($result_1)){
	  ?>
      <option value="<?php echo $res_1['discipline']; ?>"><?php echo $res_1['discipline']; ?></option>
      <?php } ?>
      </select>
      </td>
    <td><select name="semester" size="1">
      <option value="<?php echo $res_5['semester']; ?>"><?php echo $res_5['semester']; ?> Semester</option>

      <option value=""></option>
      <option value="1">1&ordm; Semester</option>
      <option value="2">2&ordm; Semester</option>
      <option value="3">3&ordm; Semester</option>
      <option value="4">4&ordm; Semester</option>
      <option value="5">4&ordm; Semester</option>
      <option value="6">4&ordm; Semester</option>
    </select></td>
    <td><input type="text" name="application_date" value="<?php echo $res_5['application_date']; ?>"></td>
  </tr> 
  <tr>
    <td>Further Information:</td>
  </tr>
  <tr>
    <td colspan="3"><textarea name="details" cols="" rows=""><?php echo $res_5['details']; ?></textarea></td>
  </tr>
  <tr>
    <td><input class="input" type="submit" name="button" id="button" value="Register"></td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  </table>
  </form>
<?php } ?>  
</div><!-- box -->

</body>
</html>