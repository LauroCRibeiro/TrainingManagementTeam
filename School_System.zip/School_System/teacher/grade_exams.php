﻿<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Grade Exams</title>
<link rel="stylesheet" type="text/css" href="css/grade_exams.css"/>
</head>

<?php require "header.php"; ?>

<div id="black_box">
</div><!-- black_box -->

<div id="box">
 <h1>Students List enrolled in this Discipline</h1>

<?php if(isset($_POST['button'])){

$student_code = $_POST['student_code'];
$grade = $_POST['grade'];
$semester = $_POST['semester'];
$discipline = $_POST['discipline'];
$exam = $_FILES['exam']['name'];

if(file_exists("../student_assignment/$exam")){
	$a = 1;
	while(file_exists("../student_assignment/[$a]$exam")){
	$a++;
  }
  	$exam = "[".$a."]".$exam;
 }

 $sql_3 = "INSERT INTO exam_grades (code, semester, discipline, grade, exam) VALUES ('$student_code', '$semester', '$discipline', '$grade', '$exam')";
 mysqli_query($connection, $sql_3);
 
 (move_uploaded_file($_FILES['exam']['tmp_name'], "../student_assignment/".$exam));
 
 echo "<script language='javascript'>window.location='';</script>";

}?> 
 
 
 
<?php

$id = $_GET['id'];
$sql_1 = "SELECT * FROM semester_exams WHERE id = '$id'";
$result = mysqli_query($connection, $sql_1);
	while($res_1 = mysqli_fetch_assoc($result)){
		$course = $res_1['course'];
		$teacher = $res_1['teacher'];
		$semester = $res_1['semester'];
		
$sql_2 = "SELECT * FROM students WHERE year_grade = '$course'";
$result_2 = mysqli_query($connection, $sql_2);
if(mysqli_num_rows($result_2) == ''){
	echo "<h2>There is no student registered</h2>";
}else{
		while($res_2 = mysqli_fetch_assoc($result_2)){
?> 
 
<form name="" method="post" action="" enctype="multipart/form-data">
<input type="hidden" name="semester" value="<?php echo $res_1['semester']; ?>" />
<input type="hidden" name="discipline" value="<?php echo $res_1['discipline']; ?>" />
<input type="hidden" name="student_code" value="<?php echo $res_2['code']; ?>" />
<table width="955" border="0">
  <tr>
    <td width="107">Code:</td>
    <td width="302">Student Name:</td>
    <td width="200">Application Date:</td>
    <td width="144">Semester:</td>
    <td width="200">Scanned Exam:</td>
    <td width="156">Grade:</td>
  </tr>
  <tr>
    <td><h3><?php echo $student_code = $res_2['code']; ?></h3></td>
    <td><h3><?php echo $res_2['name']; ?></h3></td>
    <td><h3><?php echo $res_1['application_date']; ?></h3></td>
    <td><h3><?php echo $semester = $res_1['semester']; ?></h3></td>
    <?php
    $sql_4 = "SELECT * FROM exam_grades WHERE code = '$student_code' AND semester = '$semester'";
	$result_4 = mysqli_query($connection, $sql_4);
	if(mysqli_num_rows($result_4) == ''){
	?>
    <td><input type="file" name="exam" size="5" /></td>
    <td><input name="grade" type="text" id="textfield" size="6"></td>
    <td><input type="submit" name="button" id="button" value="Finish"></td>
    <?php }else{ while($res_4 = mysqli_fetch_assoc($result_4 )){ ?>
    <td><a target="_blank" href="../students_assignments/<?php echo $res_4['exam']; ?>">See Exam</a></td>
    <td><h3><?php echo $res_4['grade']; ?></h3></td>
   <td><a href="alter_assignment_grade.php?pg=semester_exams&id=<?php echo $res_4['id']; ?>&student=<?php echo $res_2['code']; ?>&discipline=<?php echo $res_1['discipline']; ?>&semester=<?php echo $res_1['semester'];  ?>&teacher=<?php echo $res_1['teacher'];  ?>&grade=<?php echo $res_4['grade']; ?>" rel="superbox[iframe][400x100]"><img src="../img/ico-editar.png" border="0" title="Alter Grade" /></a></td>
    <?php }} ?>
  </tr>
</table>
</form>
<?php }}} ?>
</div><!-- box -->


<?php require "footer.php"; ?>

<body>
</body>
</html>