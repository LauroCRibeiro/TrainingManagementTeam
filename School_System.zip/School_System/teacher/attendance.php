﻿<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Attendance</title>
<link rel="stylesheet" type="text/css" href="css/attendance.css"/>
</head>

<body>

<?php require "header.php"; ?>
<div id="black_box">
</div><!-- black_box -->

<div id="box">
 <h1>All students from <strong><?php echo $course = base64_decode($_GET['course']); ?></strong> Current date <strong><?php echo date("d/m/Y"); ?></strong></h1>

<?php

$date = date("d/m/Y H:i:s");
$date_today = date("d/m/Y");
$dis = base64_decode($_GET['dis']);

$sql_1 = "SELECT * FROM students WHERE year_grade = '$course'";
$result = mysqli_query($connection, $sql_1);
if(mysqli_num_rows($result) == ''){
	 echo "<h2><font color='#fff' size='2px'>There is no student in this discipline!</font></h2>";
}else{
 while($res_1 = mysqli_fetch_assoc($result)){
	 $student_code = $res_1['code'];
?> 
<form name="button" method="post" enctype="multipart/form-data" action="">
<table width="955" border="0">
  <tr>
    <td width="94"><strong>Code:</strong></td>
    <td width="466"><strong>Name:</strong></td>
    <td colspan="2"><strong>Is this student present?</strong></td>
  </tr>
  <tr>
    <td><?php echo $res_1['code']; ?><input type="hidden" name="student_code" value="<?php echo $res_1['code']; ?>" /></td>
    <td><?php echo $res_1['name']; ?><input type="hidden" name="name" value="<?php echo $res_1['name']; ?>" /></td>
    <td width="315">
    <?php
    $sql_2 = "SELECT * FROM attendance_in_class WHERE date_day = '$date_today' AND discipline = '$dis' AND student_code = '$student_code'";
	$result2 = mysqli_query($connection, $sql_2);
	if(mysqli_num_rows($result2) == ''){
	?>
    <input type="radio" name="attend" id="radio" value="YES">
    <label for="radio">YES
      <input type="radio" name="attend" value="NO">
    </label> 
    NO 
    <input type="radio" name="attend" value="JUSTIFIED">
    Justified Absence 
    <label for="fileField"></label></td>
    <td width="62"><input type="submit" name="button" id="button" value="SAVE"></td>
    <?php }else{ echo "Done! Data stored in the Database."; }?>
  </tr>
  <tr>
<?php if(isset($_POST['button'])){

$student_code = $_POST['student_code'];	
$name = $_POST['name'];	
@$attend = $_POST['attend'];

if($attend == ''){
	echo "<script language='javascript'>window.alert('Report whether this student is in class or not, Please!');</script>";
}else{
$sql_3 = "SELECT * FROM confirm_students_entrance WHERE today_date = '$date_today' AND student_code = '$student_code'";
$result3 = mysqli_query($connection, $sql_3);
if(mysqli_num_rows($result3) == '' && $attend == 'YES'){
	echo "<script language='javascript'>window.alert('This student has not showed up for the class today!');</script>";
}else{	
if(mysqli_num_rows($result3)>=1 && $attend == 'NO' || $attend == 'JUSTIFIED'){
?>
 <td colspan="3">
 <h3><strong>This student is in the premises, are you sure he(she) is not in the classroom?</strong></h3>
 <a href="attendance.php?course=<?php echo $_GET['course']; ?>&dis=<?php echo $_GET['dis']; ?>&confirm_absence=yes&student_code=<?php echo $student_code; ?>&type=<?php echo $_POST['attend']; ?>">Confirm Absence</a> | <a href="">CANCEL</a>
 </td>
<?php
}else{
$sql_4 = "INSERT INTO attendance_in_class (date, date_day, course, discipline, teacher_code, student_code, attend) VALUES ('$date', '$date_today', '$course', '$dis', '$code', '$student_code', '$attend')";	
mysqli_query($connection, $sql_4);
	echo "<script language='javascript'>window.location='';</script>";	
}}}}?>  
  </tr>
</table>
</form>

<?php if(@$_GET['confirm_absence'] == 'yes'){

$student_code = $_GET['student_code'];
$attend = $_GET['type'];


$sql_4 = "INSERT INTO attendance_in_class (date, date_day, course, discipline, teacher_code, student_code, attend) VALUES ('$date', '$date_today', '$course', '$dis', '$code', '$student_code', '$attend')";	
mysqli_query($connection, $sql_4);
$course = $_GET['course'];
$dis = $_GET['dis'];
echo "<script language='javascript'>window.location='attendance.php?course=$course&dis=$dis';</script>";
}?>


<?php }} ?>
</div><!-- box -->

<?php require "footer.php"; ?>

</body>
</html>