<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
</head>

<body>
<?php if(isset($_POST['button'])){
require "../connection.php";


$password = $_POST['password'];
$password2 = $_POST['password2'];
$code = $_GET['code'];

if($password != $password2){
	echo "<script language='javascript'>window.alert('Passwords Do not match!');</script>";
}else{

mysqli_query($connection, "UPDATE login SET passsword = '$password' WHERE code = '$code'");

echo "Password has been altered<br>Click F5 on your Keyboard";
die;
}
}?>

<form name="" method="post" action="" enctype="multipart/form-data">
<em>Type your new password / Repeat your password</em><br />
<input name="senha" type="password" size="10" maxlength="20" />
<input name="senha2" type="password" size="10" maxlength="20" /><input type="submit" name="button" value="Alter" />
</form>
</body>
</html>