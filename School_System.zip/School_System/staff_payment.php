<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
</head>

<body>
<?php

$d = date("d");
$m = date("m");
$a = date("Y");
$date = date("d/m/Y H:i:s");
$d_m_y = date("d/m/Y");

if($d == 02){
$sql_1 = mysqli_query($connection, "SELECT * FROM teachers WHERE status = 'Active' AND code != ''");
if(mysqli_num_rows($sql_1) == ''){
}else{
	while($res_1 = mysqli_fetch_assoc($sql_1)){
			$code = $res_1['code'];	
			$name = $res_1['name'];
			$salary = $res_1['wage'];
			
	$sql_2 = mysqli_query($connection, "SELECT * FROM cash_flow WHERE date = '$d_m_y' AND code = '$code'");
	if(mysqli_num_rows($sql_2) >=1){
	}else{
		mysqli_query($connection, "INSERT INTO cash_flow (status, type, d, m, a, full_date, date, code, details, value, payment_methods) VALUES ('Active', 'DEBIT', '$d', '$m', '$a', '$date', '$d_m_y', '$code', 'Teacher`s payment $name', '$salary', 'Bank Transfer')");
				
   }
  }
 }
}
?>


<?php

$d = date("d");
$m = date("m");
$a = date("Y");
$date = date("d/m/Y H:i:s");
$d_m_y = date("d/m/Y");

if($d == 02){
$sql_1 = mysqli_query($connection, "SELECT * FROM staff WHERE status = 'Active' AND code != ''");
if(mysqli_num_rows($sql_1) == ''){
}else{
	while($res_1 = mysqli_fetch_assoc($sql_1)){
			$code = $res_1['code'];	
			$name = $res_1['name'];
			$salary = $res_1['wage'];
			
	$sql_2 = mysqli_query($connection, "SELECT * FROM cash_flow WHERE date = '$d_m_y' AND code = '$code'");
	if(mysqli_num_rows($sql_2) >=1){
	}else{
		mysqli_query($connection, "INSERT INTO cash_flow (status, type, d, m, a, full_date, date, code, details, value, payment_methods) VALUES ('Active', 'DEBIT', '$d', '$m', '$a', '$date', '$d_m_y', '$code', 'Staff Payment  $name', '$salary', 'Bank Transfer')");
				
   }
  }
 }
}
?>

</body>
</html>