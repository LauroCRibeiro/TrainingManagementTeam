﻿<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
</head>

<body>


<?php if(@$_GET['pg'] == 'logout'){
	
	@session_destroy();
$_SESSION['code'] = '';
$_SESSION['name']= '';
$_SESSION['password']= '';
$_SESSION['panel']= '';



echo "<script language='javascript'>window.location='index.php';</script>";



}?>



<?php 
require "connection.php";

@session_start();



$code = $_SESSION['code'];
$password = $_SESSION['password'];
$name = $_SESSION['name'];
$panel = $_SESSION['panel'];

if($code == ''){
	echo "<script language='javascript'>window.location='../index.php';</script>";
}else if($name == ''){
	echo "<script language='javascript'>window.location='../index.php';</script>";
}else if($password == ''){
	echo "<script language='javascript'>window.location='../index.php';</script>";
}else{

$sql_1 = "SELECT * FROM login WHERE code = '$code' AND password = '$password'";
$result = mysqli_query($connection, $sql_1);
$conta_sql_1 = mysqli_num_rows($result);

if($conta_sql_1 == ''){
	echo "<script language='javascript'>window.location='../index.php';</script>";
}else{

 }
}
?>


<?php 
if(@$_GET['action'] == 'quit'){
	
	@session_destroy();
$_SESSION['code'] = '';
$_SESSION['name']= '';
$_SESSION['password']= '';
$_SESSION['panel']= '';
	
	echo "<script language='javascript'>window.location='index.php';</script>";
}
	
	?>

</body>
</html>