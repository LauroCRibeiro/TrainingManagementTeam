﻿<?php

function connect(){
	$server = "localhost";
	$user = "root";
	$password = "";
	$db = "school_system";
	
	$con = new mysqli($server, $user, $password, $db);
	return $con;
	
}

$connection = connect();


?>

