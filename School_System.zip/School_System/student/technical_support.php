﻿<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Technical Support</title>
<link rel="stylesheet" type="text/css" href="css/technical_support.css"/>
</head>

<body>

<?php require "header.php"; ?>

<div id="black_box">
</div><!-- black_box -->

<div id="box">
 <h1><strong>Request History</strong></h1>
 <a href="technical_support.php?action=open_request" class="a_1">Open Request</a>
<table width="832" border="0">
<?php if(@$_GET['action'] == 'open_request'){ ?>

<?php if(isset($_POST['send_message'])){

$sector = $_POST['sector'];
$message = $_POST['message'];
$attach = $_FILES['attachment']['name'];
$date = date("d/m/Y H:i:s");

if(file_exists("../attachment/$attach")){
		$a = 1;
		while(file_exists("../attachment/[$a]$attach")){
			$a++;
			}
		$attach = "[".$a."]".$attach;
	}
	
$sql_4 = "INSERT INTO central_message (date, status, emitter, receiver, message, attachment) VALUES ('$date', 'Response on hold', '$code', '$sector', '$message', '$attach')";
$result_4 = mysqli_query($connection, $sql_4);
if($result_4 == ''){
	echo "<script language='javascript'>window.alert('Error Occurred!');window.location='technical_support.php';</script>";
}else{

(move_uploaded_file($_FILES['attachment']['tmp_name'],"../attachment/".$attach));	



 $sql_1 = "SELECT * FROM disciplines WHERE course = '$year_grade'";
	   $result_1 = mysqli_query($connection, $sql_1);
	   	while($res_1 = mysqli_fetch_assoc($result_1)){
			$teacher = $res_1['teacher'];
		}

if($sector == 'COORDENATION'){
$sql_5 = "INSERT INTO coordenation_wall (date, status, course, title) VALUES ('$date', 'Active', 'Uninformed', 'There is a student`s message to be answered')";
mysqli_query($connection, $sql_5);
}


else if($sector == $teacher){
$sql_66 = "INSERT INTO teacher_wall (date, status, course, title) VALUES ('$date', 'Active', 'Uninformed', 'There is a student`s message to be answered')";
mysqli_query($connection, $sql_66);
}

	echo "<script language='javascript'>window.alert('Message Successfully Sent!');window.location='technical_support.php';</script>";


	

}


}?>


  <tr>
  <td>	 
     <form name="send_message" method="post" action="" enctype="multipart/form-data">
	  Select the Department you would like to send a message to
     <select name="sector" size="1" id="select">
       <option value="COORDENATION">COORDENATION</option>
        <option value=""></option>
       <option value="TEACHER">TEACHER</option>
       <?php
       $sql_1 = "SELECT * FROM disciplines WHERE course= '$year_grade'";
	   $result_1 = mysqli_query($connection, $sql_1);
	   	while($res_1 = mysqli_fetch_assoc($result_1)){
			$teacher = $res_1['teacher'];
			$discipline = $res_1['discipline'];
		$sql_2 = "SELECT * FROM teachers WHERE code = '$teacher'";
		$result_2 = mysqli_query($connection, $sql_2);
			while($res_2 = mysqli_fetch_assoc($result_2)){
	   ?>
        <option value="<?php echo $teacher; ?>"><?php echo $discipline ?> - <?php echo $res_2['name']; ?></option>
       <?php }} ?>
        <option value=""></option>
        
       <option value="">Classmates</option>
       <?php
       $sql_3 = "SELECT * FROM students WHERE year_grade = '$year_grade' AND shift = '$shift' AND code != '$code'";
	   $result_3 = mysqli_query($connection, $sql_3);
	   	while($res_3 = mysqli_fetch_assoc($result_3)){
	   ?>
        <option value="<?php echo $res_3['code']; ?>"><?php echo $res_3['name']; ?></option>
        <?php } ?>
     </select>
     In you have got any attachment, select it below<br />
     <input name="attachment" type="file" />
     <br />Type your message
     <textarea name="message"></textarea>
	 <input class="input" type="submit" name="send_message" value="Send" />
     </form>
     <hr>
  </td>
  </tr>
<?php } ?>
  <tr>
    <td width="826" align="left">Message Reports Below</td>
  </tr>
  <tr>
    <td align="center"><hr></td>
  </tr>
  <tr>
    <td align="center">
    <?php
    $sql_5 = "SELECT * FROM central_message WHERE emitter = '$code'";
	$result_5 = mysqli_query($connection, $sql_5);
	if(mysqli_num_rows($result_5) == ''){
		echo "There is no message";
	}else{
	?>
     <table border="0">
      <tr>
        <td width="114"><strong>Receiver:</strong></td>
        <td width="120"><strong>Status:</strong></td>
        <td width="168"><strong>Date:</strong></td>
        <td width="149"><strong>Attachment:</strong></td>
        <td width="152"><strong>Response Date:</strong></td>
      </tr>
      <?php while($res_5 = mysqli_fetch_assoc($result_5)){ ?>
      <tr>
        <td><?php echo $res_5['receiver']; ?></td>
        <td><?php echo $res_5['status']; ?></td>
        <td><?php echo $res_5['date']; ?></td>
        <td><a target="_blank" href="../attachment/<?php echo $res_5['attachment']; ?>">Download</a></td>
        <td><?php echo $res_5['response_date']; ?></td>
        <td width="50">
        <a href="technical_support.php?action=ticket&id=<?php echo $res_5['id']; ?>"><img src="../img/visualizar16.gif"  border="0" title="View Request" /></a> |
        <a href="technical_support.php?action=close&id=<?php echo $res_5['id']; ?>"><img src="../img/deleta.png" width="22" border="0" title="Delete Request" /></a>
      
        </td>
        </tr>
      	<tr>
        <?php if(@$_GET['action'] == 'ticket'){ ?>
        <td colspan="6"><hr />
        <?php
        if($res_5['response'] == ''){
			 echo "<h4 class='h4'>There is no Answer for this request!</h4>";
		}else{
			
				 $date = $res_5['date'];
				 $response = $res_5['response'];
				 $attach_resp = $res_5['attach_resp'];
				 $message = $res_5['message'];
			 echo "<h1 class='h1'><strong>Your Message:</strong><br><br>$message</h1>";
			 echo "<h1 class='h2'><strong>Date:</strong>$date | <strong>Attachment:</strong> <a href='../attachment/$attach_resp' target='_blank'> $attach_resp</a><br><br>$response</h1>";			
			
		?>
        
        </td>
        </tr>
        <?php } ?>
      	<tr><br />
        <td colspan="6"><hr></td>
        </tr>
      <?php } ?>
    </table>
    <?php } ?>
    </td>
  </tr>
</table> 
    <?php } ?>
    </td>
  </tr>
</table> 


<?php if(@$_GET['action'] == 'close'){

$sql_6 = "DELETE FROM central_message WHERE id = ".$_GET['id']."";
mysqli_query($connection, $sql_6);
echo "<script language='javascript'>window.location='technical_support.php';</script>";
}?>

</div><!-- box -->

</body>
</html>