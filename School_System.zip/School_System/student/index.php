﻿<?php $actual_panel = "student"; ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />

<title>Student Panel</title>
<link rel="stylesheet" type="text/css" href="css/index.css"/>
</head>

<body>
<?php require "header.php"; ?>

<div id="black_box">
</div><!-- black_box -->

<div id="box">
 <div id="reports">
   <ul>
    <h1><strong>Attendance</strong> </h1>
    <li><strong>Attendance:</strong> <?php echo mysqli_num_rows(mysqli_query($connection, "SELECT * FROM attendance_in_class WHERE student_code = '$code' AND attend = 'YES'")) / 3; ?></li>
    <li><strong>Justified Absence:</strong>  <?php echo mysqli_num_rows(mysqli_query($connection, "SELECT * FROM attendance_in_class WHERE student_code = '$code' AND attend = 'JUSTIFIED'")) / 3; ?></li>
    <li><strong>Absence not Justified:</strong>  <?php echo mysqli_num_rows(mysqli_query($connection, "SELECT * FROM attendance_in_class WHERE student_code = '$code' AND attend = 'NO'")) / 3; ?></li>
   </ul>
   
   <ul>
    <h1><strong>Financial Sector</strong></h1>
    <li><strong>Confirmed Payments:</strong>  <?php echo mysqli_num_rows(mysqli_query($connection, "SELECT * FROM fees WHERE enrollment = '$code' AND status = 'Payment Confirmed'")); ?></li>
    <li><strong>Bills Not Payed Yet:</strong>  <?php echo mysqli_num_rows(mysqli_query($connection, "SELECT * FROM fees WHERE enrollment = '$code' AND status = 'Payment on hold'")); ?></li>
   </ul> 
   
   <ul>
    <h1><strong>Technical Support</strong></h1>
    <li><strong>Inbox Messages:</strong> <?php echo mysqli_num_rows(mysqli_query($connection, "SELECT * FROM central_message WHERE emitter = '$code'")); ?></li>
    <li><strong>Messages Not Replied:</strong>  <?php echo mysqli_num_rows(mysqli_query($connection, "SELECT * FROM central_message WHERE emitter = '$code' AND status = 'Response on hold'")); ?></li>
    <li><strong>Replied Messages:</strong>  <?php echo mysqli_num_rows(mysqli_query($connection, "SELECT * FROM central_message WHERE emitter = '$code' AND status = 'Replied'")); ?></li>
   </ul> 
 
 
 </div><!-- reports -->
 
 <div id="notifications">
  <h1>Notifications</h1>
  <div id="warning_notifications">
   <ul>
   <?php
   $sql_1 = mysqli_query($connection, "SELECT * FROM student_wall WHERE course = '$year_grade'");
   	while($res_1 = mysqli_fetch_assoc($sql_1)){
   ?>
    <li><h1><?php echo $res_1['title']; ?></h1></li>
    <?php } ?>
   </ul>
  </div><!-- warning_notifications -->
 </div><!-- notifications -->
 
 
</div><!-- box -->

</body>
</html>