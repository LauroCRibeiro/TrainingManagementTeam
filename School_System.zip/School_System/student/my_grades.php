﻿<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>My Grades</title>
<link rel="stylesheet" type="text/css" href="css/my_grades.css"/>
</head>

<body>
<?php require "header.php"; ?>

<div id="black_box">
</div><!-- black_box -->

<div id="box">
<?php if($_GET['pg'] == 'assignments'){ ?>
<h1><strong>Semester Assignment Grades</strong></h1>
<table width="900" border="0">
  <tr>
    <td width="317"><strong>DISCIPLINE<br /><br /></strong></td>
    <td width="150"><strong>First Semester</strong></td>
    <td width="150"><strong>Second Semester</strong></td>
    <td width="150"><strong>Third Semester</strong></td>
    <td width="150"><strong>Fourth Semester</strong></td>
  </tr>
<?php
$sql_1 = "SELECT * FROM disciplines WHERE course = '$year_grade'";
$result_1 = mysqli_query($connection, $sql_1);
	while($res_1 = mysqli_fetch_assoc($result_1)){
		$discipline = $res_1['discipline'];

$sql_2 = "SELECT * FROM assignments_grade WHERE code = '$code' AND discipline = '$discipline' AND semester = '1'";
$result_2 = mysqli_query($connection, $sql_2);
$sql_3 = "SELECT * FROM assignments_grade WHERE code = '$code' AND discipline = '$discipline' AND semester = '2'";
$result_3 = mysqli_query($connection, $sql_3);
$sql_4 = "SELECT * FROM assignments_grade WHERE code = '$code' AND discipline = '$discipline' AND semester = '3'";
$result_4 = mysqli_query($connection, $sql_4);
$sql_5 = "SELECT * FROM assignments_grade WHERE code = '$code' AND discipline = '$discipline' AND semester = '4'";
$result_5 = mysqli_query($connection, $sql_5);
		
?>
  <tr>
    <td><?php echo $discipline; ?></td>
    <td>
    <?php
    if(mysqli_num_rows($result_2) == ''){
		echo "<h2>On Hold</h2>";
	}else{
		while($res_2 = mysqli_fetch_assoc($result_2)){
				$grade = $res_2['grade'];
				if($grade >= 7){
						echo "<h2><strong>$grade</strong></h2>";
				}else{
						echo "<h3><strong>$grade</strong></h3>";	
				}
				
			}
	}?>
    </td>
    <td>
    <?php
    if(mysqli_num_rows($result_3) == ''){
		echo "<h2>On Hold</h2>";
	}else{
		while($res_3 = mysqli_fetch_assoc($result_3)){
				$grade = $res_3['grade'];
				if($grade >= 7){
						echo "<h2><strong>$grade</strong></h2>";
				}else{
						echo "<h3><strong>$grade</strong></h3>";	
				}
				
			}
	}?>
    </td>
    <td>
    <?php
    if(mysqli_num_rows($result_4) == ''){
		echo "<h2>On Hold</h2>";
	}else{
		while($res_4 = mysqli_fetch_assoc($result_4)){
				$grade = $res_4['grade'];
				if($grade >= 7){
						echo "<h2><strong>$grade</strong></h2>";
				}else{
						echo "<h3><strong>$grade</strong></h3>";	
				}
				
			}
	}?>
    </td>
    <td>
    <?php
    if(mysqli_num_rows($result_5) == ''){
		echo "<h2>On Hold</h2>";
	}else{
		while($res_5 = mysqli_fetch_assoc($result_5)){
				$grade = $res_5['grade'];
				if($grade >= 7){
						echo "<h2><strong>$grade</strong></h2>";
				}else{
						echo "<h3><strong>$grade</strong></h3>";	
				}
				
			}
	}?>
    </td>
    </tr>
  <tr>
    <td colspan="6"><img src="img/menu_topo.png" width="900" height="1"></td>
  </tr>
<?php } ?>
</table>
<h4>OBS: This Grade is a result of Assingments sent </h4>
<?php } ?>


<?php if($_GET['pg'] == 'exams'){ ?>
<h1><strong>Semester Exam Grades</strong></h1>
<table width="900" border="0">
  <tr>
    <td width="317"><strong>DISCIPLINE<br /><br /></strong></td>
    <td width="150"><strong>First Semester</strong></td>
    <td width="150"><strong>Second Semester</strong></td>
    <td width="150"><strong>Third Semester</strong></td>
    <td width="150"><strong>Fourth Semester</strong></td>
  </tr>
<?php
$sql_1 = "SELECT * FROM disciplines WHERE course = '$year_grade'";
$result_1 = mysqli_query($connection, $sql_1);
	while($res_1 = mysqli_fetch_assoc($result_1)){
		$discipline = $res_1['discipline'];
		
$sql_2 = "SELECT * FROM exam_grades WHERE code = '$code' AND discipline = '$discipline' AND semester = '1'";
$result_2 = mysqli_query($connection, $sql_2);		
$sql_3 = "SELECT * FROM exam_grades WHERE code = '$code' AND discipline = '$discipline' AND semester = '2'";
$result_3 = mysqli_query($connection, $sql_3);		
$sql_4 ="SELECT * FROM exam_grades WHERE code = '$code' AND discipline = '$discipline' AND semester = '3'";
$result_4 = mysqli_query($connection, $sql_4);			
$sql_5 = "SELECT * FROM exam_grades WHERE code = '$code' AND discipline = '$discipline' AND semester = '4'";
$result_5 = mysqli_query($connection, $sql_5);		
?>  
  <tr>
    <td><?php echo $discipline; ?></td>
    <td>
    <?php
    if(mysqli_num_rows($result_2) == ''){
		echo "<h2>On Hold</h2>";
	}else{
		while($res_2 = mysqli_fetch_assoc($result_2)){
			$grade = $res_2['grade'];
			$exam = $res_2['exam'];
			
			if($grade >= 7){
				echo "<h2><strong>".$res_2['grade']."</strong>";
			}else{
				echo "<h3><strong>".$res_2['grade']."</strong>";			
			}
			if($res_2['exam'] == ''){
			}else{
			echo " | <a target='_blank' class='a5' href='../students_assignments/$exam'>See</a></h2></h3>";
			}
			
		}}?>
    </td>
    <td>
    <?php
    if(mysqli_num_rows($result_3) == ''){
		echo "<h2>On Hold</h2>";
	}else{
		while($res_3 = mysqli_fetch_assoc($result_3)){
			$grade = $res_3['grade'];
			$exam = $res_3['exam'];
		
			if($grade >= 7){
				echo "<h2><strong>".$res_3['grade']."</strong>";
			}else{
				echo "<h3><strong>".$res_3['grade']."</strong></h3>";			
			}
			if($res_3['exam'] == ''){
			}else{
			echo " | <a target='_blank' class='a5' href='../students_assignments/$exam'>See</a></h2>";
			}			
		}}?>
    </td>
    <td>
    <?php
    if(mysqli_num_rows($result_4) == ''){
		echo "<h2>On Hold</h2>";
	}else{
		while($res_4 = mysqli_fetch_assoc($result_4)){
			$grade = $res_4['grade'];
			$exam = $res_4['exam'];
			
			if($grade >= 7){
				echo "<h2><strong>".$res_4['grade']."</strong>";
			}else{
				echo "<h3><strong>".$res_4['grade']."</strong></h3>";			
			}
			if($res_4['grade'] == ''){
			}else{
			echo " | <a target='_blank' class='a5' href='../students_assignments/$exam'>See</a></h2>";
			}			
		}}?>
    </td>
    <td>
    <?php
    if(mysqli_num_rows($result_5) == ''){
		echo "<h2>On Hold</h2>";
	}else{
		while($res_5 = mysqli_fetch_assoc($result_5)){
			$grade = $res_5['grade'];
			$exam = $res_5['exam'];
			
			if($grade >= 7){
				echo "<h2><strong>".$res_5['grade']."</strong>";
			}else{
				echo "<h3><strong>".$res_5['grade']."</strong></h3>";			
			}
			if($res_5['exam'] == ''){
			}else{
			echo " | <a target='_blank' class='a5' href='../students_assignments/$exam'>See</a></h2>";
			}			
	}}?>
    </td>        
  </tr>
<?php } ?>  
  <tr>
    <td colspan="6"><img src="img/menu_topo.png" width="900" height="1"></td>
  </tr>
</table>
<h4>Note: This is your Semester Grade.</h4>
<?php } ?>


<?php if($_GET['pg'] == 'observation'){ ?>
<h1><strong>Semester Observations Notes given by the Teacher.</strong></h1>
<table width="900" border="0">
  <tr>
    <td width="317"><strong>DISCIPLINE<br /><br /></strong></td>
    <td width="150"><strong>First Semester</strong></td>
    <td width="150"><strong>First Semester</strong></td>
    <td width="150"><strong>Third Semester</strong></td>
    <td width="150"><strong>Fourth Semester</strong></td>
  </tr>
<?php
$sql_1 = "SELECT * FROM disciplines WHERE course = 'year_grade'";
$result_1 = mysqli_query($connection, $sql_1);		
	while($res_1 = mysqli_fetch_assoc($result_1)){
		$discipline = $res_1['discipline'];
		
$sql_2 = "SELECT * FROM observations_notes WHERE code = '$code' AND discipline = '$discipline' AND semester = '1'";
$result_2 = mysqli_query($connection, $sql_2);
		
$sql_3 = "SELECT * FROM observations_notes WHERE code = '$code' AND discipline = '$discipline' AND semester = '2'";	
$result_3 = mysqli_query($connection, $sql_3);
	
$sql_4 = "SELECT * FROM observations_notes WHERE code = '$code' AND discipline = '$discipline' AND semester = '3'";
$result_4 = mysqli_query($connection, $sql_4);
		
$sql_5 = "SELECT * FROM observations_notes WHERE code = '$code' AND discipline = '$discipline' AND semester = '4'";
$result_5 = mysqli_query($connection, $sql_5);
		
?>  
  <tr>
    <td><?php echo $discipline; ?></td>
    <td>
    <?php
    if(mysqli_num_rows($result_2) == ''){
		echo "<h2>On Hold</h2>";
	}else{
		while($res_2 = mysqli_fetch_assoc($result_2)){
			$grade = $res_2['grade'];
			
			if($grade >= 7){
				echo "<h2><strong>".$res_2['grade']."</strong></h2>";
			}else{
				echo "<h3><strong>".$res_2['grade']."</strong></h3>";			
			}
			
		}}?>
    </td>
    <td>
    <?php
    if(mysqli_num_rows($result_3) == ''){
		echo "<h2>On Hold</h2>";
	}else{
		while($res_3 = mysqli_fetch_assoc($result_3)){
			$grade = $res_3['grade'];
			
			if($grade >= 7){
				echo "<h2><strong>".$res_3['grade']."</strong></h2>";
			}else{
				echo "<h3><strong>".$res_3['grade']."</strong></h3>";			
			}
			
		}}?>
    </td>
    <td>
    <?php
    if(mysqli_num_rows($result_4) == ''){
		echo "<h2>On Hold</h2>";
	}else{
		while($res_4 = mysqli_fetch_assoc($result_4)){
			$grade = $res_4['grade'];
			
			if($grade >= 7){
				echo "<h2><strong>".$res_4['grade']."</strong></h2>";
			}else{
				echo "<h3><strong>".$res_4['grade']."</strong></h3>";			
			}
			
		}}?>
    </td>
    <td>
    <?php
    if(mysqli_num_rows($result_5) == ''){
		echo "<h2>On Hold</h2>";
	}else{
		while($res_5 = mysqli_fetch_assoc($result_5)){
			$grade = $res_5['grade'];
			
			if($grade >= 7){
				echo "<h2><strong>".$res_5['grade']."</strong></h2>";
			}else{
				echo "<h3><strong>".$res_5['grade']."</strong></h3>";			
			}
			
	}}?>
    </td>        
  </tr>
<?php } ?>  
  <tr>
    <td colspan="6"><img src="img/menu_topo.png" width="900" height="1"></td>
  </tr>
</table>
<h4>Note: Discipline Grade given by the Teacher</h4>
<?php } ?>


<?php if($_GET['pg'] == 'semester'){ ?>
<h1><strong>Your Semester Grades</strong></h1>
<table width="900" border="0">
  <tr>
    <td width="317"><strong>DISCIPLINE<br /><br /></strong></td>
    <td width="120"><strong>First Semester</strong></td>
    <td width="120"><strong>Second Semester</strong></td>
    <td width="120"><strong>Third Semester</strong></td>
    <td width="120"><strong>Fourth Semester</strong></td>
    <td width="150"><strong>Result</strong></td>
  </tr>
<?php
$sql_1 = "SELECT * FROM disciplines WHERE course = 'year_grade'";
$result_1 = mysqli_query($connection, $sql_1);
	while($res_1 = mysqli_fetch_assoc($result_1)){
		$discipline = $res_1['discipline'];
		
$sql_2 = "SELECT * FROM semester_grades WHERE code = '$code' AND discipline = '$discipline' AND semester = '1'";
$result_2 = mysqli_query($connection, $sql_2);
		
$sql_3 = "SELECT * FROM semester_grades WHERE code = '$code' AND discipline = '$discipline' AND semester = '2'";	
$result_3 = mysqli_query($connection, $sql_3);
	
$sql_4 = "SELECT * FROM semester_grades WHERE code = '$code' AND discipline = '$discipline' AND semester = '3'";
$result_4 = mysqli_query($connection, $sql_4);
		
$sql_5 = "SELECT * FROM semester_grades WHERE code = '$code' AND discipline = '$discipline' AND semester = '4'";
$result_5 = mysqli_query($connection, $sql_5);
		
?>  
  <tr>
    <td><?php echo $discipline; ?></td>  
    <td>
    <?php
    if(mysqli_num_rows($result_2) == ''){
		echo "<h2>On Hold</h2>";
	}else{
		while($res_2 = mysqli_fetch_assoc($result_2)){
				$grade = number_format($res_2['grade'],2);
				
				if($grade >= 7){
					echo "<h2><strong>$grade</strong></h2>";
				}else{
					echo "<h3><strong>$grade</strong></h3>";
				}
				
			}
	}?>
    </td>
    <td>
    <?php
    if(mysqli_num_rows($result_3) == ''){
		echo "<h2>On Hold</h2>";
	}else{
		while($res_3 = mysqli_fetch_assoc($result_3)){
				$grade = number_format($res_3['grade'],2);
				
				if($grade >= 7){
					echo "<h2><strong>$grade</strong></h2>";
				}else{
					echo "<h3><strong>$grade</strong></h3>";
				}
				
			}
	}?>
    </td>
    <td>
    <?php
    if(mysqli_num_rows($result_4) == ''){
		echo "<h2>On Hold</h2>";
	}else{
		while($res_4 = mysqli_fetch_assoc($result_4)){
				$grade = number_format($res_4['grade'],2);
				
				if($grade >= 7){
					echo "<h2><strong>$grade</strong></h2>";
				}else{
					echo "<h3><strong>$grade</strong></h3>";
				}
				
			}
	}?>
    </td>
    <td>
    <?php
    if(mysqli_num_rows($result_5) == ''){
		echo "<h2>On Hold</h2>";
	}else{
		while($res_5 = mysqli_fetch_assoc($result_5)){
				$grade = number_format($res_5['grade'],2);
				
				if($grade >= 7){
					echo "<h2><strong>$grade</strong></h2>";
				}else{
					echo "<h3><strong>$grade</strong></h3>";
				}
				
			}
	}?>
    </td>    
    <td>
<?php
if(mysqli_num_rows($result_5) == ''){
	echo "On Hold";
}else{
$sql_2 = "SELECT * FROM semester_grades WHERE code = '$code' AND discipline = '$discipline' AND semester = '1'";		
$result_2 = mysqli_query($connection, $sql_2);

$sql_3 = "SELECT * FROM semester_grades WHERE code = '$code' AND discipline = '$discipline' AND semester = '2'";	
$result_3 = mysqli_query($connection, $sql_3);
	
$sql_4 = "SELECT * FROM semester_grades WHERE code = '$code' AND discipline = '$discipline' AND semester = '3'";	
$result_4 = mysqli_query($connection, $sql_4);
	
$sql_5 = "SELECT * FROM semester_grades WHERE code = '$code' AND discipline = '$discipline' AND semester = '4'";	
$result_5 = mysqli_query($connection, $sql_5);


while($res_2 = mysqli_fetch_assoc($result_2)){
while($res_3 = mysqli_fetch_assoc($result_3)){
while($res_4 = mysqli_fetch_assoc($result_4)){
while($res_5 = mysqli_fetch_assoc($result_5)){
	

	$media = ($res_2['grade']+$res_3['grade']+$res_4['grade']+$res_5['grade'])/4;
	
	if($media >=7){
		echo "<h2><strong>".number_format($media,2)." - Approved</strong></h2>";
	}else{
		echo "<h3><strong>".number_format($media,2)." - Failed</strong></h3>";
	
	}}}}}}
?>    
    </td>
  </tr>
<?php } ?>  
  <tr>
    <td colspan="6"><img src="img/menu_topo.png" width="900" height="1"></td>
  </tr>
</table>
<h4>Note: Your semester grade median is got by: Assignment Grade + Exam Grade + Observation Note = Sum Results/3 = Your Semester Grade</h4>
<h4>Note 2: The Final result is got by your grades divided by 4 = Final Grade</h4>
<?php } ?>
</div><!-- box -->

</body>
</html>