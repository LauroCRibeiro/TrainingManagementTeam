<?php $actual_panel = "student";?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<?php require "../config.php";


$sql_stud = "SELECT * FROM students WHERE code = '$code'";
$result = mysqli_query($connection, $sql_stud);
	while($r_stud = mysqli_fetch_assoc($result)){
		$name = $r_stud['name'];
		$year_grade = $r_stud['year_grade'];
		$shift = $r_stud['shift'];
		$pps = $r_stud['pps'];
	}
?>
<title>Training School Center - Student Portal</title>
<link href="css/header.css" rel="stylesheet" type="text/css" />
<script language="javascript" src="../js/jquery-1.7.2.min.js"></script>
<script src="../js/lightbox.js"></script>
<link href="../css/lightbox.css" rel="stylesheet" />


<link rel="stylesheet" href="../jquery.superbox.css" type="text/css" media="all" />
	<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.3.2/jquery.min.js"></script>

	<script type="text/javascript" src="../jquery.superbox-min.js"></script>
	<script type="text/javascript">

		$(function(){

			$.superbox.settings = {

				closeTxt: "Close",

				loadTxt: "Loading...",

				nextTxt: "Next",

				prevTxt: "Previous"

			};

			$.superbox();

		});

	</script>
</head>

<body>
<div id="header_box">
 
 <div id="logo">
  <img src="../img/logo.jpg" width="260" />
 </div><!-- logo -->
 
 <div id="student_data">
	<h1><strong><?php echo @$code; ?></strong>
    <br />
    <?php echo $pps; ?></h1>
 </div><!-- student_data -->
 
 <div id="show_login">
  <h1><strong>Hello :</strong> <?php echo $name; ?> <strong><a href="../config.php?pg=logout">LogOut</a></strong></h1>
 </div><!-- show_login -->
</div><!-- header_box -->

<div id="box_menu">
 
 <div id="header_menu">
  <ul>
   <li><a href="index.php">HOME</a></li>
   <li><a href="my_grades.php?pg=semester">My Grades</a>
    <ul>
     <li><a href="my_grades.php?pg=assignments">Assignment Grades</a></li>
     <li><a href="my_grades.php?pg=exams">Exam Grades</a></li>
     <li><a href="my_grades.php?pg=observation">Observation Grades</a></li>
     <li><a href="my_grades.php?pg=semester">Semester Grades</a></li>
    </ul>
   </li>
   <li><a href="">ASSIGNMENTS</a>
    <ul>
     <li><a href="assignments.php?pg=semester_assignments">Semester Assignments</a></li>
     <li><a href="assignments.php?pg=extra_assignments">Extra Assignments</a></li>
    </ul>
   </li>    
   <li><a href="attendance.php">Attendance</a></li>
   <li><a href="finance_sector.php">Financial Sector</a></li>
   <li><a href="technical_support.php">Technical Support</a></li>
  </ul>
 </div><!-- header_menu -->

</div><!-- box_menu -->
</body>
</html>