﻿<?php $actual_panel = "student";?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Assignments</title>
<link rel="stylesheet" type="text/css" href="css/semester_exams.css"/>
</head>

<body>
<?php require "header.php"; ?>


<div id="black_box">
</div><!-- black_box -->

<div id="box">
<?php if($_GET['pg'] == 'semester_assignments'){ ?>
<h1><strong>Semester Assignments in the System!</strong></h1>

<?php
$sql_1 = "SELECT * FROM semester_assignments WHERE status = 'Active' AND course = '$year_grade'";
$result_1 = mysqli_query($connection, $sql_1);
if(mysqli_num_rows($result_1) == ''){
	echo "<h2>There is no Assignments in the System at the moment!</h2>";
}else{
		while($res_1 = mysqli_fetch_assoc($result_1)){
?>
<table width="955" border="0">
  <tr>
    <td width="150">Assignment Number</td>
    <td width="189">Discipline</td>
    <td width="420">Theme</td>
    <td width="260">Delivery Date:</td>
    <td width="170">Semester:</td>
  </tr>
  <tr>
    <td><?php echo $id = $res_1['id']; ?></td>
    <td><?php echo $discipline = $res_1['discipline']; ?></td>
    <td><?php echo $res_1['theme']; ?></td>
    <td><?php echo $res_1['delivery_date']; ?></td>
    <td><h2><?php echo $res_1['semester']; ?> Semester</h2></td>
  </tr>
  <tr>
    <td><a href="assignment_details.php?id=<?php echo $res_1['id']; ?>&pg=semester_assignments" rel="superbox[iframe][515x400]">Further Details</a></td>
    <?php
	$sql_2 = "SELECT * FROM send_semester_assignment WHERE assignment_id = ".$res_1['id']." AND student = '$code'";
	$result_2 = mysqli_query($connection, $sql_2);
	if(mysqli_num_rows($result_2) >= '1'){
		echo "<td><h2><strong>Assignment Already Sent</strong></h2></td>";
	}else{
	?>
    <td colspan="2"><a href="send_assignment.php?id=<?php echo $res_1['id']; ?>&pg=semester_assignments&student=<?php echo $code; ?>&dis=<?php echo $res_1['discipline']; ?>&delivery_date=<?php echo $res_1['delivery_date']; ?>" rel="superbox[iframe][400x190]">Send Assignment</a></td>
    <?php } ?>
    <td></td>
    <td>&nbsp;</td>
  </tr>
</table>
<?php }} ?>

<?php } ?>


<?php if($_GET['pg'] == 'extra_assignments'){ ?>
<h1><strong>Extra Assignments in the System</strong></h1>
<?php
$sql_1 = "SELECT * FROM extra_assignments WHERE status = 'Active' AND course = '$year_grade'";
$result_1 = mysqli_query($connection, $sql_1);
if(mysqli_num_rows($result_1) == ''){
	echo "<h2>There is no assignment in the System at the moment!</h2>";
}else{
		while($res_1 = mysqli_fetch_assoc($result_1)){
?>
<table width="955" border="0">
  <tr>
    <td width="150">Assignment Number</td>
    <td width="189">Discipline</td>
    <td width="420">Theme</td>
    <td width="260">Delivery Date:</td>
  </tr>
  <tr>
    <td><?php echo $id = $res_1['id']; ?></td>
    <td><?php echo $discipline = $res_1['discipline']; ?></td>
    <td><?php echo $res_1['theme']; ?></td>
    <td><?php echo $res_1['delivery_date']; ?></td>
  </tr>
  <tr>
    <td><a href="assignment_details.php?id=<?php echo $res_1['id']; ?>&pg=extra_assignments" rel="superbox[iframe][515x400]">Further Details</a></td>
    <?php 
	$sql_2 = "SELECT * FROM send_extra_assignments WHERE assignment_id = ".$res_1['id']." AND student = '$code'";
	$result_2 = mysqli_query($connection, $sql_2);
	if(mysqli_num_rows($result_2) >= '1'){
		echo "<td><h2><strong>Assignment Already Sent</strong></h2></td>";
	}else{
	?>
    <td colspan="2"><a href="send_assignment.php?id=<?php echo $res_1['id']; ?>&pg=extra_assignments&student=<?php echo $code; ?>&dis=<?php echo $res_1['discipline']; ?>&delivery=<?php echo $res_1['delivery_date']; ?>" rel="superbox[iframe][400x190]">Send Assignment</a></td>
    <?php } ?>
    <td></td>
    <td>&nbsp;</td>
  </tr>
</table>
<?php }} ?>

<?php } ?>
</div><!-- box -->

</body>
</html>