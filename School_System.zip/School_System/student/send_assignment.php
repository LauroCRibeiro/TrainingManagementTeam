﻿<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Send Assignment</title>
<?php require "../config.php"; ?>

<link rel="stylesheet" type="text/css" href="css/send_assignment.css"/>
</head>

<body>

<div id="box">
<?php  if($_GET['pg'] == 'semester_assignments'){ ?>
<?php  if(isset($_POST['button'])){

$assignment = $_FILES['assignment']['name'];

if(file_exists("../students_assignments/$assignment")){
		$a = 1;
		while(file_exists("../students_assignments/[$a]$assignment")){
			$a++;
			}
		$assignment = "[".$a."]".$assignment;
}

$date = date("d/m/Y H:i:s");
$id = $_GET['id'];
$discipline = $_GET['dis'];
$code  =$_GET['student'];

$sql_1 = "INSERT INTO send_semester_assignment (date, status, assignment_id, discipline, assignment, student) VALUES ('$date', 'On hold', '$id', '$discipline', '$assignment', '$code')";
mysqli_query($connection, $sql_1);

(move_uploaded_file($_FILES['assignment']['tmp_name'], "../students_assignments/".$assignment));

	echo "<h1>Assignment Successfully Sent!<br>Press F5 on your keyboard</h1>";
	die;

}?>


<strong>Attention:</strong> Your due date is <?php  echo $_GET['delivery_date']; ?>
<form name="" method="post" action="" enctype="multipart/form-data">
  <table width="379" border="0">
  <tr>
    <td>Select Your Assignment Below</td>
  </tr>
  <tr>
    <td><label for="fileField"></label>
    <input type="file" name="assignment" id="fileField"></td>
  </tr>
  <tr>
    <td><input class="input" type="submit" name="button" id="button" value="Send"></td>
  </tr>
</table>
</form>
</div><!-- box -->
<?php  } ?>







<?php  if($_GET['pg'] == 'extra_assignments'){ ?>
<div id="box">

<?php  if(isset($_POST['button'])){
	
@$assignment = $_FILES['assignment']['name'];
if($assignment == ''){
	echo "<script language='javascript'>window.alert('Select Assignment To Send!');</script>";
}else{

if(file_exists("../students_assignments/$assignment")){
			$a = 1;
			while(file_exists("../students_assignments/[$a]$assignment")){
				$a++;
			}
			
			$assignment_id = "[".$a."]".$assignment;
			
		}	  
$date = date("d/m/Y H:i:s");
$id = $_GET['id'];
$student = $_GET['student'];
$discipline = $_GET['discipline'];

$sql_2 = "INSERT INTO send_extra_assignment (date, status, assignment_id, discipline, assignment, student) VALUES ('$date', 'On hold', '$id', '$discipline', '$assignment', '$student')";
mysqli_query($connection, $sql_2);

	(move_uploaded_file($_FILES['assignment']['tmp_name'], "../students_assignments/".$assignment));

	
	echo "<h1>Assignment Successfully Sent!<br>Press F5 on your Keyboard.</h1>";
	die;
 }
}?>


<?php 
$id = $_GET['id'];
$sql_1 = "SELECT * FROM extra_assignments WHERE id = '$id'";
$result_1 = mysqli_query($connection, $sql_1);
	while($res_1 = mysqli_fetch_assoc($result_1)){
?>
<strong>Attention:</strong> Your due date is <?php  echo $res_1['delivery_date']; ?>
<form name="" method="post" action="" enctype="multipart/form-data">
<table width="379" border="0">
  <tr>
    <td>Select Your Assignment Below</td>
  </tr>
  <tr>
    <td><label for="fileField"></label>
    <input type="file" name="assignment" id="fileField"></td>
  </tr>
  <tr>
    <td><input class="input" type="submit" name="button" id="button" value="Send"></td>
  </tr>
</table>
</form>
</div><!-- box -->
<?php }} ?>

</body>
</html>