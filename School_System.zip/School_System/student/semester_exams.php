<?php $actual_panel = "student";?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<?php require "../config.php"; ?>
<link href="css/semester_exams.css" rel="stylesheet" type="text/css" />
</head>

<body>
<?php require "header.php"; ?>
<div id="black_box">
</div><!-- black_box -->

<?php if(@$_GET['pg'] == 'semester_assignments'){ ?>

<div id="box">
<h1><strong>Semester Assignments In the System!</strong></h1>
<?php
$sql_1 = mysqli_query($connection, "SELECT * FROM semester_assignments WHERE status = 'Active' AND course = '$year_grade'");
$count_sql_1 = mysqli_num_rows($sql_1);
if($count_sql_1 == ''){
	echo "<h2>There is no Assignment in the System!</h2>";
}else{
 while($res_1 = mysqli_fetch_assoc($sql_1)){
?>
<table width="955" border="0">
  <tr>
    <td width="150">Assignment Number</td>
    <td width="189">Discipline</td>
    <td width="420">Theme</td>
    <td width="260">Delivery Date:</td>
    <td width="170">Semester:</td>
  </tr>
  <tr>
    <td><h2><?php echo $id = $res_1['id']; ?></h2></td>
    <td><h2><?php echo $res_1['discipline']; ?></h2></td>
    <td><h2><?php echo $res_1['theme']; ?></h2></td>
    <td><h2><?php echo $res_1['delivery_date']; ?></h2></td>
    <td><h2><?php echo $res_1['semester']; ?> Semester</h2></td>
  </tr>
  <tr>
    <td><a href="assignment_details.php?id=<?php echo $res_1['id']; ?>&pg=semester_assignments" rel="superbox[iframe][600x400]">Further Details</a></td>
    <td colspan="2">
    <?php 
	$sql_status = mysqli_query($connection, "SELECT * FROM send_semester_assignments WHERE student = '$code' AND status = 'On hold' OR status = 'Accepted' AND assignment_id = '$id'");
	if(mysqli_num_rows($sql_status) >= '1'){ echo "<h2><strong>You already sent this assignment</strong></h2>"; 
	}else{
	?>
    <a href="send_assignment.php?id=<?php echo $res_1['id']; ?>&pg=send_assignment&student=<?php echo $code; ?>&discipline=<?php echo $res_1['discipline']; ?>" rel="superbox[iframe][400x190]">Send Assignent</a>
    <?php } ?>
    </td>
    <td></td>
    <td>&nbsp;</td>
  </tr>
</table>
	
<?php }}?>
</div><!-- box -->
<?php } ?>

<?php if(@$_GET['pg'] == 'extra_assignments'){ ?>

<div id="box">
<h1><strong>Extra Assignments In the System!</strong></h1>
<?php
$sql_1 = mysqli_query($connection, "SELECT * FROM extra_assignments WHERE status = 'Active' AND course = '$year_grade'");
$count_sql_1 = mysqli_num_rows($sql_1);
if($count_sql_1 == ''){
	echo "<h2>There is no Assignment in the System!</h2>";
}else{
 while($res_1 = mysqli_fetch_assoc($sql_1)){
?>
<table width="955" border="0">
  <tr>
    <td width="150">Assignment Number</td>
    <td width="189">Discipline</td>
    <td width="420">Theme</td>
    <td width="260">Delivery Date:</td>
  </tr>
  <tr>
    <td><h2><?php echo $id = $res_1['id']; ?></h2></td>
    <td><h2><?php echo $res_1['discipline']; ?></h2></td>
    <td><h2><?php echo $res_1['theme']; ?></h2></td>
    <td><h2><?php echo $res_1['delivery_date']; ?></h2></td>
  </tr>
  <tr>
    <td><a href="assignment_details.php?id=<?php echo $res_1['id']; ?>&pg=semester_assignments" rel="superbox[iframe][600x400]">Further Details</a></td>
    <td colspan="2">
    <?php 
	$sql_status = mysqli_query($connection, "SELECT * FROM send_extra_assignment WHERE student = '$code' AND status = 'On hold' OR status = 'Accepted' AND assignment_id = '$id'");
	if(mysqli_num_rows($sql_status) >= '1'){ echo "<h2><strong>You already Sent this Assignment</strong></h2>"; 
	}else{
	?>
    <a href="send_assignment.php?id=<?php echo $res_1['id']; ?>&pg=extra_assignments&student=<?php echo $code; ?>&discipline=<?php echo $res_1['discipline']; ?>" rel="superbox[iframe][400x190]">Send Assignment</a>
    <?php } ?>
    </td>
    <td></td>
    <td>&nbsp;</td>
  </tr>
</table>
	
<?php }}?>
</div><!-- box -->
<?php } ?>


</body>
</html>