﻿<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Attendance</title>
<link rel="stylesheet" type="text/css" href="css/attendance.css"/>
</head>

<body>
<?php require "header.php"; ?>

<div id="black_box">
</div><!-- black_box -->

<div id="box">
 <h1><strong>Attendance</strong></h1>
<table width="900" border="0">
  <tr>
    <td align="center" colspan="5"><table>General Discipline Attendance during Semester</table></td>
  </tr>
  <tr>
    <td align="center" colspan="5"><hr></td>
  </tr>
  <tr>
    <td width="242"><strong>DISCIPLINE</strong></td>
    <td width="179"><strong>Attendance Total</strong></td>
    <td width="152"><strong>Absence Total</strong></td>
    <td width="192"><strong>Justified Absence</strong></td>
    <td width="119"><strong>Result</strong></td>
  </tr>
<?php
$sql_1 = "SELECT * FROM disciplines WHERE course = '$year_grade'";
$result_1 = mysqli_query($connection, $sql_1);
	while($res_1 = mysqli_fetch_assoc($result_1)){

?>  
  <tr>
    <td><?php echo $discipline = $res_1['discipline']; ?></td>
    <td><?php 
	$sql_2 = "SELECT * FROM attendance_in_class WHERE course = '$year_grade' AND discipline = '$discipline' AND student_code = '$code' AND attend = 'YES'";
	$result_2 = mysqli_query($connection, $sql_2);
	$see_result_2 = mysqli_num_rows($result_2);
	echo $see_result_2 / 3; ?></td>
    <td><?php $sql_3 = "SELECT * FROM attendance_in_class WHERE course = '$year_grade' AND discipline = '$discipline' AND student_code = '$code' AND attend = 'NO'"; 
	$result_3 = mysqli_query($connection, $sql_3);
	$see_result_3 = mysqli_num_rows($result_3);
	echo $see_result_3 / 3;
	?></td>
    <td><?php $sql_4 = "SELECT * FROM attendance_in_class WHERE course = '$year_grade' AND discipline = '$discipline' AND student_code = '$code' AND attend = 'JUSTIFIED'"; 
	$result_4 = mysqli_query($connection, $sql_4);
	$see_result_4 = mysqli_num_rows($result_4);
	echo $see_result_4 / 3;
	?></td>
    <td>
    <?php
	$sql_5 = "SELECT * FROM attendance_in_class WHERE course = '$year_grade' AND discipline = '$discipline'";
	$result_5 = mysqli_query($connection, $sql_5);
	$count_sql_5 = mysqli_num_rows($result_5);
	
	$total = ($count_sql_5*25)/100;
	
	if($see_result_3 > $total){
		echo "Approved";
	}else{
		echo "Failed";
		}
	
	?>    
    </td>
  </tr>
  <tr>
    <td colspan="5"><img src="img/menu_topo.png" width="900" height="1"></td>
  </tr>
<?php } ?>  
</table> 

</div><!-- box -->

</body>
</html>